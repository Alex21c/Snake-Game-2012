#ifndef COLLISONS_DETECTIONS_H
#define COLLISONS_DETECTIONS_H





//_________________________________ Prevent mouses to collide with snake ________________________________

void handle_and_prevent_mouses_collisons_with_snake
( 
// snake position variables
int i,int k,int tail_x[1000],int tail_y[1000],

//5th Mouse  variables
int *m5_x,int *m5_y,bool *m5_forward_dir,bool *m5_backward_dir,bool *m5_eat,
bool *m5_first_step,bool *m5_second_step,bool *m5_third_step,bool *m5_fourth_step,

//6th Mouse  variables
int *m6_x,int *m6_y,bool *m6_forward_dir,bool *m6_backward_dir,bool *m6_eat,
bool *m6_first_step,bool *m6_second_step,bool *m6_third_step,bool *m6_fourth_step,


//1st Mouse  variables
int *m1_x,int *m1_y,bool *m1_forward_dir,bool *m1_backward_dir,bool *m1_eat,
bool *m1_first_step,bool *m1_second_step,bool *m1_third_step,

//4th Mouse  variables
int *m4_x,int *m4_y,bool *m4_forward_dir,bool *m4_backward_dir,bool *m4_eat,
bool *m4_first_step,bool *m4_second_step,bool *m4_third_step,

//2nd Mouse  variables
int *m2_x,int *m2_y,bool *m2_forward_dir,bool *m2_backward_dir,bool *m2_eat,
bool *m2_first_step,bool *m2_second_step,bool *m2_third_step,

//3rd Mouse  variables
int *m3_x,int *m3_y,bool *m3_forward_dir,bool *m3_backward_dir,bool *m3_eat,
bool *m3_first_step,bool *m3_second_step,bool *m3_third_step



);



//_______________ Catch and Eat mouses ___________________________

void catch_and_eat_mouses_which_collides_with_snake
( 
// snake position variables
int i,int k,int head_x,int head_y,

//5th Mouse  variables
int *m5_x,int *m5_y,bool *m5_forward_dir,bool *m5_backward_dir,bool *m5_eat,
bool *m5_first_step,bool *m5_second_step,bool *m5_third_step,bool *m5_fourth_step,

//6th Mouse  variables
int *m6_x,int *m6_y,bool *m6_forward_dir,bool *m6_backward_dir,bool *m6_eat,
bool *m6_first_step,bool *m6_second_step,bool *m6_third_step,bool *m6_fourth_step,


//1st Mouse  variables
int *m1_x,int *m1_y,bool *m1_forward_dir,bool *m1_backward_dir,bool *m1_eat,
bool *m1_first_step,bool *m1_second_step,bool *m1_third_step,

//4th Mouse  variables
int *m4_x,int *m4_y,bool *m4_forward_dir,bool *m4_backward_dir,bool *m4_eat,
bool *m4_first_step,bool *m4_second_step,bool *m4_third_step,

//2nd Mouse  variables
int *m2_x,int *m2_y,bool *m2_forward_dir,bool *m2_backward_dir,bool *m2_eat,
bool *m2_first_step,bool *m2_second_step,bool *m2_third_step,

//3rd Mouse  variables
int *m3_x,int *m3_y,bool *m3_forward_dir,bool *m3_backward_dir,bool *m3_eat,
bool *m3_first_step,bool *m3_second_step,bool *m3_third_step,bool *erase,

char *file_name,char *name,char *score,char *lifes,char *level,
int *m1_score,int *m2_score,int *m3_score,int *m4_score,int *m5_score,int *m6_score,int *food_eaten,int *no_of_erase,int *time,int *master_time

);

#endif

