#include "abhishek.h"

void encrypt_decrypt(char *file_name)
{

char data[100];

ifstream read;

read.open(file_name,ios::in);
read.getline(data,100,'\n');
read.close();


int length=strlen(data),i,key=217;

ofstream write;
write.open(file_name,ios::out);

for(i=0;i<length;i++)
{
data[i]=data[i]^key;
write<<data[i];        
}
write.close();

  
}




//*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/

void score_encryption_decryption(char *file_name)
{


char name[100][100];

    int i=0,j,n;
 ifstream read;
 
 read.open(file_name,ios::in);
 while(read)
 {
 read.getline(name[i],100,'\n');
 n=i;
 i++;
 }
 read.close();
    
int key=217;

ofstream write;
write.open(file_name,ios::out);
for(i=0;i<n;i++)
{
for(j=0;j<strlen(name[i])-1;j++)
{
name[i][j]=name[i][j]^key;
}
write<<name[i]<<"\n";
}

write.close();

}



