#include "abhishek.h"
#include "mouses variables.h"
#include "snake body.h"
#include "prediators variables.h"




void snake(char file_name[100],char name[100],char score[10],char lifes[5],char level[5],int speed)
{


bool level_clear=false;

derived_place_prediators obj_placing_prediators;
derived_erase_prediators obj_erasing_prediators;


obj_placing_prediators.handle_eagle(&e_x,&e_y,&eagle_forward_dir,&eagle_backward_dir);

//obj_erasing_prediators.handle_black_eagle(&e_x,&e_y,&forward_dir,&backward_dir,&eagle_speed);


int cx=100,cy=300,temp;




bool exit_game=false;

char msg[100];
int time=0,master_time=60;

//displaying master_time
sprintf(msg,"%d",master_time);
setcolor(COLOR(1,178,87));
outtextxy(215,101+5+2+5+5,msg);

int temp_level=atoi(level);
cout<<temp_level;

//_________________________________Creating object of Classes -> first_mouse and first_mouse_black ____________________
derived_mouses  obj_derived_mouses;
derived_mouses_black obj_derived_mouses_black;



//varialbe for keep track of the number of foods being aten by snake
int food_eaten=0,change_x=0,change_y=0;
int no_of_erase=0;


bool m5_erase=false,m6_erase=false,m1_erase=false,m2_erase=false,m3_erase=false,m4_erase=false;




int head_x=1200,head_y=400,distance=28;
int tail_x[1000],tail_y[1000],i=0,k=0,length;

tail_x[i]=head_x;
tail_y[i]=head_y;
++i;

//printing snake body with desired length
for(length=1;length<=10;length++)
{
left_body_part(&head_x,&head_y);

//readimagefile("Snake body parts\\body left and right.jpg",head_x-24,head_y-9,head_x+27,head_y+9);

head_x=head_x-distance;
head_y=head_y;
tail_x[i]=head_x;
tail_y[i]=head_y;
++i;
//snake_left_head_black(head_x-10,head_y);
}

//Initially Placing Mouses

if(m1_eat==false&&m2_eat==false&&m3_eat==false&&m4_eat==false&&m5_eat==false&&m6_eat==false)
{

if(m1_eat==false)
obj_derived_mouses.handle_top_left_duck(m1_x,m1_y,m1_color,m1_forward_dir,m1_backward_dir,m1_first_step,m1_second_step,m1_third_step);

if(m2_eat==false)
obj_derived_mouses.handle_bottom_left_egret(m2_x,m2_y,m2_color,m2_forward_dir,m2_backward_dir,m2_first_step,m2_second_step,m2_third_step);

if(m3_eat==false)
obj_derived_mouses.handle_top_right_rabbit(m3_x,m3_y,m3_color,m3_forward_dir,m3_backward_dir,m3_first_step,m3_second_step,m3_third_step);

if(m4_eat==false)
obj_derived_mouses.handle_bottom_right_white_bird(m4_x,m4_y,m4_color,m4_forward_dir,m4_backward_dir,m4_first_step,m4_second_step,m4_third_step);

if(m5_eat==false)
obj_derived_mouses.handle_mouse_upper(&m5_x,&m5_y,&m5_color,&m5_forward_dir,&m5_backward_dir,&m5_first_step,&m5_second_step,&m5_third_step,&m5_fourth_step);

if(m6_eat==false)
obj_derived_mouses.handle_flying_rooster_lower(&m6_x,&m6_y,&m6_color,&m6_forward_dir,&m6_backward_dir,&m6_first_step,&m6_second_step,&m6_third_step,&m6_fourth_step);
}



char KEY=LEFT,KEY1;
bool erase=true;
int delay_time=speed;

bool left_head_erase = true;
bool right_head_erase = true;
bool upper_head_erase = true;
bool lower_head_erase = true;

bool left_tail = true;
bool right_tail = true;
bool upper_tail= true;
bool lower_tail = true;

bool extra_erase=false;




//poison
bool poison_dir_left=false;





while(KEY!=ESCAPE)
{
time+=100;

 //increasing value of time
 //if(time>=1100)

 if(time>=1100)
 {
sprintf(msg,"%d",master_time);
setcolor(BLACK);
outtextxy(215,101+5+2+5+5,msg);

              
master_time-=1;
sprintf(msg,"%d",master_time);
setcolor(COLOR(1,178,87));
outtextxy(215,101+5+2+5+5,msg);
time=0;
}

 
 if(master_time==0)
 {
 //kill the snake
 int temp_life;
 
readimagefile("screen\\time out.jpg",500,400,500+395,400+107);
delay(2000);
    
temp_life=atoi(lifes);
--temp_life;


itoa(temp_life,lifes,10);

if(temp_life==0)
{
encrypt_decrypt(file_name);
exit(1);
}

//UPDATE PROFILE
ofstream write;
write.open(file_name,ios::out);
//___data entering format - > name<<score<<lifes<<level ____
write<<name<<"^"<<score<<"^"<<lifes<<"^"<<level<<"^";
write.close();

access_profile_data(file_name,name,score,lifes,level);
cleardevice();
start_game(file_name,name,score,lifes,level,speed);
 
 
 
 }
         
///BBBBBBBBBBBBBBAAAAAAAAAAAAAAAAAAAAASSSSSSSSSSSSSSSSSSSSSSSSSEEEEEEEEEEEEEEEEEEE
        
//erase snake heads last positions
if(left_head_erase==true)
snake_left_head_black(head_x-15,head_y); 
else if(right_head_erase==true)
snake_right_head_black(head_x+15,head_y); 
else if(upper_head_erase==true)
snake_upper_head_black(head_x,head_y-15); 
else if(lower_head_erase==true)
snake_lower_head_black(head_x,head_y+15); 


left_head_erase=false;
right_head_erase=false;
upper_head_erase=false;
lower_head_erase=false;


//ERASE TAIL LAST POSITION
if(extra_erase==true)
{


extra_erase=false;


left_body_part_black(&tail_x[k],&tail_y[k]);
right_body_part_black(&tail_x[k],&tail_y[k]);
upper_body_part_black(&tail_x[k],&tail_y[k]);
lower_body_part_black(&tail_x[k],&tail_y[k]);

print_tail(tail_x,tail_y,&left_tail,&right_tail,&upper_tail,&lower_tail,k);


erase_tail(tail_x,tail_y,&left_tail,&right_tail,&upper_tail,&lower_tail,k);

++k;


}


                  
//ERASE TAIL LAST POSITION
if(erase==true&&no_of_erase==0)
{







left_body_part_black(&tail_x[k],&tail_y[k]);
right_body_part_black(&tail_x[k],&tail_y[k]);
upper_body_part_black(&tail_x[k],&tail_y[k]);
lower_body_part_black(&tail_x[k],&tail_y[k]);



left_tail=false;
right_tail=false;
upper_tail=false;
lower_tail=false;


++k;

}




//___________________________________________________

if((KEY==LEFT)&&(KEY1!=RIGHT))
{
if((KEY1==UP)||(KEY1==DOWN))
{
extra_erase=true;
        
if(KEY1==UP)    
{         
head_y+=9;
}
else if(KEY1==DOWN)
{
head_y-=9;

}
upper_body_part(&head_x,&head_y);

if(KEY1==UP)             
head_y-=9;
else if(KEY1==DOWN)
head_y+=9;

head_x=head_x-distance+8;
head_y=head_y;
tail_x[i]=head_x;
tail_y[i]=head_y;
change_x=8,change_y=0;

++i;
}

KEY1=KEY;   
erase=true;
//delay_time=1000;



     
left_body_part(&head_x,&head_y);

head_x=head_x-distance;
head_y=head_y;
tail_x[i]=head_x;
tail_y[i]=head_y;
++i;

snake_left_head(head_x-15,head_y);
left_head_erase=true;


tail_position_set(tail_x,tail_y,&left_tail,&right_tail,&upper_tail,&lower_tail,k);




}    

else if((KEY==RIGHT)&&(KEY1!=LEFT))
{

if((KEY1==UP)||(KEY1==DOWN))
{
extra_erase=true;


if(KEY1==UP) 
{            
head_y+=9;

}
else if(KEY1==DOWN)
{
head_y-=9;

}
upper_body_part(&head_x,&head_y);

if(KEY1==UP)             
head_y-=9;
else if(KEY1==DOWN)
head_y+=9;

head_x=head_x+distance-8;
head_y=head_y;
tail_x[i]=head_x;
tail_y[i]=head_y;

change_x=-8,change_y=0;

++i;
}
 
  KEY1=KEY;  
  erase=true;
 // delay_time=1000;
   
   
right_body_part(&head_x,&head_y);

head_x=head_x+distance;
head_y=head_y;
tail_x[i]=head_x;
tail_y[i]=head_y;
++i;


snake_right_head(head_x+15,head_y);
right_head_erase=true;

tail_position_set(tail_x,tail_y,&left_tail,&right_tail,&upper_tail,&lower_tail,k);




} 

else if((KEY==UP)&&(KEY1!=DOWN))
{
     

if((KEY1==LEFT)||(KEY1==RIGHT))
{
extra_erase=true;

if(KEY1==LEFT) 
{            
head_x+=9;

}
else if(KEY1==RIGHT)
{
head_x-=9;

}
left_body_part(&head_x,&head_y);

if(KEY1==LEFT)             
head_x-=9;
else if(KEY1==RIGHT)
head_x+=9;

head_x=head_x;
head_y=head_y-distance+8;
tail_x[i]=head_x;
tail_y[i]=head_y;

change_x=0,change_y=+8;

++i;

}
     
     KEY1=KEY;
     erase=true;
 //    delay_time=1000;
     
     
upper_body_part(&head_x,&head_y);

head_x=head_x;
head_y=head_y-distance;
tail_x[i]=head_x;
tail_y[i]=head_y;
++i;


// for printing head
snake_upper_head(head_x,head_y-15);
upper_head_erase=true;

tail_position_set(tail_x,tail_y,&left_tail,&right_tail,&upper_tail,&lower_tail,k);



}     

    
else if((KEY==DOWN)&&(KEY1!=UP))
{
    
if((KEY1==LEFT)||(KEY1==RIGHT))
{
extra_erase=true;

if(KEY1==LEFT)  
{          
head_x+=9;

}
else if(KEY1==RIGHT)
{
head_x-=9;

}
left_body_part(&head_x,&head_y);

if(KEY1==LEFT)             
head_x-=9;
else if(KEY1==RIGHT)
head_x+=9;

head_x=head_x;
head_y=head_y+distance-8;
tail_x[i]=head_x;
tail_y[i]=head_y;

change_x=0,change_y=-8;
++i;
}



KEY1=KEY;
erase=true;
    // delay_time=1000;
     
lower_body_part(&head_x,&head_y);

head_x=head_x;
head_y=head_y+distance;
tail_x[i]=head_x;
tail_y[i]=head_y;
++i;


// for printing head
snake_lower_head(head_x,head_y+15);
lower_head_erase=true;

tail_position_set(tail_x,tail_y,&left_tail,&right_tail,&upper_tail,&lower_tail,k);




}
else if(KEY==ESCAPE)
break;




//_______________________ printing tail and deleting tail here for enhancing appearance ________________//
// printing snake tail in the choosen direction
print_tail(tail_x,tail_y,&left_tail,&right_tail,&upper_tail,&lower_tail,k-1);

char temp1;
char temp2;


//_______________ Catch and Eat mouses ___________________________

catch_and_eat_mouses_which_collides_with_snake
( 

// snake position variables
i,k,head_x,head_y,
//5th mouse variables
&m5_x,&m5_y,&m5_forward_dir,&m5_backward_dir,&m5_eat,&m5_first_step,&m5_second_step, &m5_third_step, &m5_fourth_step,

//6th mouse variables
&m6_x,&m6_y,&m6_forward_dir,&m6_backward_dir,&m6_eat,&m6_first_step,&m6_second_step, &m6_third_step, &m6_fourth_step,

//1st mouse variables
&m1_x,&m1_y,&m1_forward_dir,&m1_backward_dir,&m1_eat,&m1_first_step,&m1_second_step, &m1_third_step,

//1st mouse variables
&m4_x,&m4_y,&m4_forward_dir,&m4_backward_dir,&m4_eat,&m4_first_step,&m4_second_step, &m4_third_step,
//2nd mouse variables
&m2_x,&m2_y,&m2_forward_dir,&m2_backward_dir,&m2_eat,&m2_first_step,&m2_second_step, &m2_third_step,
//3rdmouse variables
&m3_x,&m3_y,&m3_forward_dir,&m3_backward_dir,&m3_eat,&m3_first_step,&m3_second_step, &m3_third_step,&erase,

file_name,name,score,lifes,level,
&m1_score,&m2_score,&m3_score,&m4_score,&m5_score,&m6_score,&food_eaten,&no_of_erase,&time,&master_time


);


//______________________________________Placing Food_________________________________


if(m1_eat==false)
obj_derived_mouses.handle_top_left_duck(m1_x,m1_y,m1_color,m1_forward_dir,m1_backward_dir,m1_first_step,m1_second_step,m1_third_step);

if(m2_eat==false)
obj_derived_mouses.handle_bottom_left_egret(m2_x,m2_y,m2_color,m2_forward_dir,m2_backward_dir,m2_first_step,m2_second_step,m2_third_step);


if(m3_eat==false)
obj_derived_mouses.handle_top_right_rabbit(m3_x,m3_y,m3_color,m3_forward_dir,m3_backward_dir,m3_first_step,m3_second_step,m3_third_step);


if(m4_eat==false)
obj_derived_mouses.handle_bottom_right_white_bird(m4_x,m4_y,m4_color,m4_forward_dir,m4_backward_dir,m4_first_step,m4_second_step,m4_third_step);


if(m5_eat==false)
obj_derived_mouses.handle_mouse_upper(&m5_x,&m5_y,&m5_color,&m5_forward_dir,&m5_backward_dir,&m5_first_step,&m5_second_step,&m5_third_step,&m5_fourth_step);

if(m6_eat==false)
obj_derived_mouses.handle_flying_rooster_lower(&m6_x,&m6_y,&m6_color,&m6_forward_dir,&m6_backward_dir,&m6_first_step,&m6_second_step,&m6_third_step,&m6_fourth_step);

//-----==========---------- placing eagle ----------==========----------=============
obj_placing_prediators.handle_eagle(&e_x,&e_y,&eagle_forward_dir,&eagle_backward_dir);





if(KEY==poison_z)
{

time+=1000;

if(KEY1==LEFT)
{
// printing snake left_head 
snake_left_head(head_x-15,head_y); 
//poison_left( head_x-15, head_y, m1_x,  m1_y, m2_x, m2_y, m3_x, m3_y, m4_x, m4_y, m5_x, m5_y, m6_x, m6_y);

// decreasing value of 'k' because it is incremented last time
--k;

// setting tail position and direction
tail_position_set(tail_x,tail_y,&left_tail,&right_tail,&upper_tail,&lower_tail,k);

// printing snake tail in the choosen direction
print_tail(tail_x,tail_y,&left_tail,&right_tail,&upper_tail,&lower_tail,k);


// ***************************************   generating poison in the left direction   **************************************
poison_left
(
 head_x-15, head_y, m1_x,  m1_y, m2_x, m2_y, m3_x, m3_y, m4_x, m4_y, m5_x, m5_y, m6_x, m6_y,
file_name,name,score,lifes,level,
&m1_score, &m2_score, &m3_score, &m4_score, &m5_score, &m6_score, &food_eaten, &no_of_erase
,&m1_eat,&m2_eat,&m3_eat,&m4_eat,&m5_eat,&m6_eat,
&m5_erase,&erase,&m6_erase,&m1_erase,&m2_erase,&m3_erase,&m4_erase,&time,&master_time
); 


// erasing snake head last position
snake_left_head_black(head_x-15,head_y);

//erasing snake tails last position
erase_tail(tail_x,tail_y,&left_tail,&right_tail,&upper_tail,&lower_tail,k);


// increasing value of 'k' to nullify the effect of decrement or to undo the value of k 
++k;

}     
else if(KEY1==RIGHT)
{
     
// printing snake left_head 
snake_right_head(head_x+15,head_y); 

// decreasing value of 'k' because it is incremented last time
--k;

// setting tail position and direction
tail_position_set(tail_x,tail_y,&left_tail,&right_tail,&upper_tail,&lower_tail,k);

// printing snake tail in the choosen direction
print_tail(tail_x,tail_y,&left_tail,&right_tail,&upper_tail,&lower_tail,k);


// ***************************************   generating poison in the right direction   **************************************
poison_right
(
head_x+15, head_y, m1_x,  m1_y, m2_x, m2_y, m3_x, m3_y, m4_x, m4_y, m5_x, m5_y, m6_x, m6_y,
file_name,name,score,lifes,level,
&m1_score, &m2_score, &m3_score, &m4_score, &m5_score, &m6_score, &food_eaten, &no_of_erase
,&m1_eat,&m2_eat,&m3_eat,&m4_eat,&m5_eat,&m6_eat,
&m5_erase,&erase,&m6_erase,&m1_erase,&m2_erase,&m3_erase,&m4_erase,&time,&master_time
); 


// erasing snake head last position
snake_right_head_black(head_x+15,head_y);

//erasing snake tails last position
erase_tail(tail_x,tail_y,&left_tail,&right_tail,&upper_tail,&lower_tail,k);


// increasing value of 'k' to nullify the effect of decrement or to undo the value of k 
++k;     


}   

else if(KEY1==UP)
{

     
// printing snake left_head 
snake_upper_head(head_x,head_y-15); 

// decreasing value of 'k' because it is incremented last time
--k;

// setting tail position and direction
tail_position_set(tail_x,tail_y,&left_tail,&right_tail,&upper_tail,&lower_tail,k);

// printing snake tail in the choosen direction
print_tail(tail_x,tail_y,&left_tail,&right_tail,&upper_tail,&lower_tail,k);


// ***************************************   generating poison in the upward direction   **************************************
poison_up
(
head_x, head_y-15, m1_x,  m1_y, m2_x, m2_y, m3_x, m3_y, m4_x, m4_y, m5_x, m5_y, m6_x, m6_y,
file_name,name,score,lifes,level,
&m1_score, &m2_score, &m3_score, &m4_score, &m5_score, &m6_score, &food_eaten, &no_of_erase
,&m1_eat,&m2_eat,&m3_eat,&m4_eat,&m5_eat,&m6_eat,
&m5_erase,&erase,&m6_erase,&m1_erase,&m2_erase,&m3_erase,&m4_erase,&time,&master_time
); 


// erasing snake head last position
snake_upper_head_black(head_x,head_y-15);

//erasing snake tails last position
erase_tail(tail_x,tail_y,&left_tail,&right_tail,&upper_tail,&lower_tail,k);


// increasing value of 'k' to nullify the effect of decrement or to undo the value of k 
++k;     

}   
else if(KEY1==DOWN)
{

  
     
// printing snake eft_head 
snake_lower_head(head_x,head_y+15); 

// decreasing value of 'k' because it is incremented last time
--k;

// setting tail position and direction
tail_position_set(tail_x,tail_y,&left_tail,&right_tail,&upper_tail,&lower_tail,k);

// printing snake tail in the choosen direction
print_tail(tail_x,tail_y,&left_tail,&right_tail,&upper_tail,&lower_tail,k);


// generating poison in the left direction
poison_down
(
head_x, head_y+15, m1_x,  m1_y, m2_x, m2_y, m3_x, m3_y, m4_x, m4_y, m5_x, m5_y, m6_x, m6_y,
file_name,name,score,lifes,level,
&m1_score, &m2_score, &m3_score, &m4_score, &m5_score, &m6_score, &food_eaten, &no_of_erase
,&m1_eat,&m2_eat,&m3_eat,&m4_eat,&m5_eat,&m6_eat,
&m5_erase,&erase,&m6_erase,&m1_erase,&m2_erase,&m3_erase,&m4_erase,&time,&master_time
); 


// erasing snake head last position
snake_lower_head_black(head_x,head_y+15);

//erasing snake tails last position
erase_tail(tail_x,tail_y,&left_tail,&right_tail,&upper_tail,&lower_tail,k);


// increasing value of 'k' to nullify the effect of decrement or to undo the value of k 
++k;     
   
     
}   
  


KEY=temp1;
KEY1=temp2;
erase=false;

}
  

if((KEY1==LEFT)&&(KEY==RIGHT))  
{              
KEY=LEFT;  
erase=false; 
     
}
else if((KEY1==RIGHT)&&(KEY==LEFT))                
{
KEY=RIGHT;  
erase=false;
}
else if((KEY1==UP)&&(KEY==DOWN))                
{
KEY=UP;   
erase=false;
}
else if((KEY1==DOWN)&&(KEY==UP))                
{
KEY=DOWN;   
erase=false;
}                              
if(i>=990)
i=0;

if(k>=990)
k=0;

 temp1=KEY;
 temp2=KEY1;


if(erase==true)
delay_time=speed;
else 
delay_time=0;






/*
________________________________________________________________________________________________________

                                              CATCHING AND EATING MOUSES
________________________________________________________________________________________________________

*/





/*
________________________________________________________________________________________________________

                                              ERASING AND PLACING Food
________________________________________________________________________________________________________

*/







//________________________ checking for Snake collisons ___________________________
snake_collison_with_body(i,k,head_x,head_y,tail_x,tail_y,file_name,name,score,lifes,level,change_x,change_y,speed);
snake_collison_with_prediators(i,k,e_x,e_y,tail_x,tail_y,file_name,name,score,lifes,level,speed);


delay(delay_time);


//erasing snake tails last position
erase_tail(tail_x,tail_y,&left_tail,&right_tail,&upper_tail,&lower_tail,k-1);


//-----==========---------- erasing eagle ----------==========----------=============
obj_erasing_prediators.handle_black_eagle(&e_x,&e_y,&eagle_forward_dir,&eagle_backward_dir,&eagle_speed);




//_____________________________________Erasing foods_____________________________________



if((m1_eat==false)||(m1_erase==true))
{
obj_derived_mouses_black.handle_black_top_left_duck(&m1_x,&m1_y,&m2_speed,&m1_forward_dir,&m1_backward_dir,&m1_first_step,&m1_second_step,&m1_third_step);
m1_erase=false;
}
if((m2_eat==false)||(m2_erase==true))
{
obj_derived_mouses_black.handle_black_bottom_left_egret(&m2_x,&m2_y,&m2_speed,&m2_forward_dir,&m2_backward_dir,&m2_first_step,&m2_second_step,&m2_third_step);
m2_erase=false;
}

if((m3_eat==false)||(m3_erase==true))
{

obj_derived_mouses_black.handle_black_top_right_rabbit(&m3_x,&m3_y,&m3_speed,&m3_forward_dir,&m3_backward_dir,&m3_first_step,&m3_second_step,&m3_third_step);
m3_erase=false;
}

if((m4_eat==false)||(m4_erase==true))
{
obj_derived_mouses_black.handle_black_bottom_right_white_bird(&m4_x,&m4_y,&m4_speed,&m4_forward_dir,&m4_backward_dir,&m4_first_step,&m4_second_step,&m4_third_step);
m4_erase=false;
}

if((m5_eat==false)||(m5_erase==true))
{
obj_derived_mouses_black.handle_black_mouse_upper(&m5_x,&m5_y,&m5_speed,&m5_forward_dir,&m5_backward_dir,&m5_first_step,&m5_second_step,&m5_third_step,&m5_fourth_step);
m5_erase=false;

}
if((m6_eat==false)||(m6_erase==true))
{
obj_derived_mouses_black.handle_black_flying_rooster_lower(&m6_x,&m6_y,&m6_speed,&m6_forward_dir,&m6_backward_dir,&m6_first_step,&m6_second_step,&m6_third_step,&m6_fourth_step);
m6_erase=false;
}




if(m1_eat==true&&m2_eat==true&&m3_eat==true&&m4_eat==true&&m5_eat==true&&m6_eat==true)
level_clear=true;








if(level_clear==true)
{
goto refresh;

level:                     
readimagefile("screen\\victory.jpg",500,370,500+419,370+135);
delay(5000);
//show credit menu
cleardevice();


//constructing HEADER BOUNDARY
readimagefile("screen\\credits screen.jpg",10,10,1350,760);

int cx=270,cy=660;

readimagefile("screen\\check sign.jpg",cx,cy,cx+42,cy+38);
/*
cx=700,cy=660;

readimagefile("screen\\check sign.jpg",cx,cy,cx+42,cy+38);
*/
char key;
key='a';
while(key!=ENTER)
{
encrypt_decrypt(file_name);
key=getch();
if(key==ESCAPE)
startup_user_screen(&exit_game,file_name);
else if(key==ENTER)
{
if(cx==700)
{
encrypt_decrypt(file_name);
exit(1);
}
else
startup_user_screen(&exit_game,file_name);
}

key=getch();

//_______________________ Move Cursor Upward if user pressed UP arrow key ___________________
if(key==LEFT)
{
readimagefile("screen\\black check sign.jpg",cx,cy,cx+42,cy+38);

if(cx==700)
cx=270;

readimagefile("screen\\check sign.jpg",cx,cy,cx+42,cy+38);
}
// _________________________________Cursor Moved UP sucessfully ____________________________

//_______________________ Move Cursor Upward if user pressed UP arrow key ___________________
else if(key==RIGHT)
{
readimagefile("screen\\black check sign.jpg",cx,cy,cx+42,cy+38);

if(cx==270)
cx=700;

readimagefile("screen\\check sign.jpg",cx,cy,cx+42,cy+38);

}
// _________________________________Cursor Moved UP sucessfully ____________________________

}
}

// Calling function Prevent mouses 
  handle_and_prevent_mouses_collisons_with_snake
( 

// snake position variables
i,k,tail_x,tail_y,
//5th mouse variables
&m5_x,&m5_y,&m5_forward_dir,&m5_backward_dir,&m5_eat,&m5_first_step,&m5_second_step, &m5_third_step, &m5_fourth_step,

//6th mouse variables
&m6_x,&m6_y,&m6_forward_dir,&m6_backward_dir,&m6_eat,&m6_first_step,&m6_second_step, &m6_third_step, &m6_fourth_step,

//1st mouse variables
&m1_x,&m1_y,&m1_forward_dir,&m1_backward_dir,&m1_eat,&m1_first_step,&m1_second_step, &m1_third_step,

//1st mouse variables
&m4_x,&m4_y,&m4_forward_dir,&m4_backward_dir,&m4_eat,&m4_first_step,&m4_second_step, &m4_third_step,
//2nd mouse variables
&m2_x,&m2_y,&m2_forward_dir,&m2_backward_dir,&m2_eat,&m2_first_step,&m2_second_step, &m2_third_step,
//3rdmouse variables
&m3_x,&m3_y,&m3_forward_dir,&m3_backward_dir,&m3_eat,&m3_first_step,&m3_second_step, &m3_third_step

 
 

);



if(no_of_erase>0)
{
--no_of_erase;

}
else
no_of_erase=0;


change_x=0,change_y=0;

key_pressed(&KEY);

//updating value of time



//-----------------
//;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;//
//////////////////////////   PAUSE MENU   ////////////////////////////////////
//;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;//
//-----------------

//KEY=ESCAPE;
if(KEY==ESCAPE)
{

temp=getcurrentwindow();
initwindow(1366,768,"",-3,-3,false,false);
 
back_screen:

//constructing HEADER BOUNDARY
readimagefile("screen\\pause menu.jpg",10,10,1350,760);

KEY='a';
cx=100,cy=300;


readimagefile("screen\\pdot.jpg",cx,cy,cx+37,cy+36);



//KEY=ENTER;
while(KEY!=ENTER)
{
KEY=getch();

if(KEY==ESCAPE)
goto end;
else if(KEY==ENTER)
{
//cy=300;
//cy=430;
//cy=560;



if(cy==560)
{
encrypt_decrypt(file_name);
refresh:
//____________________first mouse variables____________________________


 m1_x=130,m1_y=280, m1_color=WHITE,m1_speed=30;
 m1_forward_dir=true,m1_backward_dir=false,m1_eat=false;
 m1_first_step=true,m1_second_step=false,m1_third_step=false;



//____________________Second mouse variables____________________________

 m2_x=130,m2_y=650, m2_color=WHITE,m2_speed=30;
 m2_forward_dir=true,m2_backward_dir=false,m2_eat=false;
 m2_first_step=true,m2_second_step=false,m2_third_step=false;




//____________________ third mouse variables____________________________

 m3_x=1240,m3_y=280, m3_color=WHITE,m3_speed=30;
 m3_forward_dir=false,m3_backward_dir=true,m3_eat=false;
 m3_first_step=false,m3_second_step=false,m3_third_step=true;


//____________________ fourth mouse variables____________________________

 m4_x=1240,m4_y=650, m4_color=WHITE,m4_speed=30;
 m4_forward_dir=false,m4_backward_dir=true,m4_eat=false;
 m4_first_step=false,m4_second_step=false,m4_third_step=true;


//____________________ fifth mouse variables____________________________


 m5_x=520,m5_y=280, m5_color=WHITE,m5_speed=30;
 m5_forward_dir=true,m5_backward_dir=false,m5_eat=false;
 m5_first_step=true,m5_second_step=false,m5_third_step=false,m5_fourth_step=false;

//____________________ Sixth mouse variables____________________________

 m6_x=880,m6_y=540, m6_color=WHITE,m6_speed=30;
 m6_forward_dir=false,m6_backward_dir=true,m6_eat=false;
 m6_first_step=true,m6_second_step=false,m6_third_step=false,m6_fourth_step=false;




if(level_clear==true)
goto level;


startup_user_screen(&exit_game,file_name);



}
else if(cy==430)
{
KEY=KEY1;
break;
}            
else if(cy==300)
{
backward:
readimagefile("screen\\settings menu.jpg",10,10,1350,760);

cx=70,cy=280;
readimagefile("screen\\arrow.jpg",cx,cy,cx+70,cy+42);

//*****************//

 KEY='a';
while(KEY!=ENTER)
{
KEY=getch();
if(KEY==ESCAPE)
{

goto back_screen;

}
else if(KEY==ENTER)
{
if(cy==415)
goto back_screen;     

else if(cy==280)
//-------------------------------------------------------------------------
{
    cx=70,cy=275;

readimagefile("screen\\speed settings.jpg",10,10,1350,760);
readimagefile("screen\\thunder.jpg",cx,cy,cx+81,cy+82);




KEY='a';
while(KEY!=ENTER)
{
KEY=getch();
if(KEY==ESCAPE)
goto backward;
else if(KEY==ENTER)
{
//cy=275
//cy=410;
//cy=545;

//begineer 100
//intermediate 60
//advanced 20

if(cy==275)
{
speed = 100; 
}
else if(cy==410)
{
speed = 60;
}
else if(cy==545)
{
speed = 20; 
}


goto end;             

}

KEY=getch();

//_______________________ Move Cursor Upward if user pressed UP arrow KEY ___________________




if(KEY==DOWN)
{
readimagefile("screen\\black thunder.jpg",cx,cy,cx+81,cy+82);



//330 490
if(cy==275)
cy=410;
else if(cy==410)
cy=545;
else if(cy==545)
cy=275;


readimagefile("screen\\thunder.jpg",cx,cy,cx+81,cy+82);


}
// _________________________________Cursor Moved UP sucessfully ____________________________

//_______________________ Move Cursor Upward if user pressed UP arrow KEY ___________________
else if(KEY==UP)
{
readimagefile("screen\\black thunder.jpg",cx,cy,cx+81,cy+82);

if(cy==545)
cy=410;
else if(cy==410)
cy=275;
else if(cy==275)
cy=545;


readimagefile("screen\\thunder.jpg",cx,cy,cx+81,cy+82);

}
// _________________________________Cursor Moved UP sucessfully ____________________________

}



}
//************************//



 

//-------------------------------------------------------------------------
}


KEY=getch();

//_______________________ Move Cursor Upward if user pressed UP arrow KEY ___________________


if(KEY==DOWN)
{
readimagefile("screen\\black arrow.jpg",cx,cy,cx+70,cy+42);

if(cy==280)
cy=415;
else 
cy=280;

readimagefile("screen\\arrow.jpg",cx,cy,cx+70,cy+42);

}
// _________________________________Cursor Moved UP sucessfully ____________________________

//_______________________ Move Cursor Upward if user pressed UP arrow KEY ___________________
else if(KEY==UP)
{
readimagefile("screen\\black arrow.jpg",cx,cy,cx+70,cy+42);
if(cy==415)
cy=280;
else 
cy=415;
readimagefile("screen\\arrow.jpg",cx,cy,cx+70,cy+42);
}
// _________________________________Cursor Moved UP sucessfully ____________________________

}
}



//*****************************//





getch();
KEY=KEY1;
break;
}            




KEY=getch();





//cy=300;
//cy=430;
//cy=560;

//_______________________ Move Cursor Upward if user pressed UP arrow KEY ___________________


if(KEY==DOWN)
{
readimagefile("screen\\black pdot.jpg",cx,cy,cx+37,cy+36);
//330 490
if(cy==300)
cy=430;
else if(cy==430)
cy=560;
else if(cy==560)
cy=300;



readimagefile("screen\\pdot.jpg",cx,cy,cx+37,cy+36);
}
// _________________________________Cursor Moved UP sucessfully ____________________________

//_______________________ Move Cursor Upward if user pressed UP arrow KEY ___________________
else if(KEY==UP)
{
readimagefile("screen\\black pdot.jpg",cx,cy,cx+37,cy+36);
//cy=300;
//cy=430;
//cy=560;

if(cy==560)
cy=430;
else if(cy==430)
cy=300;
else if(cy==300)
cy=560;



readimagefile("screen\\pdot.jpg",cx,cy,cx+37,cy+36);

}

// _________________________________Cursor Moved UP sucessfully ____________________________

}


end:

//closing pause menu window
closegraph(getcurrentwindow());


//setting my main window as current graphics window
setcurrentwindow(temp);
KEY=KEY1;

}


  







}



encrypt_decrypt(file_name);

}//END OF FUNCTION BODY

//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>



