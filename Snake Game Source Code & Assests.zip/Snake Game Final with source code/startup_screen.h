#ifndef STARTUP_SCREEN_H
#define STARTUP_SCREEN_H

void place_cursor(int y_position);
void erase_cursor(int y_position);
void startup_user_screen(bool *exit_game,char *file_name);
void screen(char file_name[100]);
void start_game(char file_name[100],char name[100],char score[10],char lifes[5],char level[5],int speed);
void high_score(char *score);


// function for clearing top header screen

void clear_header_screen_items();




#endif
