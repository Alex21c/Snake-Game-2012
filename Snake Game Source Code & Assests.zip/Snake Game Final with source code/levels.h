#define LEVELS_H

bool chance_1=true;
