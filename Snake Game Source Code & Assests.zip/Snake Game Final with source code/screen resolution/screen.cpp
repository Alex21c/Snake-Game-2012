#include <windows.h>

using namespace std;


int main()
{

system("qres.exe /x 1366 /y 768 && qres.exe /x 1360 /y 768");


   



return 0;
}
