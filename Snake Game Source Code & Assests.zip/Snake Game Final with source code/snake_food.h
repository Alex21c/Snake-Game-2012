
#ifndef SNAKE_FOOD_H
#define SNAKE_FOOD_H

//Creating Base class Mouse
class mouse
{
public:
//Mouse
void mouse_up(int x,int y,int color);
void mouse_down(int x,int y,int color);
void mouse_left(int x,int y,int color);
void mouse_right(int x,int y,int color);

//rabbit
void rabbit_up(int x,int y,int color);
void rabbit_down(int x,int y,int color);
void rabbit_left(int x,int y,int color);
void rabbit_right(int x,int y,int color);

//flying rooster
void flying_rooster_up(int x,int y,int color);
void flying_rooster_down(int x,int y,int color);
void flying_rooster_left(int x,int y,int color);
void flying_rooster_right(int x,int y,int color);

//egret
void egret_right(int x,int y,int color);
void egret_left(int x,int y,int color);
void egret_up(int x,int y,int color);
void egret_down(int x,int y,int color);

//cocks
void cock_right(int x,int y,int color);
void cock_left(int x,int y,int color);
void cock_up(int x,int y,int color);
void cock_down(int x,int y,int color);

//ducks
void duck_right(int x,int y,int color);
void duck_left(int x,int y,int color);
void duck_up(int x,int y,int color);
void duck_down(int x,int y,int color);


//white tropical bird
void white_bird_right(int x,int y,int color);
void white_bird_left(int x,int y,int color);
void white_bird_up(int x,int y,int color);
void white_bird_down(int x,int y,int color);


};

//class mouse obj_mouse;


//Creating Base Class Black mouse for erasing purpose
class black_mouse
{
public:
//Mouses
void black_mouse_right(int x,int y);
void black_mouse_left(int x,int y);
void black_mouse_up(int x,int y);
void black_mouse_down(int x,int y);

//rabbits
void black_rabbit_right(int x,int y);
void black_rabbit_left(int x,int y);
void black_rabbit_up(int x,int y);
void black_rabbit_down(int x,int y);

//black flying rooster
void black_flying_rooster_right(int x,int y);
void black_flying_rooster_left(int x,int y);
void black_flying_rooster_up(int x,int y);
void black_flying_rooster_down(int x,int y);


//black egret
void black_egret_right(int x,int y);
void black_egret_left(int x,int y);
void black_egret_up(int x,int y);
void black_egret_down(int x,int y);


//black cocks
void black_cock_right(int x,int y);
void black_cock_left(int x,int y);
void black_cock_up(int x,int y);
void black_cock_down(int x,int y);



//black ducks
void black_duck_right(int x,int y);
void black_duck_left(int x,int y);
void black_duck_up(int x,int y);
void black_duck_down(int x,int y);

//tropical white bird
void black_white_bird_right(int x,int y);
void black_white_bird_left(int x,int y);
void black_white_bird_up(int x,int y);
void black_white_bird_down(int x,int y);


};



//________________________________________ Creating Derived Classes _____________________________

//_____________Derived Classes of First Mouse____________________________
class derived_mouses:public mouse
{
public:



//Corners cocks
void handle_top_left_cock(int m1_x,int m1_y,int color,bool forward_dir,bool backward_dir,bool first_step,bool second_step,bool third_step);       
void handle_top_right_cock(int m3_x,int m3_y,int color,bool forward_dir,bool backward_dir,bool first_step,bool second_step,bool third_step);


//ducks
void handle_top_left_duck(int m1_x,int m1_y,int color,bool forward_dir,bool backward_dir,bool first_step,bool second_step,bool third_step);       
void handle_top_right_rabbit(int m3_x,int m3_y,int color,bool forward_dir,bool backward_dir,bool first_step,bool second_step,bool third_step);

// egret
void handle_bottom_left_egret(int m2_x,int m2_y,int color,bool forward_dir,bool backward_dir,bool first_step,bool second_step,bool third_step);       

void handle_bottom_right_white_bird(int m4_x,int m4_y,int color,bool forward_dir,bool backward_dir,bool first_step,bool second_step,bool third_step);       

//flying rooster
void handle_mouse_upper(int *m5_x,int *m5_y,int *color,bool *forward_dir,bool *backward_dir,bool *first_step,bool *second_step,bool *third_step,bool *fourth_step);       

void handle_flying_rooster_lower(int *m6_x,int *m6_y,int *color,bool *forward_dir,bool *backward_dir,bool *first_step,bool *second_step,bool *third_step,bool *fourth_step);       

void handle_7th_mouse(int m7_x,int m7_y,int color,bool forward_dir,bool backward_dir,bool first_step,bool second_step,bool third_step);       
void handle_8th_mouse(int m8_x,int m8_y,int color,bool forward_dir,bool backward_dir,bool first_step,bool second_step,bool third_step);       
void handle_9th_mouse(int m9_x,int m9_y,int color,bool forward_dir,bool backward_dir,bool first_step,bool second_step,bool third_step);       
void handle_10th_mouse(int m10_x,int m10_y,int color,bool forward_dir,bool backward_dir,bool first_step,bool second_step,bool third_step);       
       
             
};



class derived_mouses_black:public black_mouse
{
public:

//cocks      
void handle_black_top_left_cock(int *m1_x,int *m1_y,int *speed,bool *forward_dir,bool *backward_dir,bool *first_step,bool *second_step,bool *third_step);  
void handle_black_top_right_cock(int *m3_x,int *m3_y,int *speed,bool *forward_dir,bool *backward_dir,bool *first_step,bool *second_step,bool *third_step);

//ducks
void handle_black_top_left_duck(int *m1_x,int *m1_y,int *speed,bool *forward_dir,bool *backward_dir,bool *first_step,bool *second_step,bool *third_step);  
void handle_black_top_right_rabbit(int *m3_x,int *m3_y,int *speed,bool *forward_dir,bool *backward_dir,bool *first_step,bool *second_step,bool *third_step);

//egret
void handle_black_bottom_left_egret(int *m2_x,int *m2_y,int *speed,bool *forward_dir,bool *backward_dir,bool *first_step,bool *second_step,bool *third_step);
void handle_black_bottom_right_white_bird(int *m4_x,int *m4_y,int *speed,bool *forward_dir,bool *backward_dir,bool *first_step,bool *second_step,bool *third_step);

//top middle and bottom middle mouses
void handle_black_mouse_upper(int *m5_x,int *m5_y,int *speed,bool *forward_dir,bool *backward_dir,bool *first_step,bool *second_step,bool *third_step,bool *fourth_step);       
void handle_black_flying_rooster_lower(int *m6_x,int *m6_y,int *speed,bool *forward_dir,bool *backward_dir,bool *first_step,bool *second_step,bool *third_step,bool *fourth_step);       


void handle_7th_black_mouse(int *m7_x,int *m7_y,int *color,bool *forward_dir,bool *backward_dir,bool *first_step,bool *second_step,bool *third_step);       
void handle_8th_black_mouse(int *m8_x,int *m8_y,int *color,bool *forward_dir,bool *backward_dir,bool *first_step,bool *second_step,bool *third_step);       
void handle_9th_black_mouse(int *m9_x,int *m9_y,int *color,bool *forward_dir,bool *backward_dir,bool *first_step,bool *second_step,bool *third_step);       
void handle_10th_black_mouse(int *m10_x,int *m10_y,int *color,bool *forward_dir,bool *backward_dir,bool *first_step,bool *second_step,bool *third_step);       
      
};
//_____________________________________________________________________




//class black_mouse obj_black_mouse;

#endif
