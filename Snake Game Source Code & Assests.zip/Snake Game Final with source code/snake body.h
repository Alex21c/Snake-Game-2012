#ifndef SNAKE_BODY_H
#define SNAKE_BODY_H

void left_body_part(int *head_x,int *head_y);
void right_body_part(int *head_x,int *head_y);
void upper_body_part(int *head_x,int *head_y);
void lower_body_part(int *head_x,int *head_y);

// Black body parts
void left_body_part_black(int *head_x,int *head_y);
void right_body_part_black(int *head_x,int *head_y);
void upper_body_part_black(int *head_x,int *head_y);
void lower_body_part_black(int *head_x,int *head_y);


#endif


