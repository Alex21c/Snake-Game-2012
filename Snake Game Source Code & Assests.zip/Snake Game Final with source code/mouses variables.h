#ifndef MOUSES_VARIABLES_H
#define MOUSES_VARIABLES_H




//LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
//LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
//LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
//LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

//____________________first mouse variables____________________________


int m1_x=130,m1_y=280, m1_color=WHITE,m1_speed=10;
bool m1_forward_dir=true,m1_backward_dir=false,m1_eat=false;
bool m1_first_step=true,m1_second_step=false,m1_third_step=false;



//____________________Second mouse variables____________________________

int m2_x=130,m2_y=650, m2_color=WHITE,m2_speed=20;
bool m2_forward_dir=true,m2_backward_dir=false,m2_eat=false;
bool m2_first_step=true,m2_second_step=false,m2_third_step=false;




//____________________ third mouse variables____________________________

int m3_x=1240,m3_y=280, m3_color=WHITE,m3_speed=30;
bool m3_forward_dir=false,m3_backward_dir=true,m3_eat=false;
bool m3_first_step=false,m3_second_step=false,m3_third_step=true;


//____________________ fourth mouse variables____________________________

int m4_x=1240,m4_y=650, m4_color=WHITE,m4_speed=40;
bool m4_forward_dir=false,m4_backward_dir=true,m4_eat=false;
bool m4_first_step=false,m4_second_step=false,m4_third_step=true;


//____________________ fifth mouse variables____________________________


int m5_x=520,m5_y=280, m5_color=WHITE,m5_speed=50;
bool m5_forward_dir=true,m5_backward_dir=false,m5_eat=false;
bool m5_first_step=true,m5_second_step=false,m5_third_step=false,m5_fourth_step=false;

//____________________ Sixth mouse variables____________________________

int m6_x=880,m6_y=540, m6_color=WHITE,m6_speed=60;
bool m6_forward_dir=false,m6_backward_dir=true,m6_eat=false;
bool m6_first_step=true,m6_second_step=false,m6_third_step=false,m6_fourth_step=false;



//_____________________ Foods score ________________________

int m1_score=25, m2_score=50, m3_score=75, m4_score=100, m5_score=125, m6_score=150;




//LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
//LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
//LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
//LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

//*************** PREDIATORS ************


#endif
