#include "abhishek.h"




// 130 is the least value along x axis
// 230 is the least value alnog y axis

// 1240 is the maximum value along x axis
// 650 is the  maximum value alnog y axis


//spacing of 120 pxs b/w two horizontal mouses
//spacing of 110 pxs b/w two vertical mouses


//_______________________Top  LEFT Position Mouse ______________________


void derived_mouses::handle_top_left_duck(int m1_x,int m1_y,int color,bool forward_dir,bool backward_dir,bool first_step,bool second_step,bool third_step)
{
     

if(forward_dir==true)
{


//Move mouse 1 in forward diretion acc. to step 1
if((m1_x>=130&&m1_x<=250)&&(first_step==true)&&(m1_y<=280))
duck_right(m1_x,m1_y,WHITE);


//Move mouse 1 in forward diretion acc. to step 1
 if(m1_x>=250&&(m1_y>=280&&m1_y<=390)&&(second_step==true))
duck_down(m1_x,m1_y,WHITE);

//Move mouse 1 in forward diretion acc. to step 1

 if((m1_x>=250&&m1_x<=370)&&(third_step==true)&&(m1_y<=390))
duck_right(m1_x,m1_y,WHITE);



}

//__________________________ BACKWARD DIRECTION IS TRUE __________________

else if(backward_dir==true)
{
//move mouse 1 in the forward directino acc. to step 3

if((m1_x>=250&&m1_x<=370)&&(third_step==true)&&(m1_y<=390))
duck_left(m1_x,m1_y,WHITE);
//move mouse 1 in the forward directino acc. to step 2

if(m1_x>=250&&(m1_y>=280&&m1_y<=390)&&(second_step==true))
duck_up(m1_x,m1_y,WHITE);
//Move mouse 1 in forward diretion acc. to step 1

if((m1_x>=130&&m1_x<=250)&&(first_step==true)&&(m1_y<=280))
duck_left(m1_x,m1_y,WHITE);


}

      



}

void  derived_mouses_black::handle_black_top_left_duck(int *m1_x,int *m1_y,int *speed,bool *forward_dir,bool *backward_dir,bool *first_step,bool *second_step,bool *third_step)
{
      
      
if(*forward_dir==true)
{
//Move mouse 1 in forward diretion acc. to step 1
if((*m1_x>=130&&*m1_x<=250)&&(*first_step==true)&&(*m1_y<=280))
{
black_duck_right(*m1_x,*m1_y);
*m1_x+=*speed;
}
else if((*m1_x>=250)&&(*first_step==true)&&(*m1_y<=280))
{
    
*m1_x=250;
*m1_y=280;
*first_step=false;
*second_step=true;
}

//move mouse 1 in the forward directino acc. to step 2
if(*m1_x>=250&&(*m1_y>=280&&*m1_y<=390)&&(*second_step==true))
{
black_duck_down(*m1_x,*m1_y);
*m1_y+=*speed;
}
else if(*m1_x==250&&(*m1_y>=390)&&(*second_step==true))
{
*m1_y=390;

*second_step=false;
*third_step=true;
}


//move mouse 1 in the forward directino acc. to step 3

if((*m1_x>=250&&*m1_x<=370)&&(*third_step==true)&&(*m1_y<=390))
{
black_duck_right(*m1_x,*m1_y);
*m1_x+=*speed;
}
else if((*m1_x>=370)&&(*third_step==true)&&(*m1_y<=390))
{
*m1_x=370;
*m1_y=390;
*forward_dir=false;
*backward_dir=true;
}
}      


//______________________________________________BACKWARD DIRECTION IS TRUE _______________________________

else if(*backward_dir==true)
{

//move mouse 1 in the forward directino acc. to step 3

if((*m1_x>=250&&*m1_x<=370)&&(*third_step==true)&&(*m1_y<=390))
{
black_duck_left(*m1_x,*m1_y);
*m1_x-=*speed;
}
else if((*m1_x<=250)&&(*third_step==true)&&(*m1_y<=390))
{
*m1_x=250;
*m1_y=390;
*third_step=false;
*second_step=true;

}

//move mouse 1 in the forward directino acc. to step 2
if(*m1_x>=250&&(*m1_y>=280&&*m1_y<=390)&&(*second_step==true))
{
black_duck_up(*m1_x,*m1_y);
*m1_y-=*speed;
}
else if(*m1_x>=250&&(*m1_y<=280)&&(*second_step==true))
{
*m1_y=280;

*second_step=false;
*first_step=true;
}

//Move mouse 1 in forward diretion acc. to step 1
if((*m1_x>=130&&*m1_x<=250)&&(*first_step==true)&&(*m1_y<=280))
{
black_duck_left(*m1_x,*m1_y);
*m1_x-=*speed;
}
else if((*m1_x<=130)&&(*first_step==true)&&(*m1_y<=280))
{

*m1_x=130;
*m1_y=280;
*forward_dir=true;
*backward_dir=false;

}




}      

}





//______________________ Bottom LEFT Position Mouses ______________________

void derived_mouses::handle_bottom_left_egret(int m2_x,int m2_y,int color,bool forward_dir,bool backward_dir,bool first_step,bool second_step,bool third_step)
{
//spacing of 120 pxs b/w two horizontal mouses
//spacing of 110 pxs b/w two vertical mouses


if(forward_dir==true)
{


//Move mouse 1 in forward diretion acc. to step 1
if((m2_x>=130&&m2_x<=250)&&(first_step==true)&&(m2_y<=650))
egret_right(m2_x,m2_y,WHITE);


//Move mouse 1 in forward diretion acc. to step 1
 if(m2_x>=250&&(m2_y>=540&&m2_y<=650)&&(second_step==true))
egret_up(m2_x,m2_y,WHITE);

//Move mouse 1 in forward diretion acc. to step 1

 if((m2_x>=250&&m2_x<=370)&&(third_step==true)&&(m2_y>=540))
egret_right(m2_x,m2_y,WHITE);



}
else if(backward_dir==true)
{

//move mouse 1 in the forward directino acc. to step 3

if((m2_x>=250&&m2_x<=370)&&(third_step==true)&&(m2_y>=540))
egret_left(m2_x,m2_y,WHITE);

if(m2_x>=250&&(m2_y>=540&&m2_y<=650)&&(second_step==true))
egret_down(m2_x,m2_y,WHITE);

if((m2_x>=130&&m2_x<=250)&&(first_step==true)&&(m2_y<=650))
egret_left(m2_x,m2_y,WHITE);

}

      



}


//Bottom Left Mouses
void  derived_mouses_black::handle_black_bottom_left_egret(int *m2_x,int *m2_y,int *speed,bool *forward_dir,bool *backward_dir,bool *first_step,bool *second_step,bool *third_step)
{
      
      
if(*forward_dir==true)
{
                 
                      
//Move mouse 1 in forward diretion acc. to step 1
if((*m2_x>=130&&*m2_x<=250)&&(*first_step==true)&&(*m2_y<=650))
{
black_egret_right(*m2_x,*m2_y);
*m2_x+=*speed;
}
else if((*m2_x>=250)&&(*first_step==true)&&(*m2_y<=650))
{
    
*m2_x=250;
*m2_y=650;
*first_step=false;
*second_step=true;
}

//move mouse 1 in the forward directino acc. to step 2
if(*m2_x>=250&&(*m2_y>=540&&*m2_y<=650)&&(*second_step==true))
{
black_egret_up(*m2_x,*m2_y);
*m2_y-=*speed;
}
else if(*m2_x>=250&&(*m2_y<=540)&&(*second_step==true))
{
*m2_y=540;
*second_step=false;
*third_step=true;
}



//move mouse 1 in the forward directino acc. to step 3

if((*m2_x>=250&&*m2_x<=370)&&(*third_step==true)&&(*m2_y>=540))
{
black_egret_right(*m2_x,*m2_y);
*m2_x+=*speed;
}
else if((*m2_x>=370)&&(*third_step==true)&&(*m2_y>=540))
{
*m2_x=370;
*m2_y=540;
*forward_dir=false;
*backward_dir=true;
}

}   
   


//______________________________________________BACKWARD DIRECTION IS TRUE _______________________________



else if(*backward_dir==true)
{

//move mouse 1 in the forward directino acc. to step 3

if((*m2_x>=250&&*m2_x<=370)&&(*third_step==true)&&(*m2_y>=540))
{
black_egret_left(*m2_x,*m2_y);
*m2_x-=*speed;
}
else if((*m2_x<=250)&&(*third_step==true)&&(*m2_y>=540))
{
*m2_x=250;
*m2_y=540;
*third_step=false;
*second_step=true;
}


//move mouse 1 in the forward directino acc. to step 2
if(*m2_x>=250&&(*m2_y>=540&&*m2_y<=650)&&(*second_step==true))
{
black_egret_down(*m2_x,*m2_y);
*m2_y+=*speed;
}
else if(*m2_x>=250&&(*m2_y>=650)&&(*second_step==true))
{
*m2_y=650;
*second_step=false;
*first_step=true;
}


//Move mouse 1 in forward diretion acc. to step 1
if((*m2_x>=130&&*m2_x<=250)&&(*first_step==true)&&(*m2_y<=650))
{
black_egret_left(*m2_x,*m2_y);
*m2_x-=*speed;
}
else if((*m2_x<=130)&&(*first_step==true)&&(*m2_y<=650))
{
    
*m2_x=130;
*m2_y=650;
*forward_dir=true;
*backward_dir=false;
}

}


}










//_______________________Top  RIGHT Position Mouses ______________________


void derived_mouses::handle_top_right_rabbit(int m3_x,int m3_y,int color,bool forward_dir,bool backward_dir,bool first_step,bool second_step,bool third_step)
{
//spacing of 120 pxs b/w two horizontal mouses
//spacing of 110 pxs b/w two vertical mouses




if(forward_dir==true)
{

//move mouse 1 in the forward directino acc. to step 1

if((m3_x>=1000&&m3_x<=1120)&&(first_step==true)&&(m3_y<=390))
rabbit_right(m3_x,m3_y,WHITE);

//move mouse 1 in the forward directino acc. to step 2

if(m3_x>=1120&&(m3_y>=280&&m3_y<=390)&&(second_step==true))
rabbit_up(m3_x,m3_y,WHITE);

//move mouse 1 in the forward directino acc. to step 3
if((m3_x>=1120&&m3_x<=1240)&&(third_step==true)&&(m3_y>=280))
rabbit_right(m3_x,m3_y,WHITE);

                    

}
else if(backward_dir==true)
{

if((m3_x>=1120&&m3_x<=1240)&&(third_step==true)&&(m3_y>=280))
rabbit_left(m3_x,m3_y,WHITE);

if(m3_x>=1120&&(m3_y>=280&&m3_y<=390)&&(second_step==true))
rabbit_down(m3_x,m3_y,WHITE);

if((m3_x>=1000&&m3_x<=1120)&&(first_step==true)&&(m3_y<=390))
rabbit_left(m3_x,m3_y,WHITE);




}

      


/*
mouse_down(250,280+110,WHITE);
mouse_right(130+120+120,280+110,WHITE);
*/
}

void  derived_mouses_black::handle_black_top_right_rabbit(int *m3_x,int *m3_y,int *speed,bool *forward_dir,bool *backward_dir,bool *first_step,bool *second_step,bool *third_step)
{
      
      
if(*forward_dir==true)
{
  
      
                     
//Move mouse 1 in forward diretion acc. to step 1
if((*m3_x>=1000&&*m3_x<=1120)&&(*first_step==true)&&(*m3_y<=390))
{

black_rabbit_right(*m3_x,*m3_y);
*m3_x+=*speed;
}
else if((*m3_x>=1120)&&(*first_step==true)&&(*m3_y<=390))
{
    
*m3_x=1120;
*m3_y=390;
*first_step=false;
*second_step=true;
}


//move mouse 1 in the forward directino acc. to step 2
if(*m3_x>=1120&&(*m3_y>=280&&*m3_y<=390)&&(*second_step==true))
{
                                                               
black_rabbit_up(*m3_x,*m3_y);
*m3_y-=*speed;
}
else if(*m3_x>=1120&&(*m3_y<=280)&&(*second_step==true))
{
*m3_y=280;
*second_step=false;
*third_step=true;
}



if((*m3_x>=1120&&*m3_x<=1240)&&(*third_step==true)&&(*m3_y>=280))
{
black_rabbit_right(*m3_x,*m3_y);
*m3_x+=*speed;
}
else if((*m3_x>=1240)&&(*third_step==true)&&(*m3_y>=280))
{
*m3_x=1240;
*m3_y=280;
*forward_dir=false;
*backward_dir=true;
}

}   
   


//______________________________________________BACKWARD DIRECTION IS TRUE _______________________________



else if(*backward_dir==true)
{

//move mouse 1 in the forward directino acc. to step 3

if((*m3_x>=1120&&*m3_x<=1240)&&(*third_step==true)&&(*m3_y>=280))
{
black_rabbit_left(*m3_x,*m3_y);
*m3_x-=*speed;
}
else if((*m3_x<=1120)&&(*third_step==true)&&(*m3_y>=280))

{
*m3_x=1120;
*m3_y=280;
*third_step=false;
*second_step=true;
}


//move mouse 1 in the forward directino acc. to step 2
if(*m3_x>=1120&&(*m3_y>=280&&*m3_y<=390)&&(*second_step==true))
{
black_rabbit_down(*m3_x,*m3_y);
*m3_y+=*speed;
}
else if(*m3_x>=1120&&(*m3_y>=390)&&(*second_step==true))
{
*m3_y=390;
*second_step=false;
*first_step=true;
}


//Move mouse 1 in forward diretion acc. to step 1
if((*m3_x>=1000&&*m3_x<=1120)&&(*first_step==true)&&(*m3_y<=390))
{
black_rabbit_left(*m3_x,*m3_y);
*m3_x-=*speed;
}
else if((*m3_x<=1000)&&(*first_step==true)&&(*m3_y<=390))
{
    
*m3_x=1000;
*m3_y=390;
*forward_dir=true;
*backward_dir=false;
}

}


}










//_______________________Top  DOWN Position Mouses ______________________

void derived_mouses::handle_bottom_right_white_bird(int m4_x,int m4_y,int color,bool forward_dir,bool backward_dir,bool first_step,bool second_step,bool third_step)
{
     


if(forward_dir==true)
{


//Move mouse 1 in forward diretion acc. to step 1
if((m4_x>=1000&&m4_x<=1120)&&(first_step==true)&&(m4_y<=540))
white_bird_right(m4_x,m4_y,WHITE);


//Move mouse 1 in forward diretion acc. to step 1
else if(m4_x>=1120&&(m4_y>=540&&m4_y<=650)&&(second_step==true))
white_bird_down(m4_x,m4_y,WHITE);

//Move mouse 1 in forward diretion acc. to step 1

else if((m4_x>=1120&&m4_x<=1240)&&(third_step==true)&&(m4_y<=650))
white_bird_right(m4_x,m4_y,WHITE);



}
/*
//spacing of 120 pxs b/w two horizontal mouses
mouse_left(1240,650,WHITE);
mouse_left(1120,650,WHITE);

//spacing of 110 pxs b/w two vertical mouses
mouse_up(1120,540,WHITE);
mouse_left(1000,540,WHITE);
*/
    
    
//__________________________ BACKWARD DIRECTION IS TRUE __________________

else if(backward_dir==true)
{
//move mouse 1 in the forward directino acc. to step 3

if((m4_x>=1120&&m4_x<=1240)&&(third_step==true)&&(m4_y<=650))
white_bird_left(m4_x,m4_y,WHITE);
//move mouse 1 in the forward directino acc. to step 2

else if(m4_x>=1120&&(m4_y>=540&&m4_y<=650)&&(second_step==true))
white_bird_up(m4_x,m4_y,WHITE);
//Move mouse 1 in forward diretion acc. to step 1

else if((m4_x>=1000&&m4_x<=1120)&&(first_step==true)&&(m4_y<=540))
white_bird_left(m4_x,m4_y,WHITE);


}


}




void derived_mouses_black:: handle_black_bottom_right_white_bird(int *m4_x,int *m4_y,int *speed,bool *forward_dir,bool *backward_dir,bool *first_step,bool *second_step,bool *third_step)
{
     
       

  
if(*forward_dir==true)
{
//Move mouse 1 in forward diretion acc. to step 1
if((*m4_x>=1000&&*m4_x<=1120)&&(*first_step==true)&&(*m4_y<=540))
{
black_white_bird_right(*m4_x,*m4_y);
*m4_x+=*speed;
}
else if((*m4_x>=1120)&&(*first_step==true)&&(*m4_y<=540))
{
    
*m4_x=1120;
*m4_y=540;
*first_step=false;
*second_step=true;
}

//move mouse 1 in the forward directino acc. to step 2
 if(*m4_x>=1120&&(*m4_y>=540&&*m4_y<=650)&&(*second_step==true))
{
black_white_bird_down(*m4_x,*m4_y);
*m4_y+=*speed;
}
else if(*m4_x>=1120&&(*m4_y>=650)&&(*second_step==true))
{
*m4_y=650;

*second_step=false;
*third_step=true;
}


//move mouse 1 in the forward directino acc. to step 3

if((*m4_x>=1120&&*m4_x<=1240)&&(*third_step==true)&&(*m4_y<=650))
{
black_white_bird_right(*m4_x,*m4_y);
*m4_x+=*speed;
}
else if((*m4_x>=1240)&&(*third_step==true)&&(*m4_y<=650))
{
*m4_x=1240;
*m4_y=650;
*forward_dir=false;
*backward_dir=true;
}
}      


//______________________________________________BACKWARD DIRECTION IS TRUE _______________________________

else if(*backward_dir==true)
{

//move mouse 1 in the forward directino acc. to step 3

if((*m4_x>=1120&&*m4_x<=1240)&&(*third_step==true)&&(*m4_y<=650))
{
black_white_bird_left(*m4_x,*m4_y);
*m4_x-=*speed;
}
else if((*m4_x<=1120)&&(*third_step==true)&&(*m4_y<=650))
{
*m4_x=1120;
*m4_y=650;
*third_step=false;
*second_step=true;

}

//move mouse 1 in the forward directino acc. to step 2
if(*m4_x>=1120&&(*m4_y>=540&&*m4_y<=650)&&(*second_step==true))
{
black_white_bird_up(*m4_x,*m4_y);
*m4_y-=*speed;
}
else if(*m4_x>=1120&&(*m4_y<=540)&&(*second_step==true))
{
*m4_y=540;

*second_step=false;
*first_step=true;
}

//Move mouse 1 in forward diretion acc. to step 1
if((*m4_x>=1000&&*m4_x<=1120)&&(*first_step==true)&&(*m4_y<=540))
{
black_white_bird_left(*m4_x,*m4_y);
*m4_x-=*speed;
}
else if((*m4_x<=1000)&&(*first_step==true)&&(*m4_y<=540))
{

*m4_x=1000;
*m4_y=540;
*forward_dir=true;
*backward_dir=false;

}




}    
}

     
     


//Top Center

void derived_mouses::handle_mouse_upper(int *m5_x,int *m5_y,int *color,bool *forward_dir,bool *backward_dir,bool *first_step,bool *second_step,bool *third_step,bool *fourth_step)       
{
if(*forward_dir==true)
{
if((*m5_x>=520&&*m5_x<=880)&&(*m5_y<=280)&&(*first_step==true))
{
mouse_right(*m5_x,*m5_y,WHITE);
}
else if((*m5_x>=520)&&(*m5_y>=280&&*m5_y<=390)&&(*second_step==true))
mouse_down(*m5_x,*m5_y,WHITE);

else if((*m5_x>=520&&*m5_x<=880)&&(*m5_y<=390)&&(*third_step==true))
mouse_left(*m5_x,*m5_y,WHITE);

/*
*m5_x=520;
*m5_y=290;
*/  

else if((*m5_x>=520)&&(*m5_y>=280&&*m5_y<=390)&&(*fourth_step==true))
{
mouse_up(*m5_x,*m5_y,WHITE);
}

}  

else if(*backward_dir==true)
{
     
if((*m5_x>=520&&*m5_x<=880)&&(*m5_y<=280)&&(*first_step==true))
mouse_left(*m5_x,*m5_y,WHITE);

else if((*m5_x>=520)&&(*m5_y>=280&&*m5_y<=390)&&(*second_step==true))
mouse_down(*m5_x,*m5_y,WHITE);

else if((*m5_x>=520&&*m5_x<=880)&&(*m5_y<=390)&&(*third_step==true))
mouse_right(*m5_x,*m5_y,WHITE);

else if((*m5_x>=880)&&(*m5_y>=280&&*m5_y<=390)&&(*fourth_step==true))
mouse_up(*m5_x,*m5_y,WHITE);
  

}
   
}      


void derived_mouses_black::handle_black_mouse_upper(int *m5_x,int *m5_y,int *speed,bool *forward_dir,bool *backward_dir,bool *first_step,bool *second_step,bool *third_step,bool *fourth_step)       
      

{

//_______________________Top  MIDDLE Position Mouses ______________________

//spacing of 120 pxs b/w two horizontal mouses

if(*forward_dir==true)
{
if((*m5_x>=520&&*m5_x<=880)&&(*m5_y<=280)&&(*first_step==true))
{
black_mouse_right(*m5_x,*m5_y);
*m5_x+=*speed;
}
else if((*m5_x>=880)&&(*m5_y<=280)&&(*first_step==true))
{
*m5_x=880;
*m5_y=280;
*first_step=false;
*second_step=true;
}


/*
//top row of mouses
mouse_right(520,280,WHITE);
mouse_right(640,280,WHITE);
mouse_right(760,280,WHITE);
mouse_right(880,280,WHITE);

//top down mouse
mouse_down(880,390,WHITE);
*/

if((*m5_x>=520)&&(*m5_y>=280&&*m5_y<=390)&&(*second_step==true))
{
black_mouse_down(*m5_x,*m5_y);
*m5_y+=*speed;
}
else if((*m5_x>=520)&&(*m5_y>=390)&&(*second_step==true))
{
*m5_y=390;
*second_step=false;
*third_step=true;
}




/*
//bottom row of mouses
mouse_left(770,390,WHITE);
mouse_left(650,390,WHITE);
mouse_left(530,390,WHITE);
*/

if((*m5_x>=520&&*m5_x<=880)&&(*m5_y<=390)&&(*third_step==true))
{
black_mouse_left(*m5_x,*m5_y);
*m5_x-=*speed;
}
else if((*m5_x<=520)&&(*m5_y<=390)&&(*third_step==true))
{
*m5_x=520;
*m5_y=390;

*third_step=false;
*fourth_step=true;
}


if((*m5_x>=520)&&(*m5_y>=280&&*m5_y<=390)&&(*fourth_step==true))
{
black_mouse_up(*m5_x,*m5_y);
*m5_y-=*speed;
}
else if((*m5_x>=520)&&(*m5_y<=280)&&(*fourth_step==true))
{
*m5_x=520;
*m5_y=280;
*fourth_step=false;
*first_step=true;
}


//middle up and down mouses
//mouse_up(470,290,WHITE);

}

else if(*backward_dir==true)
{
if((*m5_x>=520&&*m5_x<=880)&&(*m5_y<=280)&&(*first_step==true))
{
black_mouse_left(*m5_x,*m5_y);
*m5_x-=*speed;
}
else if((*m5_x<=520)&&(*m5_y<=280)&&(*first_step==true))
{
*m5_x=520;
*m5_y=280;
*first_step=false;
*second_step=true;
}


/*
//top row of mouses
mouse_right(520,280,WHITE);
mouse_right(640,280,WHITE);
mouse_right(760,280,WHITE);
mouse_right(880,280,WHITE);

//top down mouse
mouse_down(880,390,WHITE);
*/

if((*m5_x>=520)&&(*m5_y>=280&&*m5_y<=390)&&(*second_step==true))
{
black_mouse_down(*m5_x,*m5_y);
*m5_y+=*speed;
}
else if((*m5_x>=520)&&(*m5_y>=390)&&(*second_step==true))
{
*m5_y=390;
*second_step=false;
*third_step=true;
}




/*
//bottom row of mouses
mouse_left(770,390,WHITE);
mouse_left(650,390,WHITE);
mouse_left(530,390,WHITE);
*/

if((*m5_x>=520&&*m5_x<=880)&&(*m5_y<=390)&&(*third_step==true))
{
black_mouse_right(*m5_x,*m5_y);
*m5_x+=*speed;
}
else if((*m5_x>=880)&&(*m5_y<=390)&&(*third_step==true))
{
*m5_x=880;
*m5_y=390;

*third_step=false;
*fourth_step=true;
}


if((*m5_x>=880)&&(*m5_y>=280&&*m5_y<=390)&&(*fourth_step==true))
{
black_mouse_up(*m5_x,*m5_y);
*m5_y-=*speed;
}
else if((*m5_x>=880)&&(*m5_y<=280)&&(*fourth_step==true))
{
*m5_x=880;
*m5_y=280;
*fourth_step=false;
*first_step=true;
}


//middle up and down mouses
//mouse_up(470,290,WHITE);

}

}




void derived_mouses::handle_flying_rooster_lower(int *m6_x,int *m6_y,int *color,bool *forward_dir,bool *backward_dir,bool *first_step,bool *second_step,bool *third_step,bool *fourth_step)       
{
if(*backward_dir==true)
{

if((*m6_x>=520&&*m6_x<=880)&&(*m6_y>=540)&&(*first_step==true))
flying_rooster_left(*m6_x,*m6_y,WHITE);

else if((*m6_x>=520)&&(*m6_y>=540&&*m6_y<=650)&&(*second_step==true))
flying_rooster_down(*m6_x,*m6_y,WHITE);

else if((*m6_x>=520&&*m6_x<=880)&&(*m6_y<=650)&&(*third_step==true))
flying_rooster_right(*m6_x,*m6_y,WHITE);

else if((*m6_x>=520)&&(*m6_y>=540&&*m6_y<=650)&&(*fourth_step==true))
flying_rooster_up(*m6_x,*m6_y,WHITE);


}   

else if(*forward_dir==true)
{
if((*m6_x>=520&&*m6_x<=880)&&(*m6_y>=540)&&(*first_step==true))
flying_rooster_right(*m6_x,*m6_y,WHITE);

else if((*m6_x>=880)&&(*m6_y>=540&&*m6_y<=650)&&(*second_step==true))
flying_rooster_down(*m6_x,*m6_y,WHITE);

else if((*m6_x>=520&&*m6_x<=880)&&(*m6_y<=650)&&(*third_step==true))
flying_rooster_left(*m6_x,*m6_y,WHITE);

else if((*m6_x>=520)&&(*m6_y>=540&&*m6_y<=650)&&(*fourth_step==true))
flying_rooster_up(*m6_x,*m6_y,WHITE);

}  
}      






void derived_mouses_black::handle_black_flying_rooster_lower(int *m6_x,int *m6_y,int *speed,bool *forward_dir,bool *backward_dir,bool *first_step,bool *second_step,bool *third_step,bool *fourth_step)       

{



//_______________________Top  MIDDLE Position Mouses ______________________

//spacing of 120 pxs b/w two horizontal mouses

if(*backward_dir==true)
{
if((*m6_x>=520&&*m6_x<=880)&&(*m6_y>=540)&&(*first_step==true))
{
black_flying_rooster_left(*m6_x,*m6_y);
*m6_x-=*speed;
}
else if((*m6_x<=520)&&(*m6_y>=540)&&(*first_step==true))
{
*m6_x=520;
*m6_y=540;

*first_step=false;
*second_step=true;
}


/*
//top row of mouses
mouse_right(520,280,WHITE);
mouse_right(640,280,WHITE);
mouse_right(760,280,WHITE);
mouse_right(880,280,WHITE);

//top down mouse
mouse_down(880,390,WHITE);
*/

if((*m6_x>=520)&&(*m6_y>=540&&*m6_y<=650)&&(*second_step==true))
{
black_flying_rooster_down(*m6_x,*m6_y);
*m6_y+=*speed;
}
else if((*m6_x>=520)&&(*m6_y>=650)&&(*second_step==true))
{
*m6_y=650;
*second_step=false;
*third_step=true;
}




/*
//bottom row of mouses
mouse_left(770,390,WHITE);
mouse_left(650,390,WHITE);
mouse_left(530,390,WHITE);
*/

if((*m6_x>=520&&*m6_x<=880)&&(*m6_y<=650)&&(*third_step==true))
{
black_flying_rooster_right(*m6_x,*m6_y);
*m6_x+=*speed;
}
else if((*m6_x>=880)&&(*m6_y<=650)&&(*third_step==true))
{
*m6_y=650;
*m6_x=880;
*third_step=false;
*fourth_step=true;
}


if((*m6_x>=520)&&(*m6_y>=540&&*m6_y<=650)&&(*fourth_step==true))
{



black_flying_rooster_up(*m6_x,*m6_y);
*m6_y-=*speed;
}
else if((*m6_x>=520)&&(*m6_y<=540)&&(*fourth_step==true))
{
*m6_y=540;
*fourth_step=false;
*first_step=true;
}


//middle up and down mouses
//mouse_up(470,290,WHITE);

}

else if(*forward_dir==true)
{
if((*m6_x>=520&&*m6_x<=880)&&(*m6_y>=540)&&(*first_step==true))
{
black_flying_rooster_right(*m6_x,*m6_y);
*m6_x+=*speed;
}
else if((*m6_x>=880)&&(*m6_y>=540)&&(*first_step==true))
{
*m6_x=880;
*m6_y=540;

*first_step=false;
*second_step=true;
}



if((*m6_x>=880)&&(*m6_y>=540&&*m6_y<=650)&&(*second_step==true))
{
black_flying_rooster_down(*m6_x,*m6_y);
*m6_y+=*speed;
}
else if((*m6_x>=880)&&(*m6_y>=650)&&(*second_step==true))
{
*m6_y=650;
*second_step=false;
*third_step=true;
}




/*
//bottom row of mouses
mouse_left(770,390,WHITE);
mouse_left(650,390,WHITE);
mouse_left(530,390,WHITE);
*/

if((*m6_x>=520&&*m6_x<=880)&&(*m6_y<=650)&&(*third_step==true))
{
black_flying_rooster_left(*m6_x,*m6_y);
*m6_x-=*speed;
}
else if((*m6_x<=520)&&(*m6_y<=650)&&(*third_step==true))
{
*m6_x=520;
*m6_y=650;
*third_step=false;
*fourth_step=true;
}


if((*m6_x>=520)&&(*m6_y>=540&&*m6_y<=650)&&(*fourth_step==true))
{
black_flying_rooster_up(*m6_x,*m6_y);
*m6_y-=*speed;
}
else if((*m6_x>=520)&&(*m6_y<=540)&&(*fourth_step==true))
{
*m6_y=540;
*fourth_step=false;
*first_step=true;
}


//middle up and down mouses
//mouse_up(470,290,WHITE);

}
}


/*





void derived_mouses::handle_7th_mouse()
{


// ______________________Top LEFT L shapes Mouses _______________________

//spacing of 120 pxs b/w two horizontal mouses
//spacing of 110 pxs b/w two vertical mouses


// for making row of left mouses
mouse_left(130+120+80,280+110+80,WHITE);
mouse_left(130+120-120+80,280+110+80,WHITE);
mouse_left(130+120-120-120+80,280+110+80,WHITE);

mouse_up(130-40,280+110+80-110,WHITE);

}

void derived_mouses::handle_8th_mouse()
{


// ______________________BOTTOM RIGHT L shapes Mouses _______________________

// for making row of right mouses
mouse_right(130,280+110+80+80,WHITE);
mouse_right(130+120,280+110+80+80,WHITE);
mouse_right(130+120+120,280+110+80+80,WHITE);

mouse_up(130-60,280+110+80+80+60,WHITE);


}


void derived_mouses::handle_9th_mouse()
{




// ______________________Top LEFT L shapes Mouses _______________________

//spacing of 120 pxs b/w two horizontal mouses
//spacing of 110 pxs b/w two vertical mouses


// for making row of left mouses
mouse_left(1240-120+120,280+110+80,WHITE);
mouse_left(1240-120-120+120,280+110+80,WHITE);
mouse_left(1240-120-120-120+120,280+110+80,WHITE);

mouse_down(1240-120+120+40,280+110+80-70,WHITE);


}

void derived_mouses::handle_10th_mouse()
{

// ______________________BOTTOM RIGHT L shapes Mouses _______________________

// for making row of right mouses
mouse_right(1240+40,280+110+80+80,WHITE);
mouse_right(1240-120+40,280+110+80+80,WHITE);
mouse_right(1240-120-120+40,280+110+80+80,WHITE);

mouse_down(1240+40,280+110+80+80+60+50,WHITE);


}

//_________________________________________________________________________________________________________________

*/
