#include "abhishek.h"





void snake_collison_with_prediators(int i,int k,int eagle_x,int eagle_y,int tail_x[1000],int tail_y[1000],char *file_name,char *name,char *score,char *lifes,char *level,int speed)
{
int length;
int temp_life;
for(length=k;length<i-1;length++)
if((eagle_x+50>=tail_x[length]&&eagle_x-50<=tail_x[length])&&(eagle_y-50<=tail_y[length]&&eagle_y+50>=tail_y[length]))
{
readimagefile("screen\\snake is being hunted by prediators.jpg",300,370,300+744,370+219);
delay(2000);

temp_life=atoi(lifes);
if(temp_life==1)
{
readimagefile("screen\\black snake is being hunted by prediators.jpg",300,370,300+744,370+219);
readimagefile("screen\\game over.jpg",500,400,500+346,400+81);
delay(2000);
encrypt_decrypt(file_name);

exit(1); 

}
--temp_life;
itoa(temp_life,lifes,10);



//UPDATE PROFILE
ofstream write;
write.open(file_name,ios::out);
//___data entering format - > name<<score<<lifes<<level ____
write<<name<<"^"<<score<<"^"<<lifes<<"^"<<level<<"^";
write.close();

access_profile_data(file_name,name,score,lifes,level);
cleardevice();
start_game(file_name,name,score,lifes,level,speed);
                                                                                                                     

}
}
