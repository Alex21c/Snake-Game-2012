

#ifndef SNAKEHEAD_H
#define SNAKEHEAD_H

void snake_left_head(int temp_head_x,int temp_head_y);
void snake_upper_head(int temp_head_x,int temp_head_y);
void snake_right_head(int temp_head_x,int temp_head_y);
void snake_right_head_black(int temp_head_x,int temp_head_y);
void snake_left_head_black(int temp_head_x,int temp_head_y);

void snake_upper_head_black(int temp_head_x,int temp_head_y);
void snake_lower_head(int temp_head_x,int temp_head_y);
void snake_lower_head_black(int temp_head_x,int temp_head_y);





#endif
