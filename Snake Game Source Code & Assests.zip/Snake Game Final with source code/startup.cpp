#include "abhishek.h"
#include "levels.h"





//_______________________ IF user had not pressed EXIT KEY then start game ________________
void start_game(char file_name[100],char name[100],char score[10],char lifes[5],char level[5],int speed)
{       
       
       
if(chance_1==true)
{
chance_1=false;
readimagefile("screen\\level 1.jpg",10,10,1350,760);
delay(2000);
cleardevice();
}
        
screen(file_name);
snake(file_name,name,score,lifes,level,speed);   

}

void place_cursor(int y_position)
{
setcolor(WHITE);
outtextxy(600,y_position,"*");
}

void erase_cursor(int y_position)
{
setcolor(BLACK);
outtextxy(600,y_position,"*");
}


//___________Startup User Screen ___________
void startup_user_screen(bool *exit_game,char *file_name)
{
     
chance_1=true;

int speed=100;
initwindow(1366,768,"",-3,-3,false,false);

char name[100],name2[100],name3[100],score[100],lifes[100],level[100];

back:
cleardevice();
readimagefile("king cobra.jpg",100,175,500,675);

//========================= Drawing Boundary in the form of rectangle for the top header ===============
setcolor(COLOR(142,56,142));
setlinestyle(SOLID_LINE,SOLID_LINE,2);
rectangle(6,6,1358,760);


//=====================================Displaying Snake game at the top of the HOME SCREEN ================

//_____ SNAKE  ________
settextjustify(LEFT_TEXT,TOP_TEXT);
setlinestyle(SOLID_LINE,SOLID_LINE,1);
setcolor(COLOR(0,255,0));
settextstyle(EUROPEAN_FONT,HORIZ_DIR,10);
outtextxy(200,10,"S");

setcolor(COLOR(255,0,0));
outtextxy(200+128-25,10,"n");

setcolor(COLOR(0,0,255));
outtextxy(200+(2*128)-(25*2),10,"a");

setcolor(COLOR(255,153,18));
outtextxy(200+(3*128)-(25*3),10,"k");

setcolor(COLOR(142,56,142));
outtextxy(200+(4*128)-(25*4),10,"e");


//_______GAME____________

setcolor(COLOR(0,255,0));
outtextxy(200+(5*128)-(25*3),10,"G");

setcolor(COLOR(255,0,0));
outtextxy(200+(6*128)-(25*2)-10,10,"a");

setcolor(COLOR(0,0,255));
outtextxy(200+(7*128)-(25*3)-10,10,"m");

setcolor(COLOR(255,153,18));
outtextxy(200+(8*128)-(25*3)+5,10,"e");


setcolor(WHITE);
settextstyle(SIMPLEX_FONT,HORIZ_DIR,6);
settextjustify(LEFT_TEXT,TOP_TEXT);

setcolor(COLOR(0,201,87));
outtextxy(683,200,"New Game");

setcolor(COLOR(255,62,150)); 

outtextxy(683,280,"Load Game");

setcolor(WHITE);
outtextxy(683,360,"High Score");

setcolor(COLOR(0,191,255));
outtextxy(683,440,"Options");

setcolor(COLOR(255,215,0));
outtextxy(683,520,"About Game");

setcolor(COLOR(0,201,87));
outtextxy(683,600,"Credits");

setcolor(COLOR(250,5,7));
outtextxy(683,680,"Exit");





settextstyle(DEFAULT_FONT,HORIZ_DIR,2);
setcolor(COLOR(255,0,0));
outtextxy(50,710," By : ");
setcolor(COLOR(0,255,0));
outtextxy(150,710,"Anonymous Group");

setcolor(COLOR(0,0,255));
rectangle(30,700,400,735);


setcolor(COLOR(142,56,142));
setlinestyle(SOLID_LINE,SOLID_LINE,1);
rectangle(6+6,6+4,1358-6,760-6);


int y_position=200;



int i,j;

char temp[3];



//___________________moving cursor______________


char key='t';
int distance= 660;

settextstyle(SIMPLEX_FONT,HORIZ_DIR,6);

place_cursor(y_position);



//________________________________________________WHILE LOOP STARTS ________________________
while(key!=ENTER)
{
key=getch();
if(key==ENTER)
break;
else if(key==ESCAPE)
exit(1);
else if(key<=0)
{
key=getch();

//_______________________ Move Cursor Upward if user pressed UP arrow key ___________________
if(key==UP)
{
erase_cursor(y_position);
if(y_position!=200)
y_position-=80;
else
y_position=680;
place_cursor(y_position);        
}
// _________________________________Cursor Moved UP sucessfully ____________________________

//_______________________ Move Cursor Upward if user pressed UP arrow key ___________________
else if(key==DOWN)
{


erase_cursor(y_position);
if(y_position!=680)
y_position+=80;
else
y_position=200;
place_cursor(y_position);
}
// _________________________________Cursor Moved UP sucessfully ____________________________

}
}
//________________________________WHILE LOOP ENDS User presses ENTER KEY________________________


//---------------------------------------- SEPERATOR BAR  ----------------------------------------



//_________________________Check whether user pressed enter key or not ____________________

if(key==ENTER)
{

//________________________User PRESSED enter key in front of EXIT OPTION _______________________
if(y_position==680)
{
cleardevice();
//constructing HEADER BOUNDARY
readimagefile("screen\\exit outer boundary.jpg",10,10,1350,760);


readimagefile("screen\\good by.jpg",500,350,500+380,350+94);


*exit_game = true;
int tx=900,ty=410;
for(i=1;i<=3;i++)
{

readimagefile("screen\\dot.jpg",tx,ty,tx+15,ty+13);
tx+=50;
delay(500);
}
exit(1);

}
//Presses Enter infront of Credits screen 
else if(y_position==600)
{
cleardevice();


//constructing HEADER BOUNDARY
readimagefile("screen\\credits screen.jpg",10,10,1350,760);

int cx=270,cy=660;

readimagefile("screen\\check sign.jpg",cx,cy,cx+42,cy+38);
/*
cx=700,cy=660;

readimagefile("screen\\check sign.jpg",cx,cy,cx+42,cy+38);
*/

key='a';
while(key!=ENTER)
{
key=getch();
if(key==ESCAPE)
goto back;
else if(key==ENTER)
{
if(cx==700)
exit(1);
else
goto back;              
}

key=getch();

//_______________________ Move Cursor Upward if user pressed UP arrow key ___________________
if(key==LEFT)
{
readimagefile("screen\\black check sign.jpg",cx,cy,cx+42,cy+38);

if(cx==700)
cx=270;

readimagefile("screen\\check sign.jpg",cx,cy,cx+42,cy+38);
}
// _________________________________Cursor Moved UP sucessfully ____________________________

//_______________________ Move Cursor Upward if user pressed UP arrow key ___________________
else if(key==RIGHT)
{
readimagefile("screen\\black check sign.jpg",cx,cy,cx+42,cy+38);

if(cx==270)
cx=700;

readimagefile("screen\\check sign.jpg",cx,cy,cx+42,cy+38);

}
// _________________________________Cursor Moved UP sucessfully ____________________________

}
}
else if(y_position==440)
{
cleardevice();


//constructing HEADER BOUNDARY
readimagefile("screen\\option screen.jpg",10,10,1350,760);

int cx=100,cy=330;

readimagefile("screen\\spade.jpg",cx,cy,cx+39,cy+42);

//cx=100,cy=490;

//readimagefile("screen\\spade.jpg",cx,cy,cx+39,cy+42);


key='a';
//key=ENTER;
while(key!=ENTER)
{
key=getch();
if(key==ESCAPE)
goto back;
else if(key==ENTER)
{

if(cy==330)
{
cleardevice();
cx=70,cy=275;

readimagefile("screen\\speed settings.jpg",10,10,1350,760);
readimagefile("screen\\thunder.jpg",cx,cy,cx+81,cy+82);




key='a';
while(key!=ENTER)
{
key=getch();
if(key==ESCAPE)
goto back;
else if(key==ENTER)
{
//cy=275
//cy=410;
//cy=545;

//begineer 100
//intermediate 60
//advanced 20

if(cy==275)
{
speed = 100; 
}
else if(cy==410)
{
speed = 60;
}
else if(cy==545)
{
speed = 20; 
}


goto back;              

}

key=getch();

//_______________________ Move Cursor Upward if user pressed UP arrow key ___________________




if(key==DOWN)
{
readimagefile("screen\\black thunder.jpg",cx,cy,cx+81,cy+82);


//330 490
if(cy==275)
cy=410;
else if(cy==410)
cy=545;
else if(cy==545)
cy=275;


readimagefile("screen\\thunder.jpg",cx,cy,cx+81,cy+82);


}
// _________________________________Cursor Moved UP sucessfully ____________________________

//_______________________ Move Cursor Upward if user pressed UP arrow key ___________________
else if(key==UP)
{
readimagefile("screen\\black thunder.jpg",cx,cy,cx+81,cy+82);

if(cy==545)
cy=410;
else if(cy==410)
cy=275;
else if(cy==275)
cy=545;


readimagefile("screen\\thunder.jpg",cx,cy,cx+81,cy+82);

}
// _________________________________Cursor Moved UP sucessfully ____________________________

}



exit(1);
}
//************************//
else
goto back;              
}

key=getch();

//_______________________ Move Cursor Upward if user pressed UP arrow key ___________________
if(key==DOWN)
{
readimagefile("screen\\black spade.jpg",cx,cy,cx+39,cy+42);
//330 490
if(cy==330)
cy=490;
else if(cy==490)
cy=330;



readimagefile("screen\\spade.jpg",cx,cy,cx+39,cy+42);
}
// _________________________________Cursor Moved UP sucessfully ____________________________

//_______________________ Move Cursor Upward if user pressed UP arrow key ___________________
else if(key==UP)
{
readimagefile("screen\\black spade.jpg",cx,cy,cx+39,cy+42);

if(cy==490)
cy=330;
else if(cy==330)
cy=490;


readimagefile("screen\\spade.jpg",cx,cy,cx+39,cy+42);

}
// _________________________________Cursor Moved UP sucessfully ____________________________

}






}



//______________________  Displaying good by and exiting ______________________//


//---------------------------------------- SEPERATOR BAR  ----------------------------------------


else if(y_position==520)
{


previous:
cleardevice();
readimagefile("screen\\about game menu.jpg",10,10,1350,760);
char KEY;
KEY='a';
int cx=100,cy=300;


readimagefile("screen\\pdot.jpg",cx,cy,cx+37,cy+36);



//KEY=ENTER;
while(KEY!=ENTER)
{
KEY=getch();

if(KEY==ESCAPE)
{
goto back;
}
else if(KEY==ENTER)
{

//cy=300;
//cy=430;
//cy=560;

if(cy==560)
{
goto back;
}
else if(cy==430)
{
previous_1:
readimagefile("screen\\characters menu.jpg",10,10,1350,760);
KEY='a';
int cx=100,cy=300;

readimagefile("screen\\pdot.jpg",cx,cy,cx+37,cy+36);

while(KEY!=ENTER)
{
KEY=getch();

if(KEY==ESCAPE)
{
goto previous;
}
else if(KEY==ENTER)
{
if(cy==300)
{
readimagefile("screen\\preys.jpg",10,10,1350,760);
while(KEY!=ESCAPE)
{
KEY=getch();
if(KEY==ESCAPE)
goto previous_1;

}

}
else if(cy==430)
{
readimagefile("screen\\prediators.jpg",10,10,1350,760);
while(KEY!=ESCAPE)
{
KEY=getch();
if(KEY==ESCAPE)
goto previous_1;

}

}



}

if(KEY==DOWN)
{
readimagefile("screen\\black pdot.jpg",cx,cy,cx+37,cy+36);
//330 490
if(cy==300)
cy=430;
else if(cy==430)
cy=300;



readimagefile("screen\\pdot.jpg",cx,cy,cx+37,cy+36);
}
// _________________________________Cursor Moved UP sucessfully ____________________________

//_______________________ Move Cursor Upward if user pressed UP arrow KEY ___________________
else if(KEY==UP)
{
readimagefile("screen\\black pdot.jpg",cx,cy,cx+37,cy+36);
//cy=300;
//cy=430;
//cy=560;


if(cy==430)
cy=300;
else if(cy==300)
cy=430;



readimagefile("screen\\pdot.jpg",cx,cy,cx+37,cy+36);

}

}


}            
else if(cy==300)
{
readimagefile("screen\\controllers.jpg",10,10,1350,760);
while(KEY!=ESCAPE)
{
KEY=getch();
if(KEY==ESCAPE)
goto previous;

}

}

}





//cy=300;
//cy=430;
//cy=560;

//_______________________ Move Cursor Upward if user pressed UP arrow KEY ___________________

KEY=getch();
if(KEY==DOWN)
{
readimagefile("screen\\black pdot.jpg",cx,cy,cx+37,cy+36);
//330 490
if(cy==300)
cy=430;
else if(cy==430)
cy=560;
else if(cy==560)
cy=300;



readimagefile("screen\\pdot.jpg",cx,cy,cx+37,cy+36);
}
// _________________________________Cursor Moved UP sucessfully ____________________________

//_______________________ Move Cursor Upward if user pressed UP arrow KEY ___________________
else if(KEY==UP)
{
readimagefile("screen\\black pdot.jpg",cx,cy,cx+37,cy+36);
//cy=300;
//cy=430;
//cy=560;

if(cy==560)
cy=430;
else if(cy==430)
cy=300;
else if(cy==300)
cy=560;



readimagefile("screen\\pdot.jpg",cx,cy,cx+37,cy+36);

}

// _________________________________Cursor Moved UP sucessfully ____________________________

}



}

//<<<<<<<<<<<<<<@@@@@@@@@@@@@@@!!!!!!!!!!!!!!!!!!!!!!!!!!>>>>>>>>>>>>>>>>>>>>>>>>>>





















//_____________________ PRESSES ENTER INFRONT OF HIGH SCORE _________________
else if (y_position==360)
{
cleardevice();

readimagefile("screen\\honor screen.jpg",10,10,1350,760);


//decrypt file -> all files.dat
score_encryption_decryption("Master file\\all files.dat");





//------------------------------------------//
ifstream read;

char names[100][100];
int i=1,n;

char profile[100]="profiles\\";

char temp[100];


char actual_names[100][100];




char aaaa[100];

//opening all files & update it
read.open("Master file\\all files.dat",ios::in);
//reading data from file

while(read.eof()==0)
{
read.getline(names[i],50,'\n');
n=i;
++i;
}

read.close();


//modifing names data along with path 
for(i=1;i<=n-1;i++)
{
strcpy(temp,profile);
strcat(temp,names[i]);
strcpy(actual_names[i],temp);

encrypt_decrypt(actual_names[i]);                                    


temp[0]='\0';

}

/*
//accessing data from all files 

for(i=1;i<=n-1;i++)
{

access_profile_data(actual_names[i],name,score,lifes,level);
outtext(score);
outtext(" ");

}
*/




char temp_score[100][50];






//Obtaining and coping scroes in temp_score;
for(i=1;i<=n-1;i++)
{
access_profile_data(actual_names[i],name,score,lifes,level);

strcpy(temp_score[i],score);

}



/*-------- strcmp() function reference --------

returns
< 0 str1 is greater than str2
> 0 str2 is greater than str1
= 0 str is equal to str2


*/



//convertig text into integers
int t_temp[100],t_t_temp;

char msg[100];
for(i=1;i<=n-1;i++)
{
t_temp[i]=atoi(temp_score[i]);
}



//Now use BUBBLE SORT for sorting of data



char anonymous[100];

for(i=1;i<=n-1;i++)
{
for(j=i+1;j<=n-1;j++)
{
if(t_temp[i]<t_temp[j]) //str 1 is greater than str2
{
t_t_temp=t_temp[i];
t_temp[i]=t_temp[j];
t_temp[j]=t_t_temp;


strcpy(anonymous,actual_names[i]);
strcpy(actual_names[i],actual_names[j]);
strcpy(actual_names[j],anonymous);

}
}                   

}






//sorting done sucessfully



//checking done sucessfully

//Now displaying top 5 Winners



int z;

if(n-1<=5)
z=n-1;
else 
z=5;

//Displaying data on screen

int colors[5]={COLOR(255,197,21),COLOR(255,61,164),COLOR(47,230,130),COLOR(121,55,171),COLOR(255,255,255)};

settextstyle(DEFAULT_FONT,HORIZ_DIR,4);



int x,y=330;

for(i=1;i<=z;i++)
{

setcolor(colors[i-1]);

//access profile data
access_profile_data(actual_names[i],name,score,lifes,level);

if(i==1)
{
ofstream  write;
write.open("Master file\\Master file.dat",ios::out);
write<<score;
write.close();
}


x=120;
//display name and rank
sprintf(msg,"%d.  %s",i,name);                 
outtextxy(x,y,msg);

x=710;
//display score
sprintf(msg,"%s",score);                 
outtextxy(x,y,msg);

x=960;
//display score
sprintf(msg,"%s",lifes);                 
outtextxy(x,y,msg);

x=1200;
//display score
sprintf(msg,"%s",level);                 
outtextxy(x,y,msg);



y+=50;


}


for(i=1;i<=n-1;i++)
{
encrypt_decrypt(actual_names[i]);                                    
}


int cx=270,cy=660;

readimagefile("screen\\check sign.jpg",cx,cy,cx+42,cy+38);
/*
cx=700,cy=660;

readimagefile("screen\\check sign.jpg",cx,cy,cx+42,cy+38);
*/

key='a';
while(key!=ENTER)
{
key=getch();
if(key==ESCAPE)
{
//encrypt file -> all files.dat
score_encryption_decryption("Master file\\all files.dat");
goto back;
}
else if(key==ENTER)
{
//encrypt file -> all files.dat
score_encryption_decryption("Master file\\all files.dat");
if(cx==700)
exit(1);
else
goto back;              
}

key=getch();

//_______________________ Move Cursor Upward if user pressed UP arrow key ___________________
if(key==LEFT)
{
readimagefile("screen\\black check sign.jpg",cx,cy,cx+42,cy+38);

if(cx==700)
cx=270;

readimagefile("screen\\check sign.jpg",cx,cy,cx+42,cy+38);
}
// _________________________________Cursor Moved UP sucessfully ____________________________

//_______________________ Move Cursor Upward if user pressed UP arrow key ___________________
else if(key==RIGHT)
{
readimagefile("screen\\black check sign.jpg",cx,cy,cx+42,cy+38);

if(cx==270)
cx=700;

readimagefile("screen\\check sign.jpg",cx,cy,cx+42,cy+38);

}
// _________________________________Cursor Moved UP sucessfully ____________________________

}




}///*****************************//


//_____________________ PRESSES ENTER INFRONT OF LOAD GAME _________________
else if(y_position==280)
{
    

     begining:

temp[0]='a';
distance=660;

cleardevice();

//============================================== NEW GAME =========================================//
//constructing HEADER BOUNDARY
readimagefile("screen\\load game outer boundary.jpg",10,10,1350,760);

//asking for player name by displaying image text
readimagefile("screen\\Ask for player name for load game.jpg",300,383,300+332,383+62);

//displaying message of creating profile from image
//595 91
readimagefile("screen\\loading profile.jpg",370,200,370+594,200+91);

//displaying martin the warrior left 
readimagefile("screen\\right dragon.jpg",60,100,60+248,100+146);

//displaying martin the warrior right 
readimagefile("screen\\left dragon.jpg",1300-248,100,1300,100+146);
settextstyle(EUROPEAN_FONT,HORIZ_DIR,3);
settextjustify(CENTER_TEXT,CENTER_TEXT);


i=0;
int width=25;
char ext[]=".dat";


//________________________  TAKING USER NAME _____________
//______________Continue while user does not press enter key __________________________
while(temp[0]!=ENTER)
{
temp[0]=getch();

if(temp[0]==ESCAPE)
{
goto back;
}
//______________If user presses backspace then delete the character last typed_____
if(temp[0]==BACKSPACE)
{
settextstyle(EUROPEAN_FONT,HORIZ_DIR,4);
temp[0]=name[i-1];
temp[1]='\0';
name[i-1]='\0';

if(i>0)
--i;

setcolor(BLACK);
outtextxy(distance,383+35,temp); 

if(distance>=680)                 
distance-=width;

settextstyle(EUROPEAN_FONT,HORIZ_DIR,3);
}
//_____________ last CHAR deleted Sucessfully _________________

//_______________ Specify Symbols that user can type __________________

else if(temp[0]!=46&&temp[0]!=127&&i!=11&&temp[0]!=13)
{
setcolor(WHITE);
name[i]=temp[0];
temp[1]='\0';
distance+=width;
outtextxy(distance,383+35,temp);
++i;
}
//__________________symbols specified sucessfully

}
//____________________________________ END OF WHILE LOOP ______________________________




//____________________ User typed his name and pressed enter key _______________________
if(temp[0]==ENTER)
{
            
name[i]='\0';


strcpy(name3,"profiles\\");
strcpy(name2,name);
strcat(name2,ext);
setcolor(YELLOW);


strcat(name3,name2);

strcpy(file_name,name3);


bool error=false;
read_profile(file_name,name,speed,&error); 

if(error==true)
goto begining;
}
}
//_____________________ PRESSES ENTER INFRONT OF NEW GAME _________________
else if(y_position==200)
{


create_again:
             
cleardevice();

//============================================== NEW GAME =========================================//
//constructing HEADER BOUNDARY
readimagefile("screen\\new game outer boundary.jpg",10,10,1350,760);

//asking for player name by displaying image text
readimagefile("screen\\Ask for player name.jpg",300,383,300+332,383+62);

//displaying message of creating profile from image
//595 91
readimagefile("screen\\Creating profile.jpg",370,200,370+594,200+91);

//displaying martin the warrior left 
readimagefile("screen\\Martin the Warrior right.jpg",60,100,60+197,100+190);

//displaying martin the warrior right 
readimagefile("screen\\Martin the Warrior left.jpg",1300-197,100,1300,100+190);

/*
getch();
exit(1);
*/
settextstyle(EUROPEAN_FONT,HORIZ_DIR,3);
settextjustify(CENTER_TEXT,CENTER_TEXT);

int width=25;
char ext[]=".dat";

//________________________  TAKING USER NAME _____________

continue_creating:
name[0]='.';
i=0;
distance= 660;
temp[0]='a';

//______________Continue while user does not press enter key __________________________
while(temp[0]!=ENTER)
{
temp[0]=getch();

if(temp[0]==ESCAPE)
{
goto back;
}

//______________If user presses backspace then delete the character last typed_____
if(temp[0]==BACKSPACE)
{

settextstyle(EUROPEAN_FONT,HORIZ_DIR,4);
temp[0]=name[i-1];
temp[1]='\0';
name[i-1]='\0';

if(i>0)
--i;

setcolor(BLACK);
outtextxy(distance,383+35,temp); 

if(distance>=680)                 
distance-=width;

settextstyle(EUROPEAN_FONT,HORIZ_DIR,3);
}

//_____________ last CHAR deleted Sucessfully _________________

//_______________ Specify Symbols that user can type __________________

/*

here i use "i" to limit the length of 12 characters. so here i starts from 0 . therefore 0 to 11 = 12 characters 
*/
//+++++++++++++++++++++++++++++++++++++++++++++ DISPLAYING NAME ONTO SCREEN +++++++++++++++++++++++++++++++++++++++++
else if(temp[0]!=46&&temp[0]!=127&&i!=11&&temp[0]!=13)
{

setcolor(WHITE);
name[i]=temp[0];




temp[1]='\0';
distance+=width;
outtextxy(distance,383+35,temp);
++i;
}

if(temp[0]==ENTER&&(name[0]=='.'||name[0]==' '))
{
goto continue_creating;
}




//__________________symbols specified sucessfully

}
//____________________________________ END OF WHILE LOOP ______________________________


//____________________ User typed his name and pressed enter key _______________________
if(temp[0]==ENTER&&name[0]!='.'&&name[0]!=' ')
{
            
name[i]='\0';

char name2[100];
char name3[]="profiles\\";
strcpy(name2,name);
strcat(name2,ext);
setcolor(YELLOW);


strcat(name3,name2);

strcpy(file_name,name3);
bool error=false;
create_profile(name3,name,speed,&error);

if(error==true)
goto create_again;




}
//____________________ End of if statement   _______________________
    

}


}
}
