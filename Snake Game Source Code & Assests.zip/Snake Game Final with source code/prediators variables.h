#define PREDIATORS_VARIABLES_H



//EAGLE VARIABLES

int eagle_speed=20,e_x=110,e_y=468;
bool eagle_forward_dir=true,eagle_backward_dir=false;
