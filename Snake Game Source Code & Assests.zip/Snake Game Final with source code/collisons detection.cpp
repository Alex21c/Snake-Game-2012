#include "abhishek.h"

//Handle and Prevent Mouses Collisons with Snake

 void handle_and_prevent_mouses_collisons_with_snake


(


// snake position variables
int i,int k,int tail_x[1000],int tail_y[1000],

//5th Mouse  variables
int *m5_x,int *m5_y,bool *m5_forward_dir,bool *m5_backward_dir,bool *m5_eat,
bool *m5_first_step,bool *m5_second_step,bool *m5_third_step,bool *m5_fourth_step,

//6th Mouse  variables
int *m6_x,int *m6_y,bool *m6_forward_dir,bool *m6_backward_dir,bool *m6_eat,
bool *m6_first_step,bool *m6_second_step,bool *m6_third_step,bool *m6_fourth_step,


//1st Mouse  variables
int *m1_x,int *m1_y,bool *m1_forward_dir,bool *m1_backward_dir,bool *m1_eat,
bool *m1_first_step,bool *m1_second_step,bool *m1_third_step,

//4th Mouse  variables
int *m4_x,int *m4_y,bool *m4_forward_dir,bool *m4_backward_dir,bool *m4_eat,
bool *m4_first_step,bool *m4_second_step,bool *m4_third_step,

//2nd Mouse  variables
int *m2_x,int *m2_y,bool *m2_forward_dir,bool *m2_backward_dir,bool *m2_eat,
bool *m2_first_step,bool *m2_second_step,bool *m2_third_step,

//3rd Mouse  variables
int *m3_x,int *m3_y,bool *m3_forward_dir,bool *m3_backward_dir,bool *m3_eat,
bool *m3_first_step,bool *m3_second_step,bool *m3_third_step





)

{
     
int length;
     
//_________________________________ Giving Mouse 5th A.I (Artificial Intellegence )_____________________________________
     

//____________________________DIR is forward _________________________
//___________________________________________________________________
//___________________________________________________________________

if(*m5_forward_dir==true&&*m5_eat==false)
{


//_____________________________________Step first is true _____________________
if(*m5_first_step==true)
{
// ->

for(length=k;length<i-1;length++)
if((*m5_x+200>=tail_x[length]&&*m5_x-10<=tail_x[length])&&(*m5_y-25<=tail_y[length]&&*m5_y+25>=tail_y[length]))
{
if(*m5_x-200>=520)
*m5_x-=200;
else if(*m5_x-150>=520)
*m5_x-=150;
else if(*m5_x-100>=520)
*m5_x-=100;
else if(*m5_x-50>=520)
*m5_x-=50;
else if(*m5_x-20>=520)
*m5_x-=20;



*m5_forward_dir=false;
*m5_backward_dir=true;
break;
}
}
//_____________________________________Step Second is true _____________________
else if(*m5_second_step==true)
{
// ->

for(length=k;length<i-1;length++)
if((*m5_x+25>=tail_x[length]&&*m5_x-25<=tail_x[length])&&(*m5_y-10<=tail_y[length]&&*m5_y+200>=tail_y[length]))
{


if(*m5_y-100>=280)
*m5_y-=100;
else if(*m5_y-75>=280)
*m5_y-=75;
else if(*m5_y-50>=280)
*m5_y-=50;
else if(*m5_y-25>=280)
*m5_y-=25;


*m5_fourth_step=true;
*m5_second_step=false;

*m5_forward_dir=false;
*m5_backward_dir=true;
break;
}
}


//_____________________________________Step third is true _____________________
else if(*m5_third_step==true)
{
     
// ->

for(length=k;length<i-1;length++)
if((*m5_x+10>=tail_x[length]&&*m5_x-200<=tail_x[length])&&(*m5_y-25<=tail_y[length]&&*m5_y+25>=tail_y[length]))
{
if(*m5_x+200<=880)
*m5_x+=200;
else if(*m5_x+150<=880)
*m5_x+=150;
else if(*m5_x+100<=880)
*m5_x+=100;
else if(*m5_x+50<=880)
*m5_x+=50;
else if(*m5_x+20<=880)
*m5_x+=20;



*m5_forward_dir=false;
*m5_backward_dir=true;
break;
}                    
}
else if(*m5_fourth_step==true)
{
// ->

for(length=k;length<i-1;length++)
if((*m5_x+25>=tail_x[length]&&*m5_x-25<=tail_x[length])&&(*m5_y-200<=tail_y[length]&&*m5_y+10>=tail_y[length]))
{


if(*m5_y+100<=390)
*m5_y+=100;
else if(*m5_y+75<=390)
*m5_y+=75;
else if(*m5_y+50<=390)
*m5_y+=50;
else if(*m5_y+25<=390)
*m5_y+=25;


*m5_fourth_step=false;
*m5_second_step=true;

*m5_forward_dir=false;
*m5_backward_dir=true;
break;
}
}


}

//_________________________ DIR is backward _______________________________
//___________________________________________________________________
//___________________________________________________________________

else if(*m5_backward_dir==true&&*m5_eat==false)
{


//_____________________________________Step first is true _____________________
if(*m5_first_step==true)
{
                       
// ->

for(length=k;length<i-1;length++)
if((*m5_x+10>=tail_x[length]&&*m5_x-200<=tail_x[length])&&(*m5_y-25<=tail_y[length]&&*m5_y+25>=tail_y[length]))
{
if(*m5_x+200<=880)
*m5_x+=200;
else if(*m5_x+150<=880)
*m5_x+=150;
else if(*m5_x+100<=880)
*m5_x+=100;
else if(*m5_x+50<=880)
*m5_x+=50;
else if(*m5_x+20<=880)
*m5_x+=20;



*m5_forward_dir=true;
*m5_backward_dir=false;
break;
}                    
}
else if(*m5_second_step==true)
{
// ->

for(length=k;length<i-1;length++)
if((*m5_x+25>=tail_x[length]&&*m5_x-25<=tail_x[length])&&(*m5_y-10<=tail_y[length]&&*m5_y+200>=tail_y[length]))
{


if(*m5_y-100>=280)
*m5_y-=100;
else if(*m5_y-75>=280)
*m5_y-=75;
else if(*m5_y-50>=280)
*m5_y-=50;
else if(*m5_y-25>=280)
*m5_y-=25;


*m5_fourth_step=true;
*m5_second_step=false;

*m5_forward_dir=true;
*m5_backward_dir=false;
break;
}
}
else if(*m5_fourth_step==true)
{
// ->

for(length=k;length<i-1;length++)
if((*m5_x+25>=tail_x[length]&&*m5_x-25<=tail_x[length])&&(*m5_y-200<=tail_y[length]&&*m5_y+10>=tail_y[length]))
{




if(*m5_y+100<=390)
*m5_y+=100;
if(*m5_y+75<=390)
*m5_y+=75;
else if(*m5_y+50<=390)
*m5_y+=50;
else if(*m5_y+25<=390)
*m5_y+=25;


*m5_fourth_step=false;
*m5_second_step=true;

*m5_forward_dir=true;
*m5_backward_dir=false;
break;
}
}

//_____________________________________Step third is true _____________________
else if(*m5_third_step==true)
{
// ->

for(length=k;length<i-1;length++)
if((*m5_x+200>=tail_x[length]&&*m5_x-10<=tail_x[length])&&(*m5_y-25<=tail_y[length]&&*m5_y+25>=tail_y[length]))
{
if(*m5_x-200>=520)
*m5_x-=200;
else if(*m5_x-150>=520)
*m5_x-=150;
else if(*m5_x-100>=520)
*m5_x-=100;
else if(*m5_x-50>=520)
*m5_x-=50;
else if(*m5_x-20>=520)
*m5_x-=20;



*m5_forward_dir=true;
*m5_backward_dir=false;
break;
}                    
}
}
//_________________________________ A.I to Mouse 5th Sucessfully Given _____________________________________


/*


*********      **      **       **** 
***********    ***     **       **  ** 
**             ****    **       **   ** 
**             ** **   **       **    ** 
*******        **  **  **       **    ** 
*********      **   ** **       **    ** 
**             **    ****       **   ** 
**********     **     ***       **  ** 
********       **      **       ****  


*/


     
//_________________________________ Giving Mouse 6th A.I (Artificial Intellegence )_____________________________________
     

//____________________________DIR is forward _________________________
//___________________________________________________________________
//___________________________________________________________________

if(*m6_forward_dir==true&&*m6_eat==false)
{


//_____________________________________Step first is true _____________________
if(*m6_first_step==true)
{
// ->

for(length=k;length<i-1;length++)
if((*m6_x+200>=tail_x[length]&&*m6_x-10<=tail_x[length])&&(*m6_y-25<=tail_y[length]&&*m6_y+25>=tail_y[length]))
{

if(*m6_x-200>=520)
*m6_x-=200;
else if(*m6_x-150>=520)
*m6_x-=150;
else if(*m6_x-100>=520)
*m6_x-=100;
else if(*m6_x-50>=520)
*m6_x-=50;
else if(*m6_x-20>=520)
*m6_x-=20;



*m6_forward_dir=false;
*m6_backward_dir=true;
break;
}
}
//_____________________________________Step Second is true _____________________
else if(*m6_second_step==true)
{
// ->

for(length=k;length<i-1;length++)
if((*m6_x+25>=tail_x[length]&&*m6_x-25<=tail_x[length])&&(*m6_y-10<=tail_y[length]&&*m6_y+200>=tail_y[length]))
{


if(*m6_y-100>=599)
*m6_y-=100;
else if(*m6_y-75>=599)
*m6_y-=75;
else if(*m6_y-50>=599)
*m6_y-=50;
else if(*m6_y-25>=599)
*m6_y-=25;


*m6_fourth_step=true;
*m6_second_step=false;

*m6_forward_dir=false;
*m6_backward_dir=true;
break;
}
}


//_____________________________________Step third is true _____________________
else if(*m6_third_step==true)
{
     
// ->

for(length=k;length<i-1;length++)
if((*m6_x+10>=tail_x[length]&&*m6_x-200<=tail_x[length])&&(*m6_y-25<=tail_y[length]&&*m6_y+25>=tail_y[length]))
{

if(*m6_x+200<=880)
*m6_x+=200;
else if(*m6_x+150<=880)
*m6_x+=150;
else if(*m6_x+100<=880)
*m6_x+=100;
else if(*m6_x+50<=880)
*m6_x+=50;
else if(*m6_x+20<=880)
*m6_x+=20;



*m6_forward_dir=false;
*m6_backward_dir=true;
break;
}                    
}
else if(*m6_fourth_step==true)
{
// ->

for(length=k;length<i-1;length++)
if((*m6_x+25>=tail_x[length]&&*m6_x-25<=tail_x[length])&&(*m6_y-200<=tail_y[length]&&*m6_y+10>=tail_y[length]))
{


if(*m6_y+100<=650)
*m6_y+=100;
else if(*m6_y+75<=650)
*m6_y+=75;
else if(*m6_y+50<=650)
*m6_y+=50;
else if(*m6_y+25<=650)
*m6_y+=25;


*m6_fourth_step=false;
*m6_second_step=true;

*m6_forward_dir=false;
*m6_backward_dir=true;
break;
}
}


}

//_________________________ DIR is backward _______________________________
//___________________________________________________________________
//___________________________________________________________________

else if(*m6_backward_dir==true&&*m6_eat==false)
{


//_____________________________________Step first is true _____________________
if(*m6_first_step==true)
{
                       
// ->

for(length=k;length<i-1;length++)
if((*m6_x+10>=tail_x[length]&&*m6_x-200<=tail_x[length])&&(*m6_y-25<=tail_y[length]&&*m6_y+25>=tail_y[length]))
{

if(*m6_x+200<=880)
*m6_x+=200;
else if(*m6_x+150<=880)
*m6_x+=150;
else if(*m6_x+100<=880)
*m6_x+=100;
else if(*m6_x+50<=880)
*m6_x+=50;
else if(*m6_x+20<=880)
*m6_x+=20;



*m6_forward_dir=true;
*m6_backward_dir=false;
break;
}                    
}
else if(*m6_second_step==true)
{
// ->

for(length=k;length<i-1;length++)
if((*m6_x+25>=tail_x[length]&&*m6_x-25<=tail_x[length])&&(*m6_y-10<=tail_y[length]&&*m6_y+200>=tail_y[length]))
{


if(*m6_y-100>=599)
*m6_y-=100;
if(*m6_y-75>=599)
*m6_y-=75;
else if(*m6_y-50>=599)
*m6_y-=50;
else if(*m6_y-25>=599)
*m6_y-=25;


*m6_fourth_step=true;
*m6_second_step=false;

*m6_forward_dir=true;
*m6_backward_dir=false;
break;
}
}
else if(*m6_fourth_step==true)
{
// ->

for(length=k;length<i-1;length++)
if((*m6_x+25>=tail_x[length]&&*m6_x-25<=tail_x[length])&&(*m6_y-200<=tail_y[length]&&*m6_y+10>=tail_y[length]))
{


if(*m6_y+100<=650)
*m6_y+=100;
if(*m6_y+75<=650)
*m6_y+=75;
else if(*m6_y+50<=650)
*m6_y+=50;
else if(*m6_y+25<=650)
*m6_y+=25;


*m6_fourth_step=false;
*m6_second_step=true;

*m6_forward_dir=true;
*m6_backward_dir=false;
break;
}
}

//_____________________________________Step third is true _____________________
else if(*m6_third_step==true)
{
// ->

for(length=k;length<i-1;length++)
if((*m6_x+200>=tail_x[length]&&*m6_x-10<=tail_x[length])&&(*m6_y-25<=tail_y[length]&&*m6_y+25>=tail_y[length]))
{

if(*m6_x-200>=520)
*m6_x-=200;
else if(*m6_x-150>=520)
*m6_x-=150;
else if(*m6_x-100>=520)
*m6_x-=100;
else if(*m6_x-50>=520)
*m6_x-=50;
else if(*m6_x-20>=520)
*m6_x-=20;



*m6_forward_dir=true;
*m6_backward_dir=false;
break;
}                    
}
}
//_________________________________ A.I to Mouse 6th  Sucessfully  Given _____________________________________





/*


*********      **      **       **** 
***********    ***     **       **  ** 
**             ****    **       **   ** 
**             ** **   **       **    ** 
*******        **  **  **       **    ** 
*********      **   ** **       **    ** 
**             **    ****       **   ** 
**********     **     ***       **  ** 
********       **      **       ****  


*/

    
     
//_________________________________ Giving Mouse 1st A.I (Artificial Intellegence )_____________________________________
     

//____________________________DIR is forward _________________________
//___________________________________________________________________
//___________________________________________________________________

if(*m1_forward_dir==true&&*m1_eat==false)
{
//____________________________DIR IS FORWARD _____________________

if(*m1_first_step==true)
{
for(length=k;length<i-1;length++)
if((*m1_x+200>=tail_x[length]&&*m1_x-10<=tail_x[length])&&(*m1_y-25<=tail_y[length]&&*m1_y+25>=tail_y[length]))
{


if(*m1_x-200>=130)
*m1_x-=200;
else if(*m1_x-100>=130)
*m1_x-=100;
else if(*m1_x-75>=130)
*m1_x-=75;
else if(*m1_x-50>=130)
*m1_x-=50;
else if(*m1_x-25>=130)
*m1_x-=25;




*m1_forward_dir=false;
*m1_backward_dir=true;
break;
}
}
//280 390
else if(*m1_second_step==true)
{
for(length=k;length<i-1;length++)
if((*m1_x+25>=tail_x[length]&&*m1_x-25<=tail_x[length])&&(*m1_y-10<=tail_y[length]&&*m1_y+200>=tail_y[length]))
{


if(*m1_y-100>=280)
*m1_y-=100;
else if(*m1_y-75>=280)
*m1_y-=75;
else if(*m1_y-50>=280)
*m1_y-=50;
else if(*m1_y-25>=280)
*m1_y-=25;




*m1_forward_dir=false;
*m1_backward_dir=true;
break;
}
}

else if(*m1_third_step==true)
{
for(length=k;length<i-1;length++)
if((*m1_x+200>=tail_x[length]&&*m1_x-10<=tail_x[length])&&(*m1_y-25<=tail_y[length]&&*m1_y+25>=tail_y[length]))
{

if(*m1_x-200>=200)
*m1_x-=200;
else if(*m1_x-100>=250)
*m1_x-=100;
else if(*m1_x-75>=250)
*m1_x-=75;
else if(*m1_x-50>=250)
*m1_x-=50;
else if(*m1_x-25>=250)
*m1_x-=25;




*m1_forward_dir=false;
*m1_backward_dir=true;
break;
}
}



}

//____________________________DIR IS BACKWARD _____________________

else if(*m1_backward_dir==true&&*m1_eat==false)
{

if(*m1_first_step==true)
{
                       
//120

for(length=k;length<i-1;length++)
if((*m1_x+10>=tail_x[length]&&*m1_x-200<=tail_x[length])&&(*m1_y-25<=tail_y[length]&&*m1_y+25>=tail_y[length]))
{


if(*m1_x+200<=250)
*m1_x+=200;
else if(*m1_x+100<=250)
*m1_x+=100;
else if(*m1_x+75<=250)
*m1_x+=75;
else if(*m1_x+50<=250)
*m1_x+=50;
else if(*m1_x+25<=250)
*m1_x+=25;




*m1_forward_dir=true;
*m1_backward_dir=false;
break;
}
}
//280 390
else if(*m1_second_step==true)
{
for(length=k;length<i-1;length++)
if((*m1_x+25>=tail_x[length]&&*m1_x-25<=tail_x[length])&&(*m1_y-200<=tail_y[length]&&*m1_y+10>=tail_y[length]))
{


if(*m1_y+100<=390)
*m1_y+=100;
else if(*m1_y+75<=390)
*m1_y+=75;
else if(*m1_y+50<=390)
*m1_y+=50;
else if(*m1_y+25<=390)
*m1_y+=25;




*m1_forward_dir=true;
*m1_backward_dir=false;
break;
}
}



else if(*m1_third_step==true)
{
for(length=k;length<i-1;length++)
if((*m1_x+10>=tail_x[length]&&*m1_x-200<=tail_x[length])&&(*m1_y-25<=tail_y[length]&&*m1_y+25>=tail_y[length]))
{



if(*m1_x+200<=370)
*m1_x+=200;
else if(*m1_x+100<=370)
*m1_x+=100;
else if(*m1_x+75<=370)
*m1_x+=75;
else if(*m1_x+50<=370)
*m1_x+=50;
else if(*m1_x+25<=370)
*m1_x+=25;




*m1_forward_dir=true;
*m1_backward_dir=false;
break;
}
}


}
//_________________________________ A.I to Mouse 1st Sucessfully Given _____________________________________




/*


*********      **      **       **** 
***********    ***     **       **  ** 
**             ****    **       **   ** 
**             ** **   **       **    ** 
*******        **  **  **       **    ** 
*********      **   ** **       **    ** 
**             **    ****       **   ** 
**********     **     ***       **  ** 
********       **      **       ****  


*/

    
     
//_________________________________ Giving Mouse 4th A.I (Artificial Intellegence )_____________________________________
     

//____________________________DIR is forward _________________________
//___________________________________________________________________
//___________________________________________________________________



if(*m4_forward_dir==true&&*m4_eat==false)
{
//____________________________DIR IS FORWARD _____________________

if(*m4_first_step==true)
{
for(length=k;length<i-1;length++)
if((*m4_x+200>=tail_x[length]&&*m4_x-10<=tail_x[length])&&(*m4_y-25<=tail_y[length]&&*m4_y+25>=tail_y[length]))
{


if(*m4_x-200>=1000)
*m4_x-=200;
else if(*m4_x-100>=1000)
*m4_x-=100;
else if(*m4_x-75>=1000)
*m4_x-=75;
else if(*m4_x-50>=1000)
*m4_x-=50;
else if(*m4_x-25>=1000)
*m4_x-=25;




*m4_forward_dir=false;
*m4_backward_dir=true;
break;
}
}
//280 390
else if(*m4_second_step==true)
{
for(length=k;length<i-1;length++)
if((*m4_x+25>=tail_x[length]&&*m4_x-25<=tail_x[length])&&(*m4_y-10<=tail_y[length]&&*m4_y+200>=tail_y[length]))
{


if(*m4_y-100>=540)
*m4_y-=100;
else if(*m4_y-75>=540)
*m4_y-=75;
else if(*m4_y-50>=540)
*m4_y-=50;
else if(*m4_y-25>=540)
*m4_y-=25;




*m4_forward_dir=false;
*m4_backward_dir=true;
break;
}
}

else if(*m4_third_step==true)
{
for(length=k;length<i-1;length++)
if((*m4_x+200>=tail_x[length]&&*m4_x-10<=tail_x[length])&&(*m4_y-25<=tail_y[length]&&*m4_y+25>=tail_y[length]))
{


if(*m4_x-200>=1120)
*m4_x-=200;
else if(*m4_x-100>=1120)
*m4_x-=100;
else if(*m4_x-75>=1120)
*m4_x-=75;
else if(*m4_x-50>=1120)
*m4_x-=50;
else if(*m4_x-25>=1120)
*m4_x-=25;




*m4_forward_dir=false;
*m4_backward_dir=true;
break;
}
}



}

//____________________________DIR IS BACKWARD _____________________

else if(*m4_backward_dir==true&&*m4_eat==false)
{

if(*m4_first_step==true)
{
                       
//120

for(length=k;length<i-1;length++)
if((*m4_x+10>=tail_x[length]&&*m4_x-200<=tail_x[length])&&(*m4_y-25<=tail_y[length]&&*m4_y+25>=tail_y[length]))
{


if(*m4_x+200<=1240)
*m4_x+=200;
else if(*m4_x+100<=1240)
*m4_x+=100;
else if(*m4_x+75<=1240)
*m4_x+=75;
else if(*m4_x+50<=1240)
*m4_x+=50;
else if(*m4_x+25<=1240)
*m4_x+=25;




*m4_forward_dir=true;
*m4_backward_dir=false;
break;
}
}
//280 390
else if(*m4_second_step==true)
{
for(length=k;length<i-1;length++)
if((*m4_x+25>=tail_x[length]&&*m4_x-25<=tail_x[length])&&(*m4_y-200<=tail_y[length]&&*m4_y+10>=tail_y[length]))
{


if(*m4_y+100<=650)
*m4_y+=100;
else if(*m4_y+75<=650)
*m4_y+=75;
else if(*m4_y+50<=650)
*m4_y+=50;
else if(*m4_y+25<=650)
*m4_y+=25;




*m4_forward_dir=true;
*m4_backward_dir=false;
break;
}
}



else if(*m4_third_step==true)
{
for(length=k;length<i-1;length++)
if((*m4_x+10>=tail_x[length]&&*m4_x-200<=tail_x[length])&&(*m4_y-25<=tail_y[length]&&*m4_y+25>=tail_y[length]))
{

if(*m4_x+200<=1120)
*m4_x+=200;
else if(*m4_x+100<=1120)
*m4_x+=100;
else if(*m4_x+75<=1120)
*m4_x+=75;
else if(*m4_x+50<=1120)
*m4_x+=50;
else if(*m4_x+25<=1120)
*m4_x+=25;




*m4_forward_dir=true;
*m4_backward_dir=false;
break;
}
}


}
//_________________________________ A.I to Mouse 5th Sucessfully Given _____________________________________





/*


*********      **      **       **** 
***********    ***     **       **  ** 
**             ****    **       **   ** 
**             ** **   **       **    ** 
*******        **  **  **       **    ** 
*********      **   ** **       **    ** 
**             **    ****       **   ** 
**********     **     ***       **  ** 
********       **      **       ****  


*/

    
     
//_________________________________ Giving Mouse 1st A.I (Artificial Intellegence )_____________________________________
     

//____________________________DIR is forward _________________________
//___________________________________________________________________
//___________________________________________________________________

if(*m2_forward_dir==true&&*m2_eat==false)
{
//____________________________DIR IS FORWARD _____________________

if(*m2_first_step==true)
{
for(length=k;length<i-1;length++)
if((*m2_x+200>=tail_x[length]&&*m2_x-10<=tail_x[length])&&(*m2_y-25<=tail_y[length]&&*m2_y+25>=tail_y[length]))
{

if(*m2_x-200>=130)
*m2_x-=200;
else if(*m2_x-100>=130)
*m2_x-=100;
else if(*m2_x-75>=130)
*m2_x-=75;
else if(*m2_x-50>=130)
*m2_x-=50;
else if(*m2_x-25>=130)
*m2_x-=25;




*m2_forward_dir=false;
*m2_backward_dir=true;
break;
}
}
//280 390
else if(*m2_second_step==true)
{
for(length=k;length<i-1;length++)
if((*m2_x+25>=tail_x[length]&&*m2_x-25<=tail_x[length])&&(*m2_y-200<=tail_y[length]&&*m2_y+10>=tail_y[length]))
{



if(*m2_y+100<=650)
*m2_y+=100;
else if(*m2_y+75<=650)
*m2_y+=75;
else if(*m2_y+50<=650)
*m2_y+=50;
else if(*m2_y+25<=650)
*m2_y+=25;




*m2_forward_dir=false;
*m2_backward_dir=true;
break;
}
}

else if(*m2_third_step==true)
{
for(length=k;length<i-1;length++)
if((*m2_x+200>=tail_x[length]&&*m2_x-10<=tail_x[length])&&(*m2_y-25<=tail_y[length]&&*m2_y+25>=tail_y[length]))
{


if(*m2_x-200>=250)
*m2_x-=200;
else if(*m2_x-100>=250)
*m2_x-=100;
else if(*m2_x-75>=250)
*m2_x-=75;
else if(*m2_x-50>=250)
*m2_x-=50;
else if(*m2_x-25>=250)
*m2_x-=25;




*m2_forward_dir=false;
*m2_backward_dir=true;
break;
}
}



}

//____________________________DIR IS BACKWARD _____________________

else if(*m2_backward_dir==true&&*m2_eat==false)
{

if(*m2_first_step==true)
{
                       
//120

for(length=k;length<i-1;length++)
if((*m2_x+10>=tail_x[length]&&*m2_x-200<=tail_x[length])&&(*m2_y-25<=tail_y[length]&&*m2_y+25>=tail_y[length]))
{

if(*m2_x+200<=250)
*m2_x+=200;
else if(*m2_x+100<=250)
*m2_x+=100;
else if(*m2_x+75<=250)
*m2_x+=75;
else if(*m2_x+50<=250)
*m2_x+=50;
else if(*m2_x+25<=250)
*m2_x+=25;




*m2_forward_dir=true;
*m2_backward_dir=false;
break;
}
}
//280 390
else if(*m2_second_step==true)
{
for(length=k;length<i-1;length++)
if((*m2_x+25>=tail_x[length]&&*m2_x-25<=tail_x[length])&&(*m2_y-10<=tail_y[length]&&*m2_y+200>=tail_y[length]))
{


if(*m2_y-100>=540)
*m2_y-=100;
else if(*m2_y-75>=540)
*m2_y-=75;
else if(*m2_y-50>=540)
*m2_y-=50;
else if(*m2_y-25>=540)
*m2_y-=25;




*m2_forward_dir=true;
*m2_backward_dir=false;
break;
}
}



else if(*m2_third_step==true)
{
for(length=k;length<i-1;length++)
if((*m2_x+10>=tail_x[length]&&*m2_x-200<=tail_x[length])&&(*m2_y-25<=tail_y[length]&&*m2_y+25>=tail_y[length]))
{

if(*m2_x+200<=370)
*m2_x+=200;
else if(*m2_x+100<=370)
*m2_x+=100;
else if(*m2_x+75<=370)
*m2_x+=75;
else if(*m2_x+50<=370)
*m2_x+=50;
else if(*m2_x+25<=370)
*m2_x+=25;




*m2_forward_dir=true;
*m2_backward_dir=false;
break;
}
}


}
//_________________________________ A.I to Mouse 5th Sucessfully Given _____________________________________



/*


*********      **      **       **** 
***********    ***     **       **  ** 
**             ****    **       **   ** 
**             ** **   **       **    ** 
*******        **  **  **       **    ** 
*********      **   ** **       **    ** 
**             **    ****       **   ** 
**********     **     ***       **  ** 
********       **      **       ****  


*/

    
 


    
    //_________________________________ Giving Mouse 1st A.I (Artificial Intellegence )_____________________________________
     

//____________________________DIR is forward _________________________
//___________________________________________________________________
//___________________________________________________________________

if(*m3_forward_dir==true&&*m3_eat==false)
{
//____________________________DIR IS FORWARD _____________________

if(*m3_first_step==true)
{
for(length=k;length<i-1;length++)
if((*m3_x+200>=tail_x[length]&&*m3_x-10<=tail_x[length])&&(*m3_y-25<=tail_y[length]&&*m3_y+25>=tail_y[length]))
{


if(*m3_x-200>=1000)
*m3_x-=200;
else if(*m3_x-100>=1000)
*m3_x-=100;
else if(*m3_x-75>=1000)
*m3_x-=75;
else if(*m3_x-50>=1000)
*m3_x-=50;
else if(*m3_x-25>=1000)
*m3_x-=25;




*m3_forward_dir=false;
*m3_backward_dir=true;
break;
}
}
//280 390
else if(*m3_second_step==true)
{
for(length=k;length<i-1;length++)
if((*m3_x+25>=tail_x[length]&&*m3_x-25<=tail_x[length])&&(*m3_y-200<=tail_y[length]&&*m3_y+10>=tail_y[length]))
{


if(*m3_y+100<=390)
*m3_y+=100;
else if(*m3_y+75<=390)
*m3_y+=75;
else if(*m3_y+50<=390)
*m3_y+=50;
else if(*m3_y+25<=390)
*m3_y+=25;




*m3_forward_dir=false;
*m3_backward_dir=true;
break;
}
}

else if(*m3_third_step==true)
{
for(length=k;length<i-1;length++)
if((*m3_x+200>=tail_x[length]&&*m3_x-10<=tail_x[length])&&(*m3_y-25<=tail_y[length]&&*m3_y+25>=tail_y[length]))
{


if(*m3_x-200>=1120)
*m3_x-=200;
else if(*m3_x-100>=1120)
*m3_x-=100;
else if(*m3_x-75>=1120)
*m3_x-=75;
else if(*m3_x-50>=1120)
*m3_x-=50;
else if(*m3_x-25>=1120)
*m3_x-=25;




*m3_forward_dir=false;
*m3_backward_dir=true;
break;
}
}



}

//____________________________DIR IS BACKWARD _____________________

else if(*m3_backward_dir==true&&*m3_eat==false)
{

if(*m3_first_step==true)
{
                       
//120

for(length=k;length<i-1;length++)
if((*m3_x+10>=tail_x[length]&&*m3_x-200<=tail_x[length])&&(*m3_y-25<=tail_y[length]&&*m3_y+25>=tail_y[length]))
{

if(*m3_x-200>=1120)
*m3_x-=200;
else if(*m3_x+100<=1240)
*m3_x+=100;
else if(*m3_x+75<=1120)
*m3_x+=75;
else if(*m3_x+50<=1120)
*m3_x+=50;
else if(*m3_x+25<=1120)
*m3_x+=25;




*m3_forward_dir=true;
*m3_backward_dir=false;
break;
}
}
//280 390
else if(*m3_second_step==true)
{
for(length=k;length<i-1;length++)
if((*m3_x+25>=tail_x[length]&&*m3_x-25<=tail_x[length])&&(*m3_y-10<=tail_y[length]&&*m3_y+200>=tail_y[length]))
{


if(*m3_y-100>=280)
*m3_y-=100;
else if(*m3_y-75>=280)
*m3_y-=75;
else if(*m3_y-50>=280)
*m3_y-=50;
else if(*m3_y-25>=280)
*m3_y-=25;




*m3_forward_dir=true;
*m3_backward_dir=false;
break;
}
}



else if(*m3_third_step==true)
{
for(length=k;length<i-1;length++)
if((*m3_x+10>=tail_x[length]&&*m3_x-200<=tail_x[length])&&(*m3_y-25<=tail_y[length]&&*m3_y+25>=tail_y[length]))
{


if(*m3_x+200<=1240)
*m3_x+=200;
else if(*m3_x+100<=1240)
*m3_x+=100;
else if(*m3_x+75<=1240)
*m3_x+=75;
else if(*m3_x+50<=1240)
*m3_x+=50;
else if(*m3_x+25<=1240)
*m3_x+=25;




*m3_forward_dir=true;
*m3_backward_dir=false;
break;
}
}


}
//_________________________________ A.I to Mouse 5th Sucessfully Given _____________________________________


}
    
    
    
    /*
    
    
    
    ----------------------------------------------------------------------------------------------------
    
    
___________________________________CATCH AND EAT MOUSES  __________________________________
                                         
                                         
                                         
    ----------------------------------------------------------------------------------------------------
                                             
                                             
                                             
                                             
                                             
    
    */
    


//_______________ Catch and Eat mouses ___________________________

void catch_and_eat_mouses_which_collides_with_snake


(


// snake position variables
int i,int k,int head_x,int head_y,

//5th Mouse  variables
int *m5_x,int *m5_y,bool *m5_forward_dir,bool *m5_backward_dir,bool *m5_eat,
bool *m5_first_step,bool *m5_second_step,bool *m5_third_step,bool *m5_fourth_step,

//6th Mouse  variables
int *m6_x,int *m6_y,bool *m6_forward_dir,bool *m6_backward_dir,bool *m6_eat,
bool *m6_first_step,bool *m6_second_step,bool *m6_third_step,bool *m6_fourth_step,


//1st Mouse  variables
int *m1_x,int *m1_y,bool *m1_forward_dir,bool *m1_backward_dir,bool *m1_eat,
bool *m1_first_step,bool *m1_second_step,bool *m1_third_step,

//4th Mouse  variables
int *m4_x,int *m4_y,bool *m4_forward_dir,bool *m4_backward_dir,bool *m4_eat,
bool *m4_first_step,bool *m4_second_step,bool *m4_third_step,

//2nd Mouse  variables
int *m2_x,int *m2_y,bool *m2_forward_dir,bool *m2_backward_dir,bool *m2_eat,
bool *m2_first_step,bool *m2_second_step,bool *m2_third_step,

//3rd Mouse  variables
int *m3_x,int *m3_y,bool *m3_forward_dir,bool *m3_backward_dir,bool *m3_eat,
bool *m3_first_step,bool *m3_second_step,bool *m3_third_step,bool *erase,
char *file_name,char *name,char *score,char *lifes,char *level,
int *m1_score,int *m2_score,int *m3_score,int *m4_score,int *m5_score,int *m6_score,int *food_eaten,int *no_of_erase,int *time,int *master_time

)

{
     
     
     
  int length;
  bool update=false;
  
  int temp_score; //variable for processing char score
  

  
  // Detecting collison of SNAKE WITH UPPER DOVE
if(*m5_forward_dir==true&&*m5_eat==false)
{
   
//_____________________________________Step first is true _____________________
if(*m5_first_step==true)
{
// ->

if((*m5_x+50>=head_x&&*m5_x-50<=head_x)&&(*m5_y-25<=head_y&&*m5_y+25>=head_y))
{
//
*m5_forward_dir=false;
*m5_backward_dir=false;
*m5_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;


//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m5_score;

itoa(temp_score,score,10);





}
}
//_____________________________________Step Second is true _____________________
else if(*m5_second_step==true)
{
if((*m5_x+25>=head_x&&*m5_x-25<=head_x)&&(*m5_y-50<=head_y&&*m5_y+50>=head_y))
{
//

*m5_forward_dir=false;
*m5_backward_dir=false;
*m5_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m5_score;

itoa(temp_score,score,10);

}
}
//_____________________________________Step third is true _____________________
else if(*m5_third_step==true)
{
    
if((*m5_x+50>=head_x&&*m5_x-50<=head_x)&&(*m5_y-25<=head_y&&*m5_y+25>=head_y))
{
//
*m5_forward_dir=false;
*m5_backward_dir=false;
*m5_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m5_score;

itoa(temp_score,score,10);

}                    
}
else if(*m5_fourth_step==true)
{
if((*m5_x+25>=head_x&&*m5_x-25<=head_x)&&(*m5_y-50<=head_y&&*m5_y+50>=head_y))
{
//
*m5_forward_dir=false;
*m5_backward_dir=false;
*m5_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m5_score;

itoa(temp_score,score,10);

}
}
}

//_________________________ DIR is backward _______________________________
//___________________________________________________________________
//___________________________________________________________________

else if(*m5_backward_dir==true&&*m5_eat==false)
{


//_____________________________________Step first is true _____________________
if(*m5_first_step==true)
{
                       
// ->


if((*m5_x+50>=head_x&&*m5_x-50<=head_x)&&(*m5_y-25<=head_y&&*m5_y+25>=head_y))
{
//
*m5_forward_dir=false;
*m5_backward_dir=false;
*m5_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m5_score;

itoa(temp_score,score,10);



}                    
}
else if(*m5_second_step==true)
{
// ->


if((*m5_x+25>=head_x&&*m5_x-25<=head_x)&&(*m5_y-50<=head_y&&*m5_y+50>=head_y))
{

//
*m5_forward_dir=false;
*m5_backward_dir=false;
*m5_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m5_score;

itoa(temp_score,score,10);



}
}
else if(*m5_fourth_step==true)
{
// ->


if((*m5_x+25>=head_x&&*m5_x-25<=head_x)&&(*m5_y-50<=head_y&&*m5_y+50>=head_y))
{

//

*m5_forward_dir=false;
*m5_backward_dir=false;
*m5_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m5_score;

itoa(temp_score,score,10);


}
}

//_____________________________________Step third is true _____________________
else if(*m5_third_step==true)
{
// ->


if((*m5_x+50>=head_x&&*m5_x-50<=head_x)&&(*m5_y-25<=head_y&&*m5_y+25>=head_y))
{
//
*m5_forward_dir=false;
*m5_backward_dir=false;
*m5_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m5_score;

itoa(temp_score,score,10);



}                    
}
}
  

  


/**************************************************
Detecting SNAKE collison with the DOWNWARD dove

****************************************************/






//____________________________DIR is forward _________________________
//___________________________________________________________________
//___________________________________________________________________

if(*m6_forward_dir==true&&*m6_eat==false)
{


//_____________________________________Step first is true _____________________
if(*m6_first_step==true)
{
// ->

if((*m6_x+50>=head_x&&*m6_x-50<=head_x)&&(*m6_y-25<=head_y&&*m6_y+25>=head_y))
{


//
*m6_forward_dir=false;
*m6_backward_dir=false;
*m6_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m6_score;

itoa(temp_score,score,10);



}
}
//_____________________________________Step Second is true _____________________
else if(*m6_second_step==true)
{
// ->

if((*m6_x+25>=head_x&&*m6_x-25<=head_x)&&(*m6_y-50<=head_y&&*m6_y+50>=head_y))
{


//
*m6_forward_dir=false;
*m6_backward_dir=false;
*m6_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m6_score;

itoa(temp_score,score,10);


}
}


//_____________________________________Step third is true _____________________
else if(*m6_third_step==true)
{
     
// ->

if((*m6_x+50>=head_x&&*m6_x-50<=head_x)&&(*m6_y-25<=head_y&&*m6_y+25>=head_y))
{

//
*m6_forward_dir=false;
*m6_backward_dir=false;
*m6_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m6_score;

itoa(temp_score,score,10);


}                    
}
else if(*m6_fourth_step==true)
{
// ->

if((*m6_x+25>=head_x&&*m6_x-25<=head_x)&&(*m6_y-50<=head_y&&*m6_y+50>=head_y))
{



//
*m6_forward_dir=false;
*m6_backward_dir=false;
*m6_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m6_score;

itoa(temp_score,score,10);

}
}


}

//_________________________ DIR is backward _______________________________
//___________________________________________________________________
//___________________________________________________________________

else if(*m6_backward_dir==true&&*m6_eat==false)
{


//_____________________________________Step first is true _____________________
if(*m6_first_step==true)
{
                       
// ->

if((*m6_x+50>=head_x&&*m6_x-50<=head_x)&&(*m6_y-25<=head_y&&*m6_y+25>=head_y))
{



//
*m6_forward_dir=false;
*m6_backward_dir=false;
*m6_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m6_score;

itoa(temp_score,score,10);


}                    
}
else if(*m6_second_step==true)
{
// ->

if((*m6_x+25>=head_x&&*m6_x-25<=head_x)&&(*m6_y-50<=head_y&&*m6_y+50>=head_y))
{





//
*m6_forward_dir=false;
*m6_backward_dir=false;
*m6_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m6_score;

itoa(temp_score,score,10);

}
}
else if(*m6_fourth_step==true)
{
// ->

if((*m6_x+50>=head_x&&*m6_x-50<=head_x)&&(*m6_y-25<=head_y&&*m6_y+25>=head_y))
{





//
*m6_forward_dir=false;
*m6_backward_dir=false;
*m6_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m6_score;

itoa(temp_score,score,10);

}
}

//_____________________________________Step third is true _____________________
else if(*m6_third_step==true)
{
// ->

if((*m6_x+25>=head_x&&*m6_x-25<=head_x)&&(*m6_y-50<=head_y&&*m6_y+50>=head_y))
{





//
*m6_forward_dir=false;
*m6_backward_dir=false;
*m6_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m6_score;

itoa(temp_score,score,10);

}                    
}
}





/**************************************************
Detecting SNAKE collison with the UPWARD LEFT COCK

****************************************************/


if(*m1_forward_dir==true&&*m1_eat==false)
{
//____________________________DIR IS FORWARD _____________________

if(*m1_first_step==true)
{

if((*m1_x+50>=head_x&&*m1_x-50<=head_x)&&(*m1_y-25<=head_y&&*m1_y+25>=head_y))
{



*m1_forward_dir=false;
*m1_backward_dir=false;
*m1_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;

//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m1_score;

itoa(temp_score,score,10);




}
}
//280 390
else if(*m1_second_step==true)
{

if((*m1_x+25>=head_x&&*m1_x-25<=head_x)&&(*m1_y-50<=head_y&&*m1_y+50>=head_y))
{






*m1_forward_dir=false;
*m1_backward_dir=false;
*m1_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m1_score;

itoa(temp_score,score,10);


}
}

else if(*m1_third_step==true)
{

if((*m1_x+50>=head_x&&*m1_x-50<=head_x)&&(*m1_y-25<=head_y&&*m1_y+25>=head_y))
{





*m1_forward_dir=false;
*m1_backward_dir=false;
*m1_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m1_score;

itoa(temp_score,score,10);



}
}



}

//____________________________DIR IS BACKWARD _____________________

else if(*m1_backward_dir==true&&*m1_eat==false)
{

if(*m1_first_step==true)
{
                       
//120


if((*m1_x+50>=head_x&&*m1_x-50<=head_x)&&(*m1_y-25<=head_y&&*m1_y+25>=head_y))
{






*m1_forward_dir=false;
*m1_backward_dir=false;
*m1_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;

//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m1_score;

itoa(temp_score,score,10);

}
}
//280 390
else if(*m1_second_step==true)
{

if((*m1_x+25>=head_x&&*m1_x-25<=head_x)&&(*m1_y-50<=head_y&&*m1_y+50>=head_y))
{



*m1_forward_dir=false;
*m1_backward_dir=false;
*m1_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m1_score;

itoa(temp_score,score,10);


}
}



else if(*m1_third_step==true)
{

if((*m1_x+50>=head_x&&*m1_x-50<=head_x)&&(*m1_y-25<=head_y&&*m1_y+25>=head_y))
{






*m1_forward_dir=false;
*m1_backward_dir=false;
*m1_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m1_score;

itoa(temp_score,score,10);

}
}


}


/*****************************
*****************************/

/**************************************************
Detecting SNAKE collison with the DOWNWARD RIGHT SQUIRREL

****************************************************/


if(*m4_forward_dir==true&&*m4_eat==false)
{
//____________________________DIR IS FORWARD _____________________

if(*m4_first_step==true)
{

if((*m4_x+50>=head_x&&*m4_x-50<=head_x)&&(*m4_y-25<=head_y&&*m4_y+25>=head_y))
{






*m4_forward_dir=false;
*m4_backward_dir=false;
*m4_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m4_score;

itoa(temp_score,score,10);



}
}
//280 390
else if(*m4_second_step==true)
{

if((*m4_x+25>=head_x&&*m4_x-25<=head_x)&&(*m4_y-50<=head_y&&*m4_y+50>=head_y))
{






*m4_forward_dir=false;
*m4_backward_dir=false;
*m4_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m4_score;

itoa(temp_score,score,10);


}
}

else if(*m4_third_step==true)
{

if((*m4_x+50>=head_x&&*m4_x-50<=head_x)&&(*m4_y-25<=head_y&&*m4_y+25>=head_y))
{






*m4_forward_dir=false;
*m4_backward_dir=false;
*m4_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;

//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m4_score;

itoa(temp_score,score,10);

}
}



}

//____________________________DIR IS BACKWARD _____________________

else if(*m4_backward_dir==true&&*m4_eat==false)
{

if(*m4_first_step==true)
{
                       
//120


if((*m4_x+50>=head_x&&*m4_x-50<=head_x)&&(*m4_y-25<=head_y&&*m4_y+25>=head_y))
{






*m4_forward_dir=false;
*m4_backward_dir=false;
*m4_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m4_score;

itoa(temp_score,score,10);


}
}
//280 390
else if(*m4_second_step==true)
{

if((*m4_x+25>=head_x&&*m4_x-25<=head_x)&&(*m4_y-50<=head_y&&*m4_y+50>=head_y))
{






*m4_forward_dir=false;
*m4_backward_dir=false;
*m4_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m4_score;

itoa(temp_score,score,10);


}
}



else if(*m4_third_step==true)
{

if((*m4_x+50>=head_x&&*m4_x-50<=head_x)&&(*m4_y-25<=head_y&&*m4_y+25>=head_y))
{





*m4_forward_dir=false;
*m4_backward_dir=false;
*m4_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m4_score;

itoa(temp_score,score,10);

}
}


}
/**************************************************
Detecting SNAKE collison with the DOWNWARD LEFT SQUIRREL

****************************************************/


if(*m2_forward_dir==true&&*m2_eat==false)
{
//____________________________DIR IS FORWARD _____________________

if(*m2_first_step==true)
{

if((*m2_x+50>=head_x&&*m2_x-50<=head_x)&&(*m2_y-25<=head_y&&*m2_y+25>=head_y))
{




*m2_forward_dir=false;
*m2_backward_dir=false;
*m2_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m2_score;

itoa(temp_score,score,10);


}
}
//280 390
else if(*m2_second_step==true)
{

if((*m2_x+25>=head_x&&*m2_x-25<=head_x)&&(*m2_y-50<=head_y&&*m2_y+50>=head_y))
{






*m2_forward_dir=false;
*m2_backward_dir=false;
*m2_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m2_score;

itoa(temp_score,score,10);

}
}

else if(*m2_third_step==true)
{

if((*m2_x+50>=head_x&&*m2_x-50<=head_x)&&(*m2_y-25<=head_y&&*m2_y+25>=head_y))
{





*m2_forward_dir=false;
*m2_backward_dir=false;
*m2_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m2_score;

itoa(temp_score,score,10);

}
}



}

//____________________________DIR IS BACKWARD _____________________

else if(*m2_backward_dir==true&&*m2_eat==false)
{

if(*m2_first_step==true)
{
                       
//120


if((*m2_x+50>=head_x&&*m2_x-50<=head_x)&&(*m2_y-25<=head_y&&*m2_y+25>=head_y))
{




*m2_forward_dir=false;
*m2_backward_dir=false;
*m2_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m2_score;

itoa(temp_score,score,10);

}
}
//280 390
else if(*m2_second_step==true)
{

if((*m2_x+25>=head_x&&*m2_x-25<=head_x)&&(*m2_y-50<=head_y&&*m2_y+50>=head_y))
{




*m2_forward_dir=false;
*m2_backward_dir=false;
*m2_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m2_score;

itoa(temp_score,score,10);

}
}



else if(*m2_third_step==true)
{

if((*m2_x+50>=head_x&&*m2_x-50<=head_x)&&(*m2_y-25<=head_y&&*m2_y+25>=head_y))
{



*m2_forward_dir=false;
*m2_backward_dir=false;
*m2_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m2_score;

itoa(temp_score,score,10);

}
}


}


/**************************************************
Detecting SNAKE collison with the UPWARD RIGHT COCK

****************************************************/

if(*m3_forward_dir==true&&*m3_eat==false)
{
//____________________________DIR IS FORWARD _____________________

if(*m3_first_step==true)
{

if((*m3_x+50>=head_x&&*m3_x-50<=head_x)&&(*m3_y-25<=head_y&&*m3_y+25>=head_y))
{





*m3_forward_dir=false;
*m3_backward_dir=false;
*m3_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m3_score;

itoa(temp_score,score,10);


}
}
//280 390
else if(*m3_second_step==true)
{

if((*m3_x+25>=head_x&&*m3_x-25<=head_x)&&(*m3_y-50<=head_y&&*m3_y+50>=head_y))
{




*m3_forward_dir=false;
*m3_backward_dir=false;
*m3_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m3_score;

itoa(temp_score,score,10);

}
}

else if(*m3_third_step==true)
{

if((*m3_x+50>=head_x&&*m3_x-50<=head_x)&&(*m3_y-25<=head_y&&*m3_y+25>=head_y))
{





*m3_forward_dir=false;
*m3_backward_dir=false;
*m3_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m3_score;

itoa(temp_score,score,10);

}
}



}

//____________________________DIR IS BACKWARD _____________________

else if(*m3_backward_dir==true&&*m3_eat==false)
{

if(*m3_first_step==true)
{
                       
//120


if((*m3_x+50>=head_x&&*m3_x-50<=head_x)&&(*m3_y-25<=head_y&&*m3_y+25>=head_y))
{



*m3_forward_dir=false;
*m3_backward_dir=false;
*m3_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m3_score;

itoa(temp_score,score,10);

}
}
//280 390
else if(*m3_second_step==true)
{

if((*m3_x+25>=head_x&&*m3_x-25<=head_x)&&(*m3_y-50<=head_y&&*m3_y+50>=head_y))
{





*m3_forward_dir=false;
*m3_backward_dir=false;
*m3_eat=true;
*erase=false; *no_of_erase=4;
update=true; ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m3_score;

itoa(temp_score,score,10);

}
}



else if(*m3_third_step==true)
{

if((*m3_x+50>=head_x&&*m3_x-50<=head_x)&&(*m3_y-25<=head_y&&*m3_y+25>=head_y))
{





*m3_forward_dir=false;
*m3_backward_dir=false;
*m3_eat=true;
*erase=false; 
*no_of_erase=4;
update=true;
 ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);

temp_score+=*m3_score;

itoa(temp_score,score,10);

}
}


}
//_________________________________ A.I to Mouse 5th Sucessfully Given _____________________________________


if(update==true)
{

clear_header_screen_items();
update_profile_and_update_screen(file_name,name,score,lifes,level,*food_eaten,time,master_time);

}


}



