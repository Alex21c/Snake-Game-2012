#include "abhishek.h"


////////////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

void poison_left

(


int head_x,int head_y,int m1_x,int  m1_y,int m2_x,int m2_y,int m3_x,int m3_y,int m4_x,int m4_y,int m5_x,int m5_y,int m6_x,int m6_y,
char *file_name,char *name,char *score,char *lifes,char *level,
int *m1_score,int *m2_score,int *m3_score,int *m4_score,int *m5_score,int *m6_score,int *food_eaten,int *no_of_erase
,bool *m1_eat,bool *m2_eat,bool *m3_eat,bool *m4_eat,bool *m5_eat,bool *m6_eat,bool *m5_erase,bool *erase,bool *m6_erase
,bool *m1_erase,bool *m2_erase,bool *m3_erase,bool *m4_erase,int *time,int *master_time
)

{
int x_screen_distance=90;
head_y+=10;
head_x-=60;
int temp_x=head_x;


char key;
do 
{  

readimagefile("Fires\\level  1 fires\\left fire.jpg",head_x-27,head_y-10,head_x+27,head_y+10); 
//getch();


if(kbhit()==1)
{
key=getch();
if(key==ESCAPE)
{
encrypt_decrypt(file_name);
exit(1);
}
}

if(head_x-50<=m5_x&&head_x+50>=m5_x&&head_y-25<=m5_y&&head_y+25>=m5_y&&*m5_eat==false)

{
setcolor(WHITE);
outtextxy(500,500,"got that");

delay(1000);
setcolor(BLACK);
outtextxy(500,500,"got that");
readimagefile("Fires\\level  1 fires\\black l&r fire.jpg",head_x-27,head_y-10,head_x+27,head_y+10); 

 int length;
 int temp_score; //variable for processing char score
  


*m5_erase=true;
*m5_eat=true;
*erase=false; 
*no_of_erase=4;
 ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);
temp_score+=*m3_score;
itoa(temp_score,score,10);



clear_header_screen_items();
update_profile_and_update_screen(file_name,name,score,lifes,level,*food_eaten,time,master_time);


break;
}
else if(head_x-50<=m6_x&&head_x+50>=m6_x&&head_y-25<=m6_y&&head_y+25>=m6_y&&*m6_eat==false)

{
setcolor(WHITE);
outtextxy(500,500,"got that");

delay(1000);
setcolor(BLACK);
outtextxy(500,500,"got that");
readimagefile("Fires\\level  1 fires\\black l&r fire.jpg",head_x-27,head_y-10,head_x+27,head_y+10); 

 int length;
 int temp_score; //variable for processing char score
  


*m6_erase=true;
*m6_eat=true;
*erase=false; 
*no_of_erase=4;
++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);
temp_score+=*m3_score;
itoa(temp_score,score,10);



clear_header_screen_items();
update_profile_and_update_screen(file_name,name,score,lifes,level,*food_eaten,time,master_time);


break;
}
else if(head_x-50<=m1_x&&head_x+50>=m1_x&&head_y-25<=m1_y&&head_y+25>=m1_y&&*m1_eat==false)

{
setcolor(WHITE);
outtextxy(500,500,"got that");

delay(1000);
setcolor(BLACK);
outtextxy(500,500,"got that");
readimagefile("Fires\\level  1 fires\\black l&r fire.jpg",head_x-27,head_y-10,head_x+27,head_y+10); 

 int length;
 int temp_score; //variable for processing char score
  


*m1_erase=true;
*m1_eat=true;
*erase=false; 
*no_of_erase=4;
++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);
temp_score+=*m3_score;
itoa(temp_score,score,10);



clear_header_screen_items();
update_profile_and_update_screen(file_name,name,score,lifes,level,*food_eaten,time,master_time);


break;
}
else if(head_x-50<=m3_x&&head_x+50>=m3_x&&head_y-25<=m3_y&&head_y+25>=m3_y&&*m3_eat==false)

{
setcolor(WHITE);
outtextxy(500,500,"got that");

delay(1000);
setcolor(BLACK);
outtextxy(500,500,"got that");
readimagefile("Fires\\level  1 fires\\black l&r fire.jpg",head_x-27,head_y-10,head_x+27,head_y+10); 

 int length;
 int temp_score; //variable for processing char score
  


*m3_erase=true;
*m3_eat=true;
*erase=false; 
*no_of_erase=4;
++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);
temp_score+=*m3_score;
itoa(temp_score,score,10);



clear_header_screen_items();
update_profile_and_update_screen(file_name,name,score,lifes,level,*food_eaten,time,master_time);


break;
}

else if(head_x-50<=m2_x&&head_x+50>=m2_x&&head_y-25<=m2_y&&head_y+25>=m2_y&&*m2_eat==false)

{
setcolor(WHITE);
outtextxy(500,500,"got that");

delay(1000);
setcolor(BLACK);
outtextxy(500,500,"got that");
readimagefile("Fires\\level  1 fires\\black l&r fire.jpg",head_x-27,head_y-10,head_x+27,head_y+10); 

 int length;
 int temp_score; //variable for processing char score
  


*m2_erase=true;
*m2_eat=true;
*erase=false; 
*no_of_erase=4;
++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);
temp_score+=*m3_score;
itoa(temp_score,score,10);



clear_header_screen_items();
update_profile_and_update_screen(file_name,name,score,lifes,level,*food_eaten,time,master_time);


break;
}
else if(head_x-50<=m4_x&&head_x+50>=m4_x&&head_y-25<=m4_y&&head_y+25>=m4_y&&*m4_eat==false)

{
setcolor(WHITE);
outtextxy(500,500,"got that");

delay(1000);
setcolor(BLACK);
outtextxy(500,500,"got that");
readimagefile("Fires\\level  1 fires\\black l&r fire.jpg",head_x-27,head_y-10,head_x+27,head_y+10); 

 int length;
 int temp_score; //variable for processing char score
  


*m4_erase=true;
*m4_eat=true;
*erase=false; 
*no_of_erase=4;
++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);
temp_score+=*m3_score;
itoa(temp_score,score,10);



clear_header_screen_items();
update_profile_and_update_screen(file_name,name,score,lifes,level,*food_eaten,time,master_time);


break;
}
delay(10);

readimagefile("Fires\\level  1 fires\\black l&r fire.jpg",head_x-27,head_y-10,head_x+27,head_y+10); 
head_x-=20;
}while(head_x>=x_screen_distance);





}

////////////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\


//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> POISON RIGHT <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
void poison_right(
int head_x,int head_y,int m1_x,int  m1_y,int m2_x,int m2_y,int m3_x,int m3_y,int m4_x,int m4_y,int m5_x,int m5_y,int m6_x,int m6_y,
char *file_name,char *name,char *score,char *lifes,char *level,
int *m1_score,int *m2_score,int *m3_score,int *m4_score,int *m5_score,int *m6_score,int *food_eaten,int *no_of_erase
,bool *m1_eat,bool *m2_eat,bool *m3_eat,bool *m4_eat,bool *m5_eat,bool *m6_eat,bool *m5_erase,bool *erase
,bool *m6_erase
,bool *m1_erase,bool *m2_erase,bool *m3_erase,bool *m4_erase,int *time,int *master_time
)
{
int x_screen_distance=1275;
head_y+=10;
head_x+=60;

int temp_x=head_x;
char key;
do 
{  
readimagefile("Fires\\level  1 fires\\right fire.jpg",head_x-27,head_y-10,head_x+27,head_y+10); 

//getch();

if(kbhit()==1)
{
key=getch();
if(key==ESCAPE)
{
encrypt_decrypt(file_name);
exit(1);
}
}

if(head_x-50<=m5_x&&head_x+50>=m5_x&&head_y-25<=m5_y&&head_y+25>=m5_y&&*m5_eat==false)

{
setcolor(WHITE);
outtextxy(500,500,"got that");

delay(1000);
setcolor(BLACK);
outtextxy(500,500,"got that");
readimagefile("Fires\\level  1 fires\\black l&r fire.jpg",head_x-27,head_y-10,head_x+27,head_y+10); 

 int length;
 int temp_score; //variable for processing char score
  


*m5_erase=true;
*m5_eat=true;
*erase=false; 
*no_of_erase=4;
 ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);
temp_score+=*m3_score;
itoa(temp_score,score,10);



clear_header_screen_items();
update_profile_and_update_screen(file_name,name,score,lifes,level,*food_eaten,time,master_time);


break;
}
else if(head_x-50<=m6_x&&head_x+50>=m6_x&&head_y-25<=m6_y&&head_y+25>=m6_y&&*m6_eat==false)

{
setcolor(WHITE);
outtextxy(500,500,"got that");

delay(1000);
setcolor(BLACK);
outtextxy(500,500,"got that");
readimagefile("Fires\\level  1 fires\\black l&r fire.jpg",head_x-27,head_y-10,head_x+27,head_y+10); 

 int length;
 int temp_score; //variable for processing char score
  


*m6_erase=true;
*m6_eat=true;
*erase=false; 
*no_of_erase=4;
++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);
temp_score+=*m3_score;
itoa(temp_score,score,10);



clear_header_screen_items();
update_profile_and_update_screen(file_name,name,score,lifes,level,*food_eaten,time,master_time);


break;
}
else if(head_x-50<=m1_x&&head_x+50>=m1_x&&head_y-25<=m1_y&&head_y+25>=m1_y&&*m1_eat==false)

{
setcolor(WHITE);
outtextxy(500,500,"got that");

delay(1000);
setcolor(BLACK);
outtextxy(500,500,"got that");
readimagefile("Fires\\level  1 fires\\black l&r fire.jpg",head_x-27,head_y-10,head_x+27,head_y+10); 

 int length;
 int temp_score; //variable for processing char score
  


*m1_erase=true;
*m1_eat=true;
*erase=false; 
*no_of_erase=4;
++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);
temp_score+=*m3_score;
itoa(temp_score,score,10);



clear_header_screen_items();
update_profile_and_update_screen(file_name,name,score,lifes,level,*food_eaten,time,master_time);


break;
}else if(head_x-50<=m3_x&&head_x+50>=m3_x&&head_y-25<=m3_y&&head_y+25>=m3_y)

{
setcolor(WHITE);
outtextxy(500,500,"got that");

delay(1000);
setcolor(BLACK);
outtextxy(500,500,"got that");
readimagefile("Fires\\level  1 fires\\black l&r fire.jpg",head_x-27,head_y-10,head_x+27,head_y+10); 

 int length;
 int temp_score; //variable for processing char score
  


*m3_erase=true;
*m3_eat=true;
*erase=false; 
*no_of_erase=4;
++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);
temp_score+=*m3_score;
itoa(temp_score,score,10);



clear_header_screen_items();
update_profile_and_update_screen(file_name,name,score,lifes,level,*food_eaten,time,master_time);


break;
}
else if(head_x-50<=m2_x&&head_x+50>=m2_x&&head_y-25<=m2_y&&head_y+25>=m2_y&&*m2_eat==false)

{
setcolor(WHITE);
outtextxy(500,500,"got that");

delay(1000);
setcolor(BLACK);
outtextxy(500,500,"got that");
readimagefile("Fires\\level  1 fires\\black l&r fire.jpg",head_x-27,head_y-10,head_x+27,head_y+10); 

 int length;
 int temp_score; //variable for processing char score
  


*m2_erase=true;
*m2_eat=true;
*erase=false; 
*no_of_erase=4;
++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);
temp_score+=*m3_score;
itoa(temp_score,score,10);



clear_header_screen_items();
update_profile_and_update_screen(file_name,name,score,lifes,level,*food_eaten,time,master_time);


break;
}
else if(head_x-50<=m4_x&&head_x+50>=m4_x&&head_y-25<=m4_y&&head_y+25>=m4_y&&*m4_eat==false)

{
setcolor(WHITE);
outtextxy(500,500,"got that");

delay(1000);
setcolor(BLACK);
outtextxy(500,500,"got that");
readimagefile("Fires\\level  1 fires\\black l&r fire.jpg",head_x-27,head_y-10,head_x+27,head_y+10); 

 int length;
 int temp_score; //variable for processing char score
  


*m4_erase=true;
*m4_eat=true;
*erase=false; 
*no_of_erase=4;
++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);
temp_score+=*m3_score;
itoa(temp_score,score,10);



clear_header_screen_items();
update_profile_and_update_screen(file_name,name,score,lifes,level,*food_eaten,time,master_time);


break;
}


delay(10);

readimagefile("Fires\\level  1 fires\\black l&r fire.jpg",head_x-27,head_y-10,head_x+27,head_y+10); 
head_x+=20;
}while(head_x<=x_screen_distance);

}
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


//:::::::::::::::::::::::::::::::::::: POISON UP :::::::::::::::::::::::::::::::::::::::://

void poison_up
(
int head_x,int head_y,int m1_x,int  m1_y,int m2_x,int m2_y,int m3_x,int m3_y,int m4_x,int m4_y,int m5_x,int m5_y,int m6_x,int m6_y,
char *file_name,char *name,char *score,char *lifes,char *level,
int *m1_score,int *m2_score,int *m3_score,int *m4_score,int *m5_score,int *m6_score,int *food_eaten,int *no_of_erase
,bool *m1_eat,bool *m2_eat,bool *m3_eat,bool *m4_eat,bool *m5_eat,bool *m6_eat,bool *m5_erase,bool *erase
,bool *m6_erase
,bool *m1_erase,bool *m2_erase,bool *m3_erase,bool *m4_erase,int *time,int *master_time
)
{
int x_screen_distance=250;

head_y-=60;
head_x+=10;

int temp_x=head_y;
char key;
do 
{  
readimagefile("Fires\\level  1 fires\\upward fire.jpg",head_x-10,head_y-27,head_x+10,head_y+27); 

if(kbhit()==1)
{
key=getch();
if(key==ESCAPE)
{
encrypt_decrypt(file_name);
exit(1);
}

}

if(head_x-25<=m5_x&&head_x+25>=m5_x&&head_y-50<=m5_y&&head_y+50>=m5_y&&*m5_eat==false)

{
setcolor(WHITE);
outtextxy(500,500,"got that");

delay(1000);
setcolor(BLACK);
outtextxy(500,500,"got that");
readimagefile("Fires\\level  1 fires\\black u&d fire.jpg",head_x-10,head_y-27,head_x+10,head_y+27); 

 int length;
 int temp_score; //variable for processing char score
  


*m5_erase=true;
*m5_eat=true;
*erase=false; 
*no_of_erase=4;
 ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);
temp_score+=*m3_score;
itoa(temp_score,score,10);



clear_header_screen_items();
update_profile_and_update_screen(file_name,name,score,lifes,level,*food_eaten,time,master_time);


break;
}
else if(head_x-25<=m6_x&&head_x+25>=m6_x&&head_y-50<=m6_y&&head_y+50>=m6_y&&*m6_eat==false)

{
setcolor(WHITE);
outtextxy(500,500,"got that");

delay(1000);
setcolor(BLACK);
outtextxy(500,500,"got that");
readimagefile("Fires\\level  1 fires\\black u&d fire.jpg",head_x-10,head_y-27,head_x+10,head_y+27); 

 int length;
 int temp_score; //variable for processing char score
  


*m6_erase=true;
*m6_eat=true;
*erase=false; 
*no_of_erase=4;
 ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);
temp_score+=*m3_score;
itoa(temp_score,score,10);



clear_header_screen_items();
update_profile_and_update_screen(file_name,name,score,lifes,level,*food_eaten,time,master_time);


break;
}
else if(head_x-25<=m1_x&&head_x+25>=m1_x&&head_y-50<=m1_y&&head_y+50>=m1_y&&*m1_eat==false)

{
setcolor(WHITE);
outtextxy(500,500,"got that");

delay(1000);
setcolor(BLACK);
outtextxy(500,500,"got that");
readimagefile("Fires\\level  1 fires\\black u&d fire.jpg",head_x-10,head_y-27,head_x+10,head_y+27); 

 int length;
 int temp_score; //variable for processing char score
  


*m1_erase=true;
*m1_eat=true;
*erase=false; 
*no_of_erase=4;
 ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);
temp_score+=*m3_score;
itoa(temp_score,score,10);



clear_header_screen_items();
update_profile_and_update_screen(file_name,name,score,lifes,level,*food_eaten,time,master_time);


break;
}
else if(head_x-25<=m3_x&&head_x+25>=m3_x&&head_y-50<=m3_y&&head_y+50>=m3_y&&*m3_eat==false)

{
setcolor(WHITE);
outtextxy(500,500,"got that");

delay(1000);
setcolor(BLACK);
outtextxy(500,500,"got that");
readimagefile("Fires\\level  1 fires\\black u&d fire.jpg",head_x-10,head_y-27,head_x+10,head_y+27); 

 int length;
 int temp_score; //variable for processing char score
  


*m3_erase=true;
*m3_eat=true;
*erase=false; 
*no_of_erase=4;
 ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);
temp_score+=*m3_score;
itoa(temp_score,score,10);



clear_header_screen_items();
update_profile_and_update_screen(file_name,name,score,lifes,level,*food_eaten,time,master_time);


break;
}
else if(head_x-25<=m2_x&&head_x+25>=m2_x&&head_y-50<=m2_y&&head_y+50>=m2_y&&*m2_eat==false)

{
setcolor(WHITE);
outtextxy(500,500,"got that");

delay(1000);
setcolor(BLACK);
outtextxy(500,500,"got that");
readimagefile("Fires\\level  1 fires\\black u&d fire.jpg",head_x-10,head_y-27,head_x+10,head_y+27); 

 int length;
 int temp_score; //variable for processing char score
  


*m2_erase=true;
*m2_eat=true;
*erase=false; 
*no_of_erase=4;
 ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);
temp_score+=*m3_score;
itoa(temp_score,score,10);



clear_header_screen_items();
update_profile_and_update_screen(file_name,name,score,lifes,level,*food_eaten,time,master_time);


break;
}
else if(head_x-25<=m4_x&&head_x+25>=m4_x&&head_y-50<=m4_y&&head_y+50>=m4_y&&*m4_eat==false)

{
     
setcolor(WHITE);
outtextxy(500,500,"got that");

delay(1000);
setcolor(BLACK);
outtextxy(500,500,"got that");
readimagefile("Fires\\level  1 fires\\black u&d fire.jpg",head_x-10,head_y-27,head_x+10,head_y+27); 

 int length;
 int temp_score; //variable for processing char score
  


*m4_erase=true;
*m4_eat=true;
*erase=false; 
*no_of_erase=4;
 ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);
temp_score+=*m3_score;
itoa(temp_score,score,10);



clear_header_screen_items();
update_profile_and_update_screen(file_name,name,score,lifes,level,*food_eaten,time,master_time);


break;
}
delay(10);

readimagefile("Fires\\level  1 fires\\black u&d fire.jpg",head_x-10,head_y-27,head_x+10,head_y+27); 


head_y-=20;
}while(head_y>=x_screen_distance);
}

////////////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\




//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{ POISON DOWN }}}}}}}}}}}}}}}}}}}}}}}}}}}}
//:::::::::::::::::::::::::::::::::::: POISON UP :::::::::::::::::::::::::::::::::::::::://
void poison_down
(
int head_x,int head_y,int m1_x,int  m1_y,int m2_x,int m2_y,int m3_x,int m3_y,int m4_x,int m4_y,int m5_x,int m5_y,int m6_x,int m6_y,
char *file_name,char *name,char *score,char *lifes,char *level,
int *m1_score,int *m2_score,int *m3_score,int *m4_score,int *m5_score,int *m6_score,int *food_eaten,int *no_of_erase
,bool *m1_eat,bool *m2_eat,bool *m3_eat,bool *m4_eat,bool *m5_eat,bool *m6_eat,bool *m5_erase,bool *erase
,bool *m6_erase
,bool *m1_erase,bool *m2_erase,bool *m3_erase,bool *m4_erase,int *time,int *master_time

)
{
int x_screen_distance=680;
head_y+=60;
head_x+=10;

int temp_x=head_y;
char key;

do 
{  
readimagefile("Fires\\level  1 fires\\downward fire.jpg",head_x-10,head_y-27,head_x+10,head_y+27); 

if(kbhit()==1)
{
key=getch();
if(key==ESCAPE)
{
encrypt_decrypt(file_name);
exit(1);
}

}

if(head_x-25<=m5_x&&head_x+25>=m5_x&&head_y-50<=m5_y&&head_y+50>m5_y&&*m5_eat==false)

{
setcolor(WHITE);
outtextxy(500,500,"got that");

delay(1000);
setcolor(BLACK);
outtextxy(500,500,"got that");
readimagefile("Fires\\level  1 fires\\black u&d fire.jpg",head_x-10,head_y-27,head_x+10,head_y+27); 

 int length;
 int temp_score; //variable for processing char score
  


*m5_erase=true;
*m5_eat=true;
*erase=false; 
*no_of_erase=4;
 ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);
temp_score+=*m3_score;
itoa(temp_score,score,10);



clear_header_screen_items();
update_profile_and_update_screen(file_name,name,score,lifes,level,*food_eaten,time,master_time);


break;
}
else if(head_x-25<=m6_x&&head_x+25>=m6_x&&head_y-50<=m6_y&&head_y+50>m6_y&&*m6_eat==false)
{
setcolor(WHITE);
outtextxy(500,500,"got that");

delay(1000);
setcolor(BLACK);
outtextxy(500,500,"got that");
readimagefile("Fires\\level  1 fires\\black u&d fire.jpg",head_x-10,head_y-27,head_x+10,head_y+27); 

 int length;
 int temp_score; //variable for processing char score
  


*m6_erase=true;
*m6_eat=true;
*erase=false; 
*no_of_erase=4;
 ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);
temp_score+=*m3_score;
itoa(temp_score,score,10);



clear_header_screen_items();
update_profile_and_update_screen(file_name,name,score,lifes,level,*food_eaten,time,master_time);


break;
}
else if(head_x-25<=m1_x&&head_x+25>=m1_x&&head_y-50<=m1_y&&head_y+50>=m1_y&&*m1_eat==false)

{
setcolor(WHITE);
outtextxy(500,500,"got that");

delay(1000);
setcolor(BLACK);
outtextxy(500,500,"got that");
readimagefile("Fires\\level  1 fires\\black u&d fire.jpg",head_x-10,head_y-27,head_x+10,head_y+27); 

 int length;
 int temp_score; //variable for processing char score
  


*m1_erase=true;
*m1_eat=true;
*erase=false; 
*no_of_erase=4;
 ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);
temp_score+=*m3_score;
itoa(temp_score,score,10);



clear_header_screen_items();
update_profile_and_update_screen(file_name,name,score,lifes,level,*food_eaten,time,master_time);


break;
}
else if(head_x-25<=m3_x&&head_x+25>=m3_x&&head_y-50<=m3_y&&head_y+50>m3_y&&*m3_eat==false)

{
setcolor(WHITE);
outtextxy(500,500,"got that");

delay(1000);
setcolor(BLACK);
outtextxy(500,500,"got that");
readimagefile("Fires\\level  1 fires\\black u&d fire.jpg",head_x-10,head_y-27,head_x+10,head_y+27); 

 int length;
 int temp_score; //variable for processing char score
  


*m3_erase=true;
*m3_eat=true;
*erase=false; 
*no_of_erase=4;
 ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);
temp_score+=*m3_score;
itoa(temp_score,score,10);



clear_header_screen_items();
update_profile_and_update_screen(file_name,name,score,lifes,level,*food_eaten,time,master_time);


break;
}
else if(head_x-25<=m2_x&&head_x+25>=m2_x&&head_y-50<=m2_y&&head_y+50>=m2_y&&*m2_eat==false)

{
setcolor(WHITE);
outtextxy(500,500,"got that");

delay(1000);
setcolor(BLACK);
outtextxy(500,500,"got that");
readimagefile("Fires\\level  1 fires\\black u&d fire.jpg",head_x-10,head_y-27,head_x+10,head_y+27); 

 int length;
 int temp_score; //variable for processing char score
  


*m2_erase=true;
*m2_eat=true;
*erase=false; 
*no_of_erase=4;
 ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);
temp_score+=*m3_score;
itoa(temp_score,score,10);



clear_header_screen_items();
update_profile_and_update_screen(file_name,name,score,lifes,level,*food_eaten,time,master_time);


break;
}
else if(head_x-25<=m4_x&&head_x+25>=m4_x&&head_y-50<=m4_y&&head_y+50>=m4_y&&*m4_eat==false)

{
setcolor(WHITE);
outtextxy(500,500,"got that");

delay(1000);
setcolor(BLACK);
outtextxy(500,500,"got that");
readimagefile("Fires\\level  1 fires\\black u&d fire.jpg",head_x-10,head_y-27,head_x+10,head_y+27); 

 int length;
 int temp_score; //variable for processing char score
  


*m4_erase=true;
*m4_eat=true;
*erase=false; 
*no_of_erase=4;
 ++*food_eaten;
//Main Processing for Updating Score
temp_score=atoi(score);
temp_score+=*m3_score;
itoa(temp_score,score,10);



clear_header_screen_items();
update_profile_and_update_screen(file_name,name,score,lifes,level,*food_eaten,time,master_time);


break;
}

delay(10);

readimagefile("Fires\\level  1 fires\\black u&d fire.jpg",head_x-10,head_y-27,head_x+10,head_y+27); 


head_y+=20;
}while(head_y<=x_screen_distance);
}
////////////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\


//{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}





