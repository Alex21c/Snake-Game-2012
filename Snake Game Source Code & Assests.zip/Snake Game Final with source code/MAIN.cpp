#include "abhishek.h"





int main()
{

system("cd screen resolution && screen.exe && cd..");

char file_name[100];

bool exit=false;
  
startup_user_screen(&exit,file_name);


getch();


return 0;
}
