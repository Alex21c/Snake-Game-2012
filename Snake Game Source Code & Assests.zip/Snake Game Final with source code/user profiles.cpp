#include "abhishek.h"

void handle_score(char *fname)
{

//decrypt file -> all files.dat
score_encryption_decryption("Master file\\all files.dat");

char name[100],name2[100],name3[100],score[100],lifes[100],level[100];



int j;

//------------------------------------------//
ifstream read;

char names[100][100],temp[100];
int i=1,n;

char profile[100]="profiles\\";

char actual_names[100][100];

char aaaa[100];



//opening all files & update it
read.open("Master file\\all files.dat",ios::in);
//reading data from file

while(read.eof()==0)
{
read.getline(names[i],50,'\n');


n=i;
++i;
}

read.close();


//modifing names data along with path 
for(i=1;i<=n-1;i++)
{
strcpy(temp,profile);
strcat(temp,names[i]);
strcpy(actual_names[i],temp);

if(strcmp(actual_names[i],fname)!=0)
{
encrypt_decrypt(actual_names[i]);                                    
}




temp[0]='\0';

}

/*
//accessing data from all files 

for(i=1;i<=n-1;i++)
{

access_profile_data(actual_names[i],name,score,lifes,level);
outtext(score);
outtext(" ");

}
*/




char temp_score[100][50];





//Obtaining and coping scroes in temp_score;
for(i=1;i<=n-1;i++)
{
access_profile_data(actual_names[i],name,score,lifes,level);

strcpy(temp_score[i],score);

}



/*-------- strcmp() function reference --------

returns
< 0 str1 is greater than str2
> 0 str2 is greater than str1
= 0 str is equal to str2


*/



//convertig text into integers
int t_temp[100],t_t_temp;

char msg[100];
for(i=1;i<=n-1;i++)
{
t_temp[i]=atoi(temp_score[i]);
}



//Now use BUBBLE SORT for sorting of data



char anonymous[100];

for(i=1;i<=n-1;i++)
{
for(j=i+1;j<=n-1;j++)
{
if(t_temp[i]<t_temp[j]) //str 1 is greater than str2
{
t_t_temp=t_temp[i];
t_temp[i]=t_temp[j];
t_temp[j]=t_t_temp;


strcpy(anonymous,actual_names[i]);
strcpy(actual_names[i],actual_names[j]);
strcpy(actual_names[j],anonymous);

}
}                   

}






//sorting done sucessfully



//checking done sucessfully

//Now displaying top 5 Winners



int z;

if(n-1<=5)
z=n-1;
else 
z=5;

//Displaying data on screen

int colors[5]={COLOR(255,197,21),COLOR(255,61,164),COLOR(47,230,130),COLOR(121,55,171),COLOR(255,255,255)};




int x,y=330;


//access profile data
access_profile_data(actual_names[1],name,score,lifes,level);

ofstream  write;
write.open("Master file\\Master file.dat",ios::out);
write<<score;
write.close();
     




//decrypting files data  
for(i=1;i<=n-1;i++)
{

if(strcmp(actual_names[i],fname)!=0)
{
encrypt_decrypt(actual_names[i]);                                    
}



}






//encrypt file -> all files.dat
score_encryption_decryption("Master file\\all files.dat");


}



















//_________________________ Function For Creating Profile ___________________
void create_profile(char file_name[100],char name[100],int speed,bool *error=false)
{

// file_name contains file_name along with source
char temp[100],temp1[100];

strcpy(temp,name);
strcat(temp,".dat");
strcpy(temp1,temp);


ifstream read;
read.open(file_name,ios::in);


if(!read)//i.e read==0 or file does not exits 
{
//_______________create data file _______________
fstream write,;
write.open(file_name,ios::out);
//___data entering format - > name<<score<<lifes<<level ____

write<<name<<"^"<<"0"<<"^"<<"5"<<"^"<<"1"<<"^";
write.close();




//first place data into temp file
write.open("Master file\\temp.dat",ios::out);
write<<temp;
write.close();

//encrypt data in temp file
score_encryption_decryption("Master file\\temp.dat");

//now access encryped data of temp file
write.open("Master file\\temp.dat",ios::in);
write.getline(temp,100,'\n');
write.close();

//now open allfile.dat and place encryped data inside it
write.open("Master file\\all files.dat",ios::out|ios::app);
write<<temp<<"\n";
write.close();



char msg[100];




cleardevice();
char score[10]="0",lifes[5]="5",level[5]="1";



//handle_score(temp1);

start_game(file_name,name,score,lifes,level,speed);

}     
else
{
read.close();

readimagefile("screen\\profile exists.jpg",500,500,500+757,500+63);
*error=true;


getch();
}
}


//_________________________ Function For Creating Profile ___________________
void update_profile_and_update_screen(char file_name[100],char name[100],char score[10],char lifes[5],char level[5],int food_eaten,int *time,int *master_time)
{
char temp[100];


// file_name contains file_name along with source
//_______________create data file _______________
ofstream write;
write.open(file_name,ios::out);
//___data entering format - > name<<score<<lifes<<level ____
write<<name<<"^"<<score<<"^"<<lifes<<"^"<<level<<"^";
write.close();



access_profile_data(file_name,name,score,lifes,level);
int x1,y1;


//1125 98 lifes draw

//________________________ draw life ___________________________




//_____________________________________________________________


settextjustify(LEFT_TEXT,TOP_TEXT);
settextstyle(EUROPEAN_FONT,HORIZ_DIR,2);
setcolor(WHITE);

//__________ Displaing Player name ______________
setcolor(COLOR(255,0,0));
outtextxy(1115,30-2  ,name);

//__________ Displaing Player Level ______________
setcolor(COLOR(210,54,158));
if((strcmp(level,"1")==0))
outtextxy(1115,55+2    ,"First");
else if((strcmp(level,"2")==0))
outtextxy(1115,55+2    ,"Second");
else if((strcmp(level,"3")==0))
outtextxy(1115,55+2    ,"Third");
else if((strcmp(level,"4")==0))
outtextxy(1115,55+2    ,"Fourth");
else if((strcmp(level,"5")==0))
outtextxy(1115,55+2    ,"Fifth");
else if((strcmp(level,"6")==0))
outtextxy(1115,55+2    ,"Sixth");
else if((strcmp(level,"7")==0))
outtextxy(1115,55+2    ,"Seventh");
else if((strcmp(level,"8")==0))
outtextxy(1115,55+2    ,"Eight");
else if((strcmp(level,"9")==0))
outtextxy(1115,55+2    ,"Ninth");


//_______________Draw rectangle for displaying power bar ______________
readimagefile("Fires\\level  1 fires\\right fire.jpg",1115,115,1115+55,115+20); 

//setcolor(COLOR(116,49,154));
//rectangle(1115,108+8+4,1300,130+4);

//Displaying high Score

handle_score(file_name);
char temp_score[10];
high_score(temp_score);


setcolor(WHITE);
outtextxy(215,30+1,temp_score);


//Displaying Score
setcolor(COLOR(251,252,1));
outtextxy(215,55+5+2,score);

char msg[100];
itoa(food_eaten,temp,10);

//Displaying Food Eaten
setcolor(COLOR(114,44,160));
outtextxy(215,79+5+4  ,temp);

//***********************************************************//
//Displaying Time left to complete the game

sprintf(msg,"%d",*master_time);
setcolor(BLACK);
outtextxy(215,101+5+2+5+5,msg);

*master_time-=1;
sprintf(msg,"%d",*master_time);
setcolor(COLOR(1,178,87));
outtextxy(215,101+5+2+5+5,msg);

*time=0;

//***********************************************************//



int temp_life; //varibale for hodling lifes and displaying them onto screen

temp_life=atoi(lifes);


//_____________Fill the Circles of lifes ____________

if(temp_life==5)
{
readimagefile("screen\\5 lifes.bmp",1110,82-3,1110+150,111+4-3);
}
else if(temp_life==4)
{
readimagefile("screen\\4 lifes.bmp",1110,82-3,1110+120,111+4-3);
}
else if(temp_life==3)
{
readimagefile("screen\\3 lifes.bmp",1110,82-3,1110+91,111+4-3);
}
else if(temp_life==2)
{
readimagefile("screen\\2 lifes.bmp",1110,82-3,1110+61,111+4-3);
}
else if(temp_life==1)
{
readimagefile("screen\\1 life.bmp",1110,82-3,1110+31,111+4-3);
}
else if(temp_life==0)
{
readimagefile("screen\\0 life.bmp",1110,82-3,1110+31,111+4-3);
}




//____________ circles filled sucessfully ______________

    
}





//________________________________ Function for Reading Profile ____________________

void read_profile(char file_name[100],char name[100],int speed,bool *error=false)
{
    
 //decrypting data 

char temp[100];

strcpy(temp,name);
strcat(temp,".dat");
handle_score(temp);
// file_name contains file_name along with source

ifstream read;
read.open(file_name,ios::in);


if(!read)//i.e read==0 or file does not exits 
{

readimagefile("screen\\invalid proflile name.jpg",500,500,500+452,500+62);
getch();
*error=true;

}     
else
{
    
read.close();
encrypt_decrypt(file_name);
char name[100],score[100],lifes[100],level[100];
access_profile_data(file_name,name,score,lifes,level);
cleardevice();

start_game(file_name,name,score,lifes,level,speed);


                           
}




}



void access_profile_data(char *file_name,char *name,char *score,char *lifes,char *level)

{
     
     

//__________________________________Accessing Data from Player Profile _________________

//___________________variables for obtaining data from file _______________
char temp[200];

bool name_found=false,score_found=false,lifes_found=false,level_found=false;



ifstream read;
// ___data entering format - > name<<score<<lifes<<level ____
// write<<name<<"^"<<"0"<<"^"<<"5"<<"^"<<"1";

int i,l=0;
read.open(file_name,ios::in);
read.getline(temp,200,'\n');
//__________starting for loop  ________________
for(i=0;i<strlen(temp);i++)
{
//____________________ Code for obtaining NAME _______________
if((temp[i]!='^')&&(name_found==false)&&(score_found==false)&&(lifes_found==false)&&(level_found==false))
{
name[l]=temp[i];
++l;

}
else if((temp[i]=='^')&&(name_found==false)&&(score_found==false)&&(lifes_found==false)&&(level_found==false))
{

name_found=true;
name[l]='\0';
l=0;


}
//_________________ NAME obtained Sucesfully ________________

//---------------------------------------- SEPERATOR BAR  ----------------------------------------

//____________________ Code for obtaining SCORE _______________

else if((temp[i]!='^')&&(name_found==true)&&(score_found==false)&&(lifes_found==false)&&(level_found==false))
{
score[l]=temp[i];
++l;
}
else if((temp[i]=='^')&&(name_found==true)&&(score_found==false)&&(lifes_found==false)&&(level_found==false))
{
score_found=true;
score[l]='\0';
l=0;

}
//_________________ SCORE obtained Sucesfully ________________

//---------------------------------------- SEPERATOR BAR  ----------------------------------------

//____________________ Code for obtaining LIFES _______________

else if((temp[i]!='^')&&(name_found==true)&&(score_found==true)&&(lifes_found==false)&&(level_found==false))
{
lifes[l]=temp[i];
++l;
}
else if((temp[i]=='^')&&(name_found==true)&&(score_found==true)&&(lifes_found==false)&&(level_found==false))
{
lifes_found=true;
lifes[l]='\0';
l=0;


}
//_________________ LIFES obtained Sucesfully ________________

//---------------------------------------- SEPERATOR BAR  ----------------------------------------

//____________________ Code for obtaining LEVEL _______________

else if((temp[i]!='^')&&(name_found==true)&&(score_found==true)&&(lifes_found==true)&&(level_found==false))
{
level[l]=temp[i];
++l;
}
else if((temp[i]=='^')&&(name_found==true)&&(score_found==true)&&(lifes_found==true)&&(level_found==false))
{
level_found=true;
level[l]='\0';
l=0;

}
//_________________ LIFES obtained Sucesfully ________________


}
//__________ ending for loop ________________


read.close();

//___________________________ Data sucessfully accessed from the user profile ________________

}



