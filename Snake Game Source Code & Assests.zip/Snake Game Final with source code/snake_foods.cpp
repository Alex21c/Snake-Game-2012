#include "abhishek.h"

//------------------------------------
//COCKS
//------------------------------------
     
       
void mouse::cock_up(int x,int y,int color)
{ 
     
 readimagefile("Food\\Cock\\upward cock.jpg",x-12,y-14,x+12,y+14);
 
}




void mouse::cock_down(int x,int y,int color)
{ 
  readimagefile("Food\\Cock\\downward cock.jpg",x-12,y-14,x+12,y+14);

}



void mouse::cock_left(int x,int y,int color)
{ 
 readimagefile("Food\\Cock\\left cock.jpg",x-14,y-12,x+14,y+12);

}


void mouse::cock_right(int x,int y,int color)
{ 
 readimagefile("Food\\Cock\\right cock.jpg",x-14,y-12,x+14,y+12);

}






//-------------------------------------------------- ____________-----------------------------\
//________________________________ Erases cocks _____________________
//-------------------------------------------------- ____________-----------------------------\

// _______________________________ BLACK MOUSE RIGHT ______________________________________________


     
void black_mouse::black_cock_right(int x,int y)
{ 
  readimagefile("Food\\Cock\\l&r erase.jpg",x-14,y-12,x+14,y+12);


}




//__________________________ BLACK MOUSE LEFT _________________________________

void black_mouse::black_cock_left(int x,int y)
{ 
     
readimagefile("Food\\Cock\\l&r erase.jpg",x-14,y-12,x+14,y+12);
}


//_______________________________ BLACK MOUSE UP __________________________________



void black_mouse::black_cock_up(int x,int y)
{ 
   readimagefile("Food\\Cock\\u&d erase.jpg",x-12,y-14,x+12,y+14);

}




// _______________________________________ BLACK MOUSE DOWN  _______________________________________

void black_mouse::black_cock_down(int x,int y)
{ 
  readimagefile("Food\\Cock\\u&d erase.jpg",x-12,y-14,x+12,y+14);

}




//------------------------------------
//DUCKS
//------------------------------------
     
       
void mouse::duck_up(int x,int y,int color)
{ 
     
 readimagefile("Food\\Animals\\Duck\\upward duck.jpg",x-25,y-36,x+25,y+36);
 
}




void mouse::duck_down(int x,int y,int color)
{ 
  readimagefile("Food\\Animals\\Duck\\downward duck.jpg",x-25,y-36,x+25,y+36);

}



void mouse::duck_left(int x,int y,int color)
{ 
 readimagefile("Food\\Animals\\Duck\\left duck.jpg",x-36,y-25,x+36,y+25);

}


void mouse::duck_right(int x,int y,int color)
{ 
 readimagefile("Food\\Animals\\Duck\\right duck.jpg",x-36,y-25,x+36,y+25);

}






//-------------------------------------------------- ____________-----------------------------\
//________________________________ Erases ducks _____________________
//-------------------------------------------------- ____________-----------------------------\

// _______________________________ BLACK MOUSE RIGHT ______________________________________________


     
void black_mouse::black_duck_right(int x,int y)
{ 
  readimagefile("Food\\Animals\\Duck\\black l&r duck.jpg",x-36,y-25,x+36,y+25);


}




//__________________________ BLACK MOUSE LEFT _________________________________

void black_mouse::black_duck_left(int x,int y)
{ 
     
readimagefile("Food\\Animals\\Duck\\black l&r duck.jpg",x-36,y-25,x+36,y+25);
}


//_______________________________ BLACK MOUSE UP __________________________________



void black_mouse::black_duck_up(int x,int y)
{ 
   readimagefile("Food\\Animals\\Duck\\black u&d duck.jpg",x-25,y-36,x+25,y+36);

}




// _______________________________________ BLACK MOUSE DOWN  _______________________________________

void black_mouse::black_duck_down(int x,int y)
{ 
  readimagefile("Food\\Animals\\Duck\\black u&d duck.jpg",x-25,y-36,x+25,y+36);

}





//------------------------------------
//FLYING rooster
//------------------------------------
       
void mouse::flying_rooster_up(int x,int y,int color)
{ 
     
 readimagefile("Food\\Animals\\Rooster\\upward rooster.jpg",x-25,y-36,x+25,y+36);
 
}




void mouse::flying_rooster_down(int x,int y,int color)
{ 
  readimagefile("Food\\Animals\\Rooster\\downward rooster.jpg",x-25,y-36,x+25,y+36);

}



void mouse::flying_rooster_left(int x,int y,int color)
{ 
readimagefile("Food\\Animals\\Rooster\\left rooster.jpg",x-36,y-25,x+36,y+25);

}


void mouse::flying_rooster_right(int x,int y,int color)
{ 
 readimagefile("Food\\Animals\\Rooster\\right rooster.jpg",x-36,y-25,x+36,y+25);
}






//-------------------------------------------------------------------------------\
//________________________________ Erases rooster  _____________________
//-------------------------------------------------- ____________-----------------------------\

// _______________________________ BLACK MOUSE RIGHT ______________________________________________

     
void black_mouse::black_flying_rooster_right(int x,int y)
{ 
  readimagefile("Food\\Animals\\Rooster\\black l&r rooster.jpg",x-36,y-25,x+36,y+25);


}




//__________________________ BLACK MOUSE LEFT _________________________________

void black_mouse::black_flying_rooster_left(int x,int y)
{ 
     
   readimagefile("Food\\Animals\\Rooster\\black l&r rooster.jpg",x-36,y-25,x+36,y+25);
}


//_______________________________ BLACK MOUSE UP __________________________________

//36 25

void black_mouse::black_flying_rooster_up(int x,int y)
{ 
   readimagefile("Food\\Animals\\Rooster\\black u&d rooster.jpg",x-25,y-36,x+25,y+36);

}

//56 36 


// _______________________________________ BLACK MOUSE DOWN  _______________________________________

void black_mouse::black_flying_rooster_down(int x,int y)
{ 
  readimagefile("Food\\Animals\\Rooster\\black u&d rooster.jpg",x-25,y-36,x+25,y+36);

}






//------------------------------------
//EGRET
//------------------------------------
       //
void mouse::egret_up(int x,int y,int color)
{ 
     
 readimagefile("Food\\Animals\\Egret\\upward egret.jpg",x-25,y-36,x+25,y+36);
 
}




void mouse::egret_down(int x,int y,int color)
{ 
  readimagefile("Food\\Animals\\Egret\\downward egret.jpg",x-25,y-36,x+25,y+36);

}


//23 36
//25 136
void mouse::egret_left(int x,int y,int color)
{ 
readimagefile("Food\\Animals\\Egret\\left egret.jpg",x-36,y-25,x+36,y+25);

}


void mouse::egret_right(int x,int y,int color)
{ 
 readimagefile("Food\\Animals\\Egret\\right egret.jpg",x-36,y-25,x+36,y+25);
}






//-------------------------------------------------------------------------------\
//________________________________ Erases egret _____________________
//-------------------------------------------------- ____________-----------------------------\

// _______________________________ BLACK MOUSE RIGHT ______________________________________________

     
void black_mouse::black_egret_right(int x,int y)
{ 
  readimagefile("Food\\Animals\\Egret\\black l&r egret.jpg",x-36,y-25,x+36,y+25);


}




//__________________________ BLACK MOUSE LEFT _________________________________

void black_mouse::black_egret_left(int x,int y)
{ 
     
   readimagefile("Food\\Animals\\Egret\\black l&r egret.jpg",x-36,y-25,x+36,y+25);
}


//_______________________________ BLACK MOUSE UP __________________________________



void black_mouse::black_egret_up(int x,int y)
{ 
   readimagefile("Food\\Animals\\Egret\\black u&d egret.jpg",x-25,y-36,x+25,y+36);

}




// _______________________________________ BLACK MOUSE DOWN  _______________________________________

void black_mouse::black_egret_down(int x,int y)
{ 
  readimagefile("Food\\Animals\\Egret\\black u&d egret.jpg",x-25,y-36,x+25,y+36);

}












//------------------------------------
//mouse
//------------------------------------
       //
void mouse::mouse_up(int x,int y,int color)
{ 
     
 readimagefile("Food\\Animals\\Mouse\\upward mouse.jpg",x-25,y-36,x+25,y+36);
 
}




void mouse::mouse_down(int x,int y,int color)
{ 
  readimagefile("Food\\Animals\\Mouse\\downward mouse.jpg",x-25,y-36,x+25,y+36);

}


//23 36
//25 136
void mouse::mouse_left(int x,int y,int color)
{ 
readimagefile("Food\\Animals\\Mouse\\left mouse.jpg",x-36,y-25,x+36,y+25);

}


void mouse::mouse_right(int x,int y,int color)
{ 
 readimagefile("Food\\Animals\\Mouse\\right mouse.jpg",x-36,y-25,x+36,y+25);
}






//-------------------------------------------------------------------------------\
//________________________________ Erases mouse _____________________
//-------------------------------------------------- ____________-----------------------------\

// _______________________________ BLACK MOUSE RIGHT ______________________________________________

     
void black_mouse::black_mouse_right(int x,int y)
{ 
  readimagefile("Food\\Animals\\Mouse\\black l&r mouse.jpg",x-36,y-25,x+36,y+25);


}




//__________________________ BLACK MOUSE LEFT _________________________________

void black_mouse::black_mouse_left(int x,int y)
{ 
     
   readimagefile("Food\\Animals\\Mouse\\black l&r mouse.jpg",x-36,y-25,x+36,y+25);
}


//_______________________________ BLACK MOUSE UP __________________________________



void black_mouse::black_mouse_up(int x,int y)
{ 
   readimagefile("Food\\Animals\\Mouse\\black u&d mouse.jpg",x-25,y-36,x+25,y+36);

}




// _______________________________________ BLACK MOUSE DOWN  _______________________________________

void black_mouse::black_mouse_down(int x,int y)
{ 
  readimagefile("Food\\Animals\\Mouse\\black u&d mouse.jpg",x-25,y-36,x+25,y+36);

}

















//------------------------------------
//rabbit
//------------------------------------
       //
void mouse::rabbit_up(int x,int y,int color)
{ 
     
 readimagefile("Food\\Animals\\Rabbit\\upward rabbit.jpg",x-25,y-36,x+25,y+36);
 
}




void mouse::rabbit_down(int x,int y,int color)
{ 
  readimagefile("Food\\Animals\\Rabbit\\downward rabbit.jpg",x-25,y-36,x+25,y+36);

}


//23 36
//25 136
void mouse::rabbit_left(int x,int y,int color)
{ 
readimagefile("Food\\Animals\\Rabbit\\left rabbit.jpg",x-36,y-25,x+36,y+25);

}


void mouse::rabbit_right(int x,int y,int color)
{ 
 readimagefile("Food\\Animals\\Rabbit\\right rabbit.jpg",x-36,y-25,x+36,y+25);
}






//-------------------------------------------------------------------------------\
//________________________________ Erases rabbit _____________________
//-------------------------------------------------- ____________-----------------------------\

// _______________________________ BLACK rabbit RIGHT ______________________________________________

     
void black_mouse::black_rabbit_right(int x,int y)
{ 
  readimagefile("Food\\Animals\\Rabbit\\black l&r rabbit.jpg",x-36,y-25,x+36,y+25);


}




//__________________________ BLACK rabbit LEFT _________________________________

void black_mouse::black_rabbit_left(int x,int y)
{ 
     
   readimagefile("Food\\Animals\\Rabbit\\black l&r rabbit.jpg",x-36,y-25,x+36,y+25);
}


//_______________________________ BLACK rabbit UP __________________________________



void black_mouse::black_rabbit_up(int x,int y)
{ 
   readimagefile("Food\\Animals\\Rabbit\\black u&d rabbit.jpg",x-25,y-36,x+25,y+36);

}




// _______________________________________ BLACK rabbit DOWN  _______________________________________

void black_mouse::black_rabbit_down(int x,int y)
{ 
  readimagefile("Food\\Animals\\Rabbit\\black u&d rabbit.jpg",x-25,y-36,x+25,y+36);

}

















//------------------------------------
//white_bird
//------------------------------------
       //
void mouse::white_bird_up(int x,int y,int color)
{ 
     
 readimagefile("Food\\Animals\\White tropic bird\\upward bird.jpg",x-25,y-36,x+25,y+36);
 
}




void mouse::white_bird_down(int x,int y,int color)
{ 
  readimagefile("Food\\Animals\\White tropic bird\\downward bird.jpg",x-25,y-36,x+25,y+36);

}


//23 36
//25 136
void mouse::white_bird_left(int x,int y,int color)
{ 
readimagefile("Food\\Animals\\White tropic bird\\left bird.jpg",x-36,y-25,x+36,y+25);

}


void mouse::white_bird_right(int x,int y,int color)
{ 
 readimagefile("Food\\Animals\\White tropic bird\\right bird.jpg",x-36,y-25,x+36,y+25);
}






//-------------------------------------------------------------------------------\
//________________________________ Erases white_bird _____________________
//-------------------------------------------------- ____________-----------------------------\

// _______________________________ BLACK white_bird RIGHT ______________________________________________

     
void black_mouse::black_white_bird_right(int x,int y)
{ 
  readimagefile("Food\\Animals\\White tropic bird\\black l&r bird.jpg",x-36,y-25,x+36,y+25);


}




//__________________________ BLACK white_bird LEFT _________________________________

void black_mouse::black_white_bird_left(int x,int y)
{ 
     
   readimagefile("Food\\Animals\\White tropic bird\\black l&r bird.jpg",x-36,y-25,x+36,y+25);
}


//_______________________________ BLACK white_bird UP __________________________________



void black_mouse::black_white_bird_up(int x,int y)
{ 
   readimagefile("Food\\Animals\\White tropic bird\\black u&d bird.jpg",x-25,y-36,x+25,y+36);

}




// _______________________________________ BLACK white_bird DOWN  _______________________________________

void black_mouse::black_white_bird_down(int x,int y)
{ 
  readimagefile("Food\\Animals\\White tropic bird\\black u&d bird.jpg",x-25,y-36,x+25,y+36);

}
