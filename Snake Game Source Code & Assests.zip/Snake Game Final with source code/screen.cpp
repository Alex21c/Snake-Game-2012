
#include "abhishek.h"

//222 118
void clear_header_screen_items()
{
     
readimagefile("screen\\top screen black.jpg ",1100,40,1300,130);     
readimagefile("screen\\top screen black.jpg ",210,40,410,130);     

}

void high_score(char *score)
{
fstream read;
read.open("Master file\\Master File.dat",ios::in);
read.getline(score,10,'\n');
read.close();   
}



void screen(char file_name[100])
{

char msg[50];
int size,i,x,y,x1,y1;




    
//constructing HEADER BOUNDARY
readimagefile("screen\\header boundary.jpg",5,10,1355,150);



readimagefile("screen\\title.jpg",420,45,420+449,45+76);



settextjustify(RIGHT_TEXT,TOP_TEXT);
settextstyle(EUROPEAN_FONT,HORIZ_DIR,2);
setcolor(WHITE);


//1100,37   

// Dispalying Header top left menu items
readimagefile("screen\\header left menu.jpg",50,20,50+156,20+123);

//84 118
// Dispalying Header top RIGHT menu items
readimagefile("screen\\header right menu.jpg",1000,20,1000+84,20+118);



char name[100],score[100],lifes[100],level[100];

access_profile_data(file_name,name,score,lifes,level);

//________________________ draw life ___________________________
x1=1125 , y1=90+8 ;
setlinestyle(SOLID_LINE,SOLID_LINE,1);
setfillstyle(SOLID_FILL,COLOR(255,0,0));
setcolor(COLOR(255,0,0));

//ci = 49 means number 1
//ci = 57 means number 9

//___________________ Creating circles for displaying lifes
int temp_life; //varibale for hodling lifes and displaying them onto screen

temp_life=atoi(lifes);


//_____________Fill the Circles of lifes ____________

if(temp_life==5)
{
readimagefile("screen\\5 lifes.bmp",1110,82-3,1110+150,111+4-3);
}
else if(temp_life==4)
{
readimagefile("screen\\4 lifes.bmp",1110,82-3,1110+120,111+4-3);
}
else if(temp_life==3)
{
readimagefile("screen\\3 lifes.bmp",1110,82-3,1110+91,111+4-3);
}
else if(temp_life==2)
{
readimagefile("screen\\2 lifes.bmp",1110,82-3,1110+61,111+4-3);
}
else if(temp_life==1)
{
readimagefile("screen\\1 life.bmp",1110,82-3,1110+31,111+4-3);
}
else if(temp_life==0)
{
readimagefile("screen\\0 life.bmp",1110,82-3,1110+31,111+4-3);
}






//_____________________________________________________________

settextjustify(LEFT_TEXT,TOP_TEXT);
settextstyle(EUROPEAN_FONT,HORIZ_DIR,2);
setcolor(WHITE);

//__________ Displaing Player name ______________
setcolor(COLOR(255,0,0));
outtextxy(1115,30-2  ,name);

//__________ Displaing Player Level ______________
setcolor(COLOR(210,54,158));
if((strcmp(level,"1")==0))
outtextxy(1115,55+2    ,"First");
else if((strcmp(level,"2")==0))
outtextxy(1115,55+2    ,"Second");
else if((strcmp(level,"3")==0))
outtextxy(1115,55+2    ,"Third");
else if((strcmp(level,"4")==0))
outtextxy(1115,55+2    ,"Fourth");
else if((strcmp(level,"5")==0))
outtextxy(1115,55+2    ,"Fifth");
else if((strcmp(level,"6")==0))
outtextxy(1115,55+2    ,"Sixth");
else if((strcmp(level,"7")==0))
outtextxy(1115,55+2    ,"Seventh");
else if((strcmp(level,"8")==0))
outtextxy(1115,55+2    ,"Eight");
else if((strcmp(level,"9")==0))
outtextxy(1115,55+2    ,"Ninth");


//_______________Draw rectangle for displaying power bar ______________
readimagefile("Fires\\level  1 fires\\right fire.jpg",1115,115,1115+55,115+20); 

//setcolor(COLOR(116,49,154));
//rectangle(1115,108+8+4,1300,130+4);


handle_score(file_name);

char temp_score[10];
high_score(temp_score);

//Displaying high Score
setcolor(WHITE);
outtextxy(215,30+1 ,temp_score);


//Displaying Score
setcolor(COLOR(251,252,1));
outtextxy(215,55+5  ,score);

//Displaying Food Eaten
setcolor(COLOR(114,44,160));
outtextxy(215,79+5+4  ,"0");


//Displaying Time left to complete the game
setcolor(COLOR(1,178,87));
outtextxy(215,101+5+2+5+5 ,"60");









//________________________________________________________________
//-------------------------- Creating Footer Boundary ---------------------------
//________________________________________________________________

//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

//place upward left dragons 
readimagefile("screen\\555 left.jpg",10,160,10+221,160+55);
readimagefile("screen\\555 left.jpg",10+221,160,10+221+221,160+55);
readimagefile("screen\\555 left.jpg",10+221+221,160,10+221+221+221,160+55);
readimagefile("screen\\555 left.jpg",10+221+221+221,160,10+221+221+221+221,160+55);
readimagefile("screen\\555 left.jpg",10+221+221+221+221,160,10+221+221+221+221+221,160+55);
readimagefile("screen\\555 left.jpg",10+221+221+221+221+221,160,10+221+221+221+221+221+221,160+55);


//place downward right dragons 
readimagefile("screen\\555 right.jpg",10,711,10+221,711+55);
readimagefile("screen\\555 right.jpg",10+221,711,10+221+221,711+55);
readimagefile("screen\\555 right.jpg",10+221+221,711,10+221+221+221,711+55);
readimagefile("screen\\555 right.jpg",10+221+221+221,711,10+221+221+221+221,711+55);
readimagefile("screen\\555 right.jpg",10+221+221+221+221,711,10+221+221+221+221+221,711+55);
readimagefile("screen\\555 right.jpg",10+221+221+221+221+221,711,10+221+221+221+221+221+221,711+55);



//place left side downward dragons
readimagefile("screen\\555 downward.jpg",5,215+10,60,436+10);
readimagefile("screen\\555 downward.jpg",5,436+30,60,436+221+30);

//place right side upward dragons
readimagefile("screen\\555 upward.jpg",1350-55,215+10,1350,436+10);
readimagefile("screen\\555 upward.jpg",1350-55,436+30,1350,436+221+30);

//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

/*

getch();     
exit(1);
*/
}



