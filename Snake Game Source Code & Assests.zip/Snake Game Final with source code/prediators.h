#define PREDIATORS_H

//collison detection of prediators with snake
void snake_collison_with_prediators(int i,int k,int eagle_x,int eagle_y,int tail_x[1000],int tail_y[1000],char *file_name,char *name,char *score,char *lifes,char *level,int speed);


//Creating Base class Mouse
class place_prediators
{
public:
//Mouse

void eagle_left(int x,int y);
void eagle_right(int x,int y);

};

//class mouse obj_mouse;


//Creating Base Class Black mouse for erasing purpose

class erase_prediators
{
public:

void black_eagle_lr(int x,int y);


};



//________________________________________ Creating Derived Classes _____________________________

//_____________Derived Classes of First Mouse____________________________
class derived_place_prediators:public place_prediators
{
public:



//Corners cocks
void handle_eagle(int *e_x,int *e_y,bool *forward_dir,bool *backward_dir);       

    
};



class derived_erase_prediators:public erase_prediators
{
public:

void handle_black_eagle(int *e_x,int *e_y,bool *forward_dir,bool *backward_dir,int *eagle_speed);       

};
//_____________________________________________________________________




