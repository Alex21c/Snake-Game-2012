#define SCORE_H
void handle_score(char *fname);

