#ifndef MYSNAKE_H
#define MYSNAKE_H



void snake(char file_name[100],char name[100],char score[10],char lifes[5],char level[5],int speed);

void poison_left
(
int head_x,int head_y,int m1_x,int  m1_y,int m2_x,int m2_y,int m3_x,int m3_y,int m4_x,int m4_y,int m5_x,int m5_y,int m6_x,int m6_y,
char *file_name,char *name,char *score,char *lifes,char *level,
int *m1_score,int *m2_score,int *m3_score,int *m4_score,int *m5_score,int *m6_score,int *food_eaten,int *no_of_erase
,bool *m1_eat,bool *m2_eat,bool *m3_eat,bool *m4_eat,bool *m5_eat,bool *m6_eat,bool *m5_erase,bool *erase,bool *m6_erase
,bool *m1_erase,bool *m2_erase,bool *m3_erase,bool *m4_erase,int *time,int *master_time

);
void poison_right
(
int head_x,int head_y,int m1_x,int  m1_y,int m2_x,int m2_y,int m3_x,int m3_y,int m4_x,int m4_y,int m5_x,int m5_y,int m6_x,int m6_y,
char *file_name,char *name,char *score,char *lifes,char *level,
int *m1_score,int *m2_score,int *m3_score,int *m4_score,int *m5_score,int *m6_score,int *food_eaten,int *no_of_erase
,bool *m1_eat,bool *m2_eat,bool *m3_eat,bool *m4_eat,bool *m5_eat,bool *m6_eat,bool *m5_erase,bool *erase,bool *m6_erase
,bool *m1_erase,bool *m2_erase,bool *m3_erase,bool *m4_erase,int *time,int *master_time

);

void poison_up
(
int head_x,int head_y,int m1_x,int  m1_y,int m2_x,int m2_y,int m3_x,int m3_y,int m4_x,int m4_y,int m5_x,int m5_y,int m6_x,int m6_y,
char *file_name,char *name,char *score,char *lifes,char *level,
int *m1_score,int *m2_score,int *m3_score,int *m4_score,int *m5_score,int *m6_score,int *food_eaten,int *no_of_erase
,bool *m1_eat,bool *m2_eat,bool *m3_eat,bool *m4_eat,bool *m5_eat,bool *m6_eat,bool *m5_erase,bool *erase,bool *m6_erase
,bool *m1_erase,bool *m2_erase,bool *m3_erase,bool *m4_erase,int *time,int *master_time

);

void poison_down
(
int head_x,int head_y,int m1_x,int  m1_y,int m2_x,int m2_y,int m3_x,int m3_y,int m4_x,int m4_y,int m5_x,int m5_y,int m6_x,int m6_y,
char *file_name,char *name,char *score,char *lifes,char *level,
int *m1_score,int *m2_score,int *m3_score,int *m4_score,int *m5_score,int *m6_score,int *food_eaten,int *no_of_erase
,bool *m1_eat,bool *m2_eat,bool *m3_eat,bool *m4_eat,bool *m5_eat,bool *m6_eat,bool *m5_erase,bool *erase,bool *m6_erase
,bool *m1_erase,bool *m2_erase,bool *m3_erase,bool *m4_erase,int *time,int *master_time

);


void snake_collison_with_body(int i,int k,int head_x,int head_y,int tail_x[1000],int tail_y[1000],char *file_name,char *name,char *score,char *lifes,char *level,int change_x,int change_y,int speed);




// Snake collide with walls
void snake_collison_wall(int head_x,int head_y,char *file_name,char *name,char *score,char *lifes,char *level,int speed);

void snkae_touched_his_body_and_died_so_update_the_profile_and_start_the_game(char *file_name,char *name,char *score,char *lifes,char *level,int speed);





#endif
