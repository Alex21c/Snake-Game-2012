#include "abhishek.h"


void place_prediators::eagle_left(int x,int y)
{ 
readimagefile("Food\\Prediators\\Eagle\\left eagle.jpg",x-25,y-36,x+25,y+36);

}


void place_prediators::eagle_right(int x,int y)
{ 
 readimagefile("Food\\Prediators\\Eagle\\right eagle.jpg",x-25,y-36,x+25,y+36);
}


void erase_prediators::black_eagle_lr(int x,int y)
{ 
readimagefile("Food\\Prediators\\Eagle\\black l&r eagle.jpg",x-25,y-36,x+25,y+36);
}





/*


p_prediators.eagle_left(1240,468,RED);

p_prediators.eagle_left(110,468,RED);
*/


void derived_place_prediators::handle_eagle(int *e_x,int *e_y,bool *eagle_forward_dir,bool *eagle_backward_dir)
{

if(*eagle_forward_dir==true)
{
if(*e_x<=1240)
eagle_right(*e_x,*e_y);
}
else if(*eagle_backward_dir==true)
{
if(*e_x>=110)
eagle_left(*e_x,*e_y);
}

}     

  
  
  
void derived_erase_prediators::handle_black_eagle(int *e_x,int *e_y,bool *eagle_forward_dir,bool *eagle_backward_dir,int *eagle_speed)
{

if(*eagle_forward_dir==true)
{
if(*e_x<=1240)
{
black_eagle_lr(*e_x,*e_y);
*e_x+=*eagle_speed;
}
else
{
*eagle_forward_dir=false;
*eagle_backward_dir=true;
*e_x=1240;
}

}


else if(*eagle_backward_dir==true)
{

if(*e_x>=110)
{
black_eagle_lr(*e_x,*e_y);
*e_x-=*eagle_speed;
}
else
{
*eagle_backward_dir=false;
*eagle_forward_dir=true;
*e_x=110;
}


}
}     
     
     

    


