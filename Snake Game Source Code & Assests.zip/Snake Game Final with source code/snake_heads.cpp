#include "abhishek.h"







//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>//
void snake_left_head(int temp_head_x,int temp_head_y)
{
readimagefile("Snake body parts\\snake head leftward.jpg",temp_head_x-28,temp_head_y-14,temp_head_x+28,temp_head_y+15);
}
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>//




//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>//
void snake_upper_head(int temp_head_x,int temp_head_y)
{

readimagefile("Snake body parts\\snake head upward.jpg",temp_head_x-14,temp_head_y-28,temp_head_x+15,temp_head_y+28);
}
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>//




//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>//
void snake_right_head(int temp_head_x,int temp_head_y)
{
readimagefile("Snake body parts\\snake head rightward.jpg",temp_head_x-28,temp_head_y-14,temp_head_x+28,temp_head_y+15);

}

// SNAKE lower head//
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>//
void snake_lower_head(int temp_head_x,int temp_head_y)
{

readimagefile("Snake body parts\\snake head downward.jpg",temp_head_x-14,temp_head_y-28,temp_head_x+15,temp_head_y+28);


}
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>//

//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::://
void snake_right_head_black(int temp_head_x,int temp_head_y)
{
readimagefile("Snake body parts\\left and right.jpg",temp_head_x-28,temp_head_y-14,temp_head_x+28,temp_head_y+15);


}


//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::://
void snake_left_head_black(int temp_head_x,int temp_head_y)
{

readimagefile("Snake body parts\\left and right.jpg",temp_head_x-28,temp_head_y-14,temp_head_x+28,temp_head_y+15);

}

//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>//

void snake_upper_head_black(int temp_head_x,int temp_head_y)
{
readimagefile("Snake body parts\\up and down.jpg",temp_head_x-14,temp_head_y-28,temp_head_x+15,temp_head_y+28);

}

void snake_lower_head_black(int temp_head_x,int temp_head_y)
{
readimagefile("Snake body parts\\up and down.jpg",temp_head_x-14,temp_head_y-28,temp_head_x+15,temp_head_y+28);

}
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>//
