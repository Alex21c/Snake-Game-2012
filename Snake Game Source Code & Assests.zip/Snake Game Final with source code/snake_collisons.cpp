#include "abhishek.h"
#include "mysnake.h"
#include "snaketail.h"



//_______________global variables declaration_______________//

int length;
int k;


//____________________________//


void snake_collison_wall(int head_x,int head_y,char *file_name,char *name,char *score,char *lifes,char *level,int speed)
{

int temp_life;
temp_life=atoi(lifes);
 
--temp_life;
  



if((head_x<=75)&& ((head_y>=180)&&(head_y<=775))&&(temp_life==0))
{
readimagefile("screen\\snake touches the boundary.jpg",250,370,250+810,370+202);

delay(1500);

readimagefile("screen\\black boundary.jpg",250,370,250+810,370+202);

readimagefile("screen\\game over.jpg",500,400,500+346,400+81);
encrypt_decrypt(file_name);
delay(3000);
exit(1);
}
else if((head_x>=1300)&& ((head_y>=180)&&(head_y<=775))&&(temp_life==0))
{
readimagefile("screen\\snake touches the boundary.jpg",250,370,250+810,370+202);

delay(1500);

readimagefile("screen\\black boundary.jpg",250,370,250+810,370+202);

readimagefile("screen\\game over.jpg",500,400,500+346,400+81);
encrypt_decrypt(file_name);
delay(3000);
exit(1);
}
else if((head_y<=225)&& ((head_x>=50)&&(head_x<=1300))&&(temp_life==0))
{
readimagefile("screen\\snake touches the boundary.jpg",250,370,250+810,370+202);

delay(1500);

readimagefile("screen\\black boundary.jpg",250,370,250+810,370+202);

readimagefile("screen\\game over.jpg",500,400,500+346,400+81);
encrypt_decrypt(file_name);
delay(3000);
exit(1);
}
else if((head_y>=700)&& ((head_x>=50)&&(head_x<=1300))&&(temp_life==0))
{
readimagefile("screen\\snake touches the boundary.jpg",250,370,250+810,370+202);

delay(1500);

readimagefile("screen\\black boundary.jpg",250,370,250+810,370+202);

readimagefile("screen\\game over.jpg",500,400,500+346,400+81);
encrypt_decrypt(file_name);
delay(3000);
exit(1);
}
else if(

(temp_life!=0)

&& 

(
((head_y>=700)&& (head_x>=50&&head_x<=1300))||((head_y<=225)&& (head_x>=50&&head_x<=1300))||((head_x>=1300)&& (head_y>=180&&head_y<=775))||
((head_x<=75)&& (head_y>=180&&head_y<=775))
)

)


{
itoa(temp_life,lifes,10);


readimagefile("screen\\snake touches the boundary.jpg",250,370,250+810,370+202);


delay(2000);

//UPDATE PROFILE
ofstream write;
write.open(file_name,ios::out);
//___data entering format - > name<<score<<lifes<<level ____
write<<name<<"^"<<score<<"^"<<lifes<<"^"<<level<<"^";
write.close();

access_profile_data(file_name,name,score,lifes,level);
cleardevice();
start_game(file_name,name,score,lifes,level,speed);


    
}

}

// start new game if snake touches his body and decrease the life of the snake by one unit

void snkae_touched_his_body_and_died_so_update_the_profile_and_start_the_game(char *file_name,char *name,char *score,char *lifes,char *level,int speed)
{

//update the value of life by decreasing it by one unit

int temp_life;
temp_life=atoi(lifes);
 
--temp_life;
  
if(temp_life==0)
{


readimagefile("screen\\snake ate itself.jpg",400,370,400+588,370+195);

delay(1500);
readimagefile("screen\\black ate.jpg",400,370,400+588,370+195);

readimagefile("screen\\game over.jpg",500,400,500+346,400+81);
encrypt_decrypt(file_name);
delay(3000);
exit(1);
               
}
else if(temp_life>0)
{
readimagefile("screen\\snake ate itself.jpg",400,370,400+588,370+195);
delay(1000);
    
     
itoa(temp_life,lifes,10);
//UPDATE PROFILE
ofstream write;
write.open(file_name,ios::out);
//___data entering format - > name<<score<<lifes<<level ____
write<<name<<"^"<<score<<"^"<<lifes<<"^"<<level<<"^";
write.close();

access_profile_data(file_name,name,score,lifes,level);
cleardevice();
start_game(file_name,name,score,lifes,level,speed);
}

}



//check whether snake touches its body or not
void snake_collison_with_body(int i,int k,int head_x,int head_y,int tail_x[1000],int tail_y[1000],char *file_name,char *name,char *score,char *lifes,char *level,int change_x,int change_y,int speed)
{
char t[100];

for(length=k-2;length<i-1;length++)
{



if((head_x==tail_x[length]||head_x+8==tail_x[length]||head_x-8==tail_x[length])&&(head_y==tail_y[length]||head_y+8==tail_y[length]||head_y-8==tail_y[length]))
{

snkae_touched_his_body_and_died_so_update_the_profile_and_start_the_game(file_name,name,score,lifes,level,speed);
//exit(1);
}

}

//check whether snake touches wall or not
snake_collison_wall(head_x,head_y,file_name,name,score,lifes,level,speed);


}

