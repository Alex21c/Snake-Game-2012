
#include "abhishek.h"



void key_pressed(char *KEY)
{

char t;
     
//check whether any key is pressed or not from the keyboard
if(kbhit()==1)
{
t=getch();

if(t==ESCAPE)
*KEY=ESCAPE;
else if((t==poison_z)||(t==poison_Z))
*KEY=poison_z;
else if(t<=0)
{
t=getch();

if(t==LEFT)
{
*KEY=LEFT;             
}
else if(t==RIGHT)
{
*KEY=RIGHT;
             
}
else if(t==UP)
{
*KEY=UP;
             
}
else if(t==DOWN)
{
*KEY=DOWN;
}
else if(t==ESCAPE)
{
*KEY==ESCAPE;
}
}

}
}
