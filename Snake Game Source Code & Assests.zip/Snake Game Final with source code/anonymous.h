#ifndef ANONYMOUS_H
#define ANONYMOUS_H

void encrypt_decrypt(char *file_name);
void score_encryption_decryption(char *file_name);





#endif
