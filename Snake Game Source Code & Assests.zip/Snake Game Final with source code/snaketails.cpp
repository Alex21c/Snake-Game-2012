#include "abhishek.h"

//40 19
// SNAKE left TAIL

void snake_left_tail(int tail,int head_y)
{
readimagefile("Snake body parts\\snake tail left.jpg",tail-30,head_y-5,tail+66-30,head_y+5);


}

// SNAKE right TAIL

void snake_right_tail(int tail,int head_y)
{
readimagefile("Snake body parts\\snake tail right.jpg",tail-66+30,head_y-5,tail+30,head_y+5);


}


// SNAKE upper TAIL

void snake_upper_tail(int tail,int head_y)
{
readimagefile("Snake body parts\\snake tail upward.jpg",tail-5,head_y-30,tail+5,head_y+66-30);


}
// SNAKE lower TAIL

void snake_lower_tail(int tail,int head_y)
{
readimagefile("Snake body parts\\snake tail downward.jpg",tail-5,head_y-66+30,tail+5,head_y+30);


}

// SNAKE upper TAIL BLACK
void snake_upper_tail_black(int tail,int head_y)
{
readimagefile("Snake body parts\\snake tail ud black.jpg",tail-5,head_y-30,tail+5,head_y+66-30);

}

// SNAKE lower TAIL BLACK
void snake_lower_tail_black(int tail,int head_y)
{
readimagefile("Snake body parts\\snake tail ud black.jpg",tail-5,head_y-66+30,tail+5,head_y+30);


}





//black left tail

void snake_left_tail_black(int tail,int head_y)
{
readimagefile("Snake body parts\\snake tail lr black.jpg",tail-30,head_y-5,tail+66-30,head_y+5);

}


//black right tail

void snake_right_tail_black(int tail,int head_y)
{
readimagefile("Snake body parts\\snake tail lr black.jpg",tail-66+30,head_y-5,tail+30,head_y+5);

}



//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::://


/// __________________ ERASING SNAKE TAILS ________________________

void erase_tail(int tail_x[500],int tail_y[500], bool *left_tail, bool *right_tail, bool *upper_tail , bool *lower_tail,int k)
{
//erasing snake tail
if(*left_tail==true)
snake_left_tail_black(tail_x[k],tail_y[k]);
else if(*right_tail==true)
snake_right_tail_black(tail_x[k],tail_y[k]);
else if(*upper_tail==true)
snake_upper_tail_black(tail_x[k],tail_y[k]);
else if(*lower_tail==true)
snake_lower_tail_black(tail_x[k],tail_y[k]);
}

/// __________________________________________///

//########################################################################################//

/// __________________ PRINTING SNAKE TAILS ________________________
void print_tail(int tail_x[500],int tail_y[500], bool *left_tail, bool *right_tail, bool *upper_tail , bool *lower_tail,int k)
{
//printing snake tail
if(*left_tail==true)
snake_left_tail(tail_x[k],tail_y[k]);
else if(*right_tail==true)
snake_right_tail(tail_x[k],tail_y[k]);
else if(*upper_tail==true)
snake_upper_tail(tail_x[k],tail_y[k]);
else if(*lower_tail==true)
snake_lower_tail(tail_x[k],tail_y[k]);
}
///__________________________________________///

//########################################################################################//

/// __________________ set SNAKE TAILS position ________________________

void tail_position_set(int tail_x[500],int tail_y[500], bool *left_tail, bool *right_tail, bool *upper_tail , bool *lower_tail,int k)
{
// for setting tail position
if(tail_x[k]<tail_x[k-1])
*left_tail=true;
else if(tail_x[k]>tail_x[k-1])
*right_tail=true;
else if(tail_y[k]<tail_y[k-1])
*upper_tail=true;
else if(tail_y[k]>tail_y[k-1])
*lower_tail=true;
}

