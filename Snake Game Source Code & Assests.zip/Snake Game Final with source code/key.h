#ifndef KEY_H
#define KEY_H

void key_pressed(char *KEY);


#endif
