

#ifndef SNAKETAIL_H
#define SNAKETAIL_H


void snake_left_tail(int tail,int head_y);
void snake_upper_tail(int tail,int head_y);
void snake_lower_tail(int tail,int head_y);
void snake_upper_tail_black(int tail,int head_y);
void snake_lower_tail_black(int tail,int head_y);
void snake_right_tail(int tail,int head_y);
void snake_left_tail_black(int tail,int head_y);
void snake_right_tail_black(int tail,int head_y);



void print_tail(int tail_x[1000],int tail_y[1000], bool *left_tail, bool *right_tail, bool *upper_tail , bool *lower_tail,int k);
void erase_tail(int tail_x[1000],int tail_y[1000], bool *left_tail, bool *right_tail, bool *upper_tail , bool *lower_tail,int k);
void tail_position_set(int tail_x[1000],int tail_y[1000], bool *left_tail, bool *right_tail, bool *upper_tail , bool *lower_tail,int k);



#endif
