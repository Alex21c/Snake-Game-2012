#ifndef USER_PROFILE_HEADER_FILE_H
#define USER_PROFILE_HEADER_FILE_H

void create_profile(char file_name[100],char name[100],int speed,bool *error);
void read_profile(char file_name[100],char name[100],int speed,bool *error);

void access_profile_data(char *file_name,char *name,char *score,char *lifes,char *level);
void update_profile_and_update_screen(char file_name[100],char name[100],char score[10],char lifes[5],char level[5],int food_eaten,int *time,int *master_time);


#endif
