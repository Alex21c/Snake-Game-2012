#include "snake body.h"
#include "abhishek.h"


void left_body_part(int *head_x,int *head_y)
{
//14,5
readimagefile("Snake body parts\\body left and right.jpg",*head_x-14,*head_y-5,*head_x+14,*head_y+5);
     //53 19
     
     
}


void right_body_part(int *head_x,int *head_y)
{
//14,5
readimagefile("Snake body parts\\body left and right.jpg",*head_x-14,*head_y-5,*head_x+14,*head_y+5);
     
}


void upper_body_part(int *head_x,int *head_y)
{
//14,5
readimagefile("Snake body parts\\body up and down.jpg",*head_x-5,*head_y-14,*head_x+5,*head_y+14);
     
}
void lower_body_part(int *head_x,int *head_y)
{
//14,5

readimagefile("Snake body parts\\body up and down.jpg",*head_x-5,*head_y-14,*head_x+5,*head_y+14);
     
}


//_____________ BLACK BODY PARTS _____________
void left_body_part_black(int *head_x,int *head_y)
{
//14,5
readimagefile("Snake body parts\\body left and right black.jpg",*head_x-14,*head_y-5,*head_x+14,*head_y+5);
     
     
     
}


void right_body_part_black(int *head_x,int *head_y)
{
//14,5
readimagefile("Snake body parts\\body left and right black.jpg",*head_x-14,*head_y-5,*head_x+14,*head_y+5);
     
}


void upper_body_part_black(int *head_x,int *head_y)
{
//14,5
readimagefile("Snake body parts\\body up and down black.jpg",*head_x-5,*head_y-14,*head_x+5,*head_y+14);
     
}
void lower_body_part_black(int *head_x,int *head_y)
{
//14,5
readimagefile("Snake body parts\\body up and down black.jpg",*head_x-5,*head_y-14,*head_x+5,*head_y+14);
     
}


/*

if(left_tail==true)
left_body_part_black(&tail_x[k],&tail_y[k]);
else if(right_tail==true)
right_body_part_black(&tail_x[k],&tail_y[k]);
else if(upper_tail==true)
upper_body_part_black(&tail_x[k],&tail_y[k]);
else if(lower_tail==true)
lower_body_part_black(&tail_x[k],&tail_y[k]);

*/


