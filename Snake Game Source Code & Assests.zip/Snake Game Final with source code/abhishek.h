
#ifndef ABHISHEK_H
#define ABHISHEK_H

//___________ Built in Headers Files ___________
#include <windows.h>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fstream>
#include <iostream>

using namespace std;


//_____________MY OWN HEADER FILES ________
#include "key.h"
#include "graphics.h"
#include "snakehead.h"
#include "snaketail.h"
#include "mysnake.h"
#include "snake_food.h"
#include "startup_screen.h"
#include "user profiles header file.h"
#include "collisons_detections.h"
#include "anonymous.h"
#include "score.h"
#include "prediators.h"
//_____________MY OWN DEFINED CONSTANTS _________

#define UP 72
#define DOWN 80 
#define LEFT 75
#define RIGHT 77
#define ESCAPE 27
#define poison_Z 90
#define poison_z 122
#define ENTER 13
#define BACKSPACE 8
#define SPACE 32
#define F4 107



#endif
